-- 
-- Table structure for table `journal_comment`
-- 

CREATE TABLE `journal_comment` (
  `comment_id` int(10) unsigned NOT NULL auto_increment,
  `journal_id` int(10) default NULL,
  `journal_by` int(10) default NULL,
  `journal_date` varchar(100) default NULL,
  `journal_time` varchar(100) default NULL,
  `journal_text` blob,
  UNIQUE KEY `comment_id` (`comment_id`)
) TYPE=MyISAM  AUTO_INCREMENT=14 ;

-- 
-- Dumping data for table `journal_comment`
-- 

INSERT INTO `journal_comment` VALUES (3, 2, 1, '1074819144', '18:52:24 India Standard Time', 0x48656c6c6f2054686973206973206120746573742e2e2e);
INSERT INTO `journal_comment` VALUES (4, 2, 2, '1074819499', '18:58:19 India Standard Time', 0x48656c6c6f2054686973206973206120746573742e2e2e);
INSERT INTO `journal_comment` VALUES (5, 2, 2, '1074819625', '19:00:25 India Standard Time', 0x3c503e48656c6c6f3c2f503e);
INSERT INTO `journal_comment` VALUES (6, 2, 2, '1074819645', '19:00:45 India Standard Time', 0x3c503e48656c6c6f3c2f503e);
INSERT INTO `journal_comment` VALUES (7, 4, 10, '1078618475', '18:14:35 India Standard Time', 0x486920686f772061726520796f753f);
INSERT INTO `journal_comment` VALUES (8, 6, 1, '1080525002', '19:50:02 India Standard Time', 0x48656c6c6f);
INSERT INTO `journal_comment` VALUES (11, 11, 50, '1121282137', '14:15:37 India Standard Time', 0x3b6c6b6b6c3b6b3b6c6b3b6c6b6c3b6b3b);

-- --------------------------------------------------------

-- 
-- Table structure for table `login_page`
-- 

CREATE TABLE `login_page` (
  `login_id` int(10) unsigned NOT NULL auto_increment,
  `login_text` blob,
  UNIQUE KEY `login_id` (`login_id`)
) TYPE=MyISAM  AUTO_INCREMENT=2 ;

-- 
-- Dumping data for table `login_page`
-- 

INSERT INTO `login_page` VALUES (1, 0x436f6d6d696e6720536f6f6e);

-- --------------------------------------------------------

-- 
-- Table structure for table `main_page`
-- 

CREATE TABLE `main_page` (
  `main_id` int(10) unsigned NOT NULL auto_increment,
  `main_text` blob,
  UNIQUE KEY `main_id` (`main_id`)
) TYPE=MyISAM  AUTO_INCREMENT=2 ;

-- 
-- Dumping data for table `main_page`
-- 

INSERT INTO `main_page` VALUES (1, 0x54686520676f616c20666f722074686973207369746520697320746f206761746865722c20686572652c20746865205275737369616e20636f6d6d756e6974792c206f6620616c6c206167657320616e642066726f6d20616c6c206f7665722074686520776f726c642e20546f20637265617465206f6e6520706c61636520776865726520776520285275737369616e73292063616e20636f6d6d756e69636174652c2073686172652069646561732c206d656574206e65772070656f706c652c2066696e6420667269656e6473206f722074686174207370656369616c20736f6d656f6e652c2066696e64206f7574206c6174657374206e657773206f722072756d6f727320696e20796f7572206c6f63616c20636f6d6d756e6974792c206f7220616e797468696e6720656c736520796f752077616e7420746f20646f2e2054686520706f73736962696c69746965732061726520656e646c6573732c20616e642062657374206f6620616c6c2c20204954532046524545);

-- --------------------------------------------------------

-- 
-- Table structure for table `member_friends`
-- 

CREATE TABLE `member_friends` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `member_id` int(10) default NULL,
  `friend_id` int(10) default NULL,
  `approve` int(10) default NULL,
  `deleted` int(10) default NULL,
  `date` int(10) unsigned default NULL,
  UNIQUE KEY `id` (`id`)
) TYPE=MyISAM  AUTO_INCREMENT=656 ;

-- 
-- Dumping data for table `member_friends`
-- 

INSERT INTO `member_friends` VALUES (60, 85, 90, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (57, 89, 90, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (69, 91, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (64, 88, 85, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (63, 90, 84, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (68, 81, 91, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (59, 88, 90, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (58, 86, 90, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (62, 88, 84, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (61, 90, 85, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (67, 84, 88, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (66, 90, 88, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (206, 81, 112, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (56, 90, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (47, 81, 86, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (55, 81, 90, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (46, 85, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (54, 89, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (45, 81, 85, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (53, 81, 89, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (44, 84, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (52, 88, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (43, 81, 84, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (51, 81, 88, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (144, 100, 90, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (48, 86, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (135, 81, 100, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (72, 84, 90, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (73, 90, 91, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (74, 84, 91, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (75, 88, 91, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (76, 85, 91, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (77, 91, 90, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (78, 91, 88, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (79, 90, 89, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (80, 91, 89, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (81, 86, 89, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (82, 89, 88, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (624, 84, 106, 0, 0, NULL);
INSERT INTO `member_friends` VALUES (87, 84, 89, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (88, 88, 89, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (89, 91, 84, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (90, 89, 84, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (91, 85, 84, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (204, 81, 111, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (100, 91, 85, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (623, 251, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (102, 84, 85, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (593, 238, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (104, 90, 86, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (105, 89, 86, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (106, 81, 94, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (107, 94, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (110, 90, 94, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (111, 88, 94, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (114, 94, 90, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (115, 81, 95, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (116, 95, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (117, 81, 96, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (118, 96, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (119, 81, 97, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (120, 97, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (592, 81, 238, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (205, 111, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (123, 81, 98, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (124, 98, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (125, 81, 99, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (126, 99, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (127, 99, 90, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (128, 98, 90, 0, 0, NULL);
INSERT INTO `member_friends` VALUES (129, 97, 90, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (130, 90, 99, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (131, 89, 91, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (133, 90, 97, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (134, 94, 88, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (136, 100, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (137, 97, 100, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (138, 94, 100, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (139, 91, 100, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (140, 90, 100, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (142, 86, 100, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (241, 81, 120, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (243, 91, 99, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (147, 100, 91, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (148, 81, 103, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (149, 103, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (150, 103, 100, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (153, 94, 99, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (154, 89, 99, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (156, 103, 90, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (242, 120, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (158, 95, 90, 0, 0, NULL);
INSERT INTO `member_friends` VALUES (159, 96, 90, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (160, 90, 96, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (161, 86, 96, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (184, 90, 108, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (163, 91, 96, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (164, 94, 96, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (165, 103, 96, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (166, 97, 96, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (167, 85, 96, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (168, 96, 86, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (169, 100, 86, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (170, 103, 86, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (177, 106, 100, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (178, 100, 103, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (173, 96, 85, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (174, 81, 106, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (175, 106, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (176, 106, 86, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (182, 81, 108, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (183, 108, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (635, 256, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (186, 91, 108, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (187, 88, 108, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (188, 89, 108, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (189, 86, 108, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (190, 103, 108, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (191, 99, 108, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (192, 106, 108, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (634, 81, 256, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (194, 81, 109, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (195, 109, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (196, 89, 109, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (197, 99, 89, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (198, 108, 90, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (199, 108, 89, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (200, 109, 89, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (201, 81, 110, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (202, 110, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (203, 108, 86, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (207, 112, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (208, 97, 94, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (209, 100, 94, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (210, 99, 94, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (211, 96, 94, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (212, 112, 90, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (213, 81, 113, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (214, 113, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (215, 81, 114, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (216, 114, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (217, 114, 86, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (218, 86, 114, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (219, 81, 115, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (220, 115, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (221, 81, 116, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (222, 116, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (223, 90, 112, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (224, 86, 106, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (225, 108, 106, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (227, 96, 91, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (228, 108, 91, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (229, 81, 117, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (230, 117, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (231, 90, 103, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (232, 96, 103, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (233, 86, 103, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (234, 108, 103, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (235, 81, 118, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (236, 118, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (237, 108, 118, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (238, 100, 118, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (239, 81, 119, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (240, 119, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (244, 108, 99, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (245, 108, 88, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (246, 81, 121, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (247, 121, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (248, 81, 122, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (249, 122, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (250, 99, 91, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (251, 118, 108, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (252, 90, 118, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (253, 118, 90, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (254, 81, 123, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (255, 123, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (256, 118, 100, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (257, 81, 124, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (258, 124, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (259, 81, 125, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (260, 125, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (261, 81, 126, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (262, 126, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (263, 81, 127, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (264, 127, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (265, 96, 127, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (266, 81, 128, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (267, 128, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (268, 103, 118, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (269, 81, 129, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (270, 129, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (271, 81, 130, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (272, 130, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (273, 100, 106, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (274, 81, 131, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (275, 131, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (276, 127, 96, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (277, 81, 132, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (278, 132, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (279, 81, 133, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (280, 133, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (281, 81, 134, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (282, 134, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (283, 81, 135, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (284, 135, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (285, 81, 136, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (286, 136, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (287, 86, 128, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (288, 81, 137, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (289, 137, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (290, 81, 138, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (291, 138, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (292, 81, 139, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (293, 139, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (294, 81, 140, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (295, 140, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (296, 128, 139, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (297, 139, 128, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (298, 81, 142, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (299, 142, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (300, 81, 143, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (301, 143, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (302, 81, 144, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (303, 144, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (304, 142, 144, 0, 0, NULL);
INSERT INTO `member_friends` VALUES (305, 126, 144, 0, 0, NULL);
INSERT INTO `member_friends` VALUES (306, 128, 144, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (307, 118, 144, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (308, 81, 145, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (309, 145, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (310, 126, 145, 0, 0, NULL);
INSERT INTO `member_friends` VALUES (357, 122, 128, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (312, 118, 103, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (313, 144, 128, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (314, 81, 146, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (315, 146, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (316, 81, 147, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (317, 147, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (318, 81, 148, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (319, 148, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (320, 81, 149, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (321, 149, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (322, 81, 150, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (323, 150, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (324, 86, 150, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (325, 89, 150, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (326, 91, 150, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (327, 114, 150, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (328, 118, 150, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (329, 122, 150, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (330, 81, 151, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (331, 151, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (332, 150, 114, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (333, 150, 122, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (336, 81, 153, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (337, 153, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (344, 144, 118, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (345, 150, 118, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (346, 89, 118, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (347, 81, 157, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (479, 81, 183, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (348, 157, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (349, 85, 106, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (350, 106, 85, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (351, 81, 158, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (352, 158, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (353, 81, 159, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (354, 159, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (355, 118, 89, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (356, 150, 89, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (358, 128, 122, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (359, 90, 122, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (360, 88, 122, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (361, 103, 122, 0, 0, NULL);
INSERT INTO `member_friends` VALUES (362, 89, 122, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (363, 150, 91, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (364, 122, 89, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (367, 122, 90, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (368, 81, 161, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (369, 161, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (370, 81, 163, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (371, 163, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (372, 97, 163, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (373, 81, 164, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (374, 164, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (375, 91, 164, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (376, 90, 164, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (377, 89, 164, 0, 0, NULL);
INSERT INTO `member_friends` VALUES (378, 86, 164, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (379, 88, 164, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (380, 85, 164, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (381, 106, 164, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (382, 164, 85, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (383, 128, 86, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (384, 150, 86, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (385, 164, 86, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (386, 164, 91, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (387, 164, 163, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (388, 164, 90, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (389, 164, 90, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (390, 81, 165, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (391, 165, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (392, 165, 165, 0, 0, NULL);
INSERT INTO `member_friends` VALUES (393, 90, 163, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (394, 91, 163, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (395, 89, 163, 0, 0, NULL);
INSERT INTO `member_friends` VALUES (396, 88, 163, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (397, 108, 163, 0, 0, NULL);
INSERT INTO `member_friends` VALUES (398, 94, 163, 0, 0, NULL);
INSERT INTO `member_friends` VALUES (399, 100, 163, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (400, 163, 90, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (401, 163, 91, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (402, 122, 88, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (403, 164, 88, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (404, 163, 88, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (405, 164, 122, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (406, 128, 164, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (407, 139, 164, 0, 0, NULL);
INSERT INTO `member_friends` VALUES (408, 163, 97, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (409, 94, 97, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (410, 96, 97, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (411, 100, 97, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (412, 91, 97, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (413, 163, 118, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (414, 163, 100, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (415, 97, 91, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (416, 164, 97, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (622, 81, 251, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (418, 89, 97, 0, 0, NULL);
INSERT INTO `member_friends` VALUES (419, 164, 128, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (621, 250, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (620, 81, 250, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (633, 255, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (427, 118, 163, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (632, 81, 255, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (429, 81, 168, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (430, 168, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (431, 81, 169, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (432, 169, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (433, 81, 170, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (434, 170, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (435, 81, 171, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (436, 171, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (437, 171, 91, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (438, 90, 171, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (439, 103, 171, 0, 0, NULL);
INSERT INTO `member_friends` VALUES (440, 89, 171, 0, 0, NULL);
INSERT INTO `member_friends` VALUES (591, 206, 85, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (442, 88, 171, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (443, 86, 171, 0, 0, NULL);
INSERT INTO `member_friends` VALUES (444, 106, 171, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (445, 81, 173, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (446, 173, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (447, 81, 174, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (448, 174, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (449, 81, 175, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (450, 175, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (451, 81, 176, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (452, 176, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (453, 81, 177, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (454, 177, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (455, 81, 178, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (456, 178, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (457, 81, 179, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (458, 179, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (459, 173, 85, 0, 0, NULL);
INSERT INTO `member_friends` VALUES (460, 86, 91, 0, 0, NULL);
INSERT INTO `member_friends` VALUES (461, 81, 180, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (462, 180, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (463, 81, 181, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (464, 181, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (465, 94, 91, 0, 0, NULL);
INSERT INTO `member_friends` VALUES (466, 122, 91, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (467, 118, 91, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (468, 114, 91, 0, 0, NULL);
INSERT INTO `member_friends` VALUES (469, 106, 91, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (470, 177, 91, 0, 0, NULL);
INSERT INTO `member_friends` VALUES (471, 81, 182, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (472, 182, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (480, 183, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (481, 81, 184, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (482, 184, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (483, 81, 185, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (484, 185, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (485, 81, 186, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (486, 186, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (487, 81, 187, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (488, 187, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (489, 81, 188, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (490, 188, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (491, 81, 189, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (492, 189, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (493, 81, 190, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (494, 190, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (495, 81, 191, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (496, 191, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (497, 81, 192, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (498, 192, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (499, 81, 193, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (500, 193, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (501, 81, 194, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (502, 194, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (503, 81, 195, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (504, 195, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (505, 81, 196, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (506, 196, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (507, 81, 197, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (508, 197, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (509, 81, 198, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (510, 198, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (511, 81, 199, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (512, 199, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (513, 81, 200, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (514, 200, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (515, 81, 201, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (516, 201, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (517, 81, 202, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (518, 202, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (519, 81, 203, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (520, 203, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (521, 81, 204, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (522, 204, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (523, 81, 205, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (524, 205, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (525, 81, 206, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (526, 206, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (527, 81, 207, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (528, 207, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (529, 96, 206, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (530, 81, 208, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (531, 208, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (534, 81, 210, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (535, 210, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (536, 81, 211, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (537, 211, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (538, 81, 212, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (539, 212, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (540, 81, 213, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (541, 213, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (542, 81, 214, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (543, 214, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (544, 81, 215, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (545, 215, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (546, 81, 216, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (547, 216, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (548, 81, 217, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (549, 217, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (550, 81, 218, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (551, 218, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (552, 81, 219, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (553, 219, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (554, 81, 220, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (555, 220, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (556, 81, 221, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (557, 221, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (558, 81, 222, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (559, 222, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (560, 81, 223, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (561, 223, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (562, 81, 224, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (563, 224, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (564, 81, 225, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (565, 225, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (569, 227, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (568, 81, 227, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (570, 211, 163, 0, 0, NULL);
INSERT INTO `member_friends` VALUES (571, 81, 228, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (572, 228, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (573, 81, 229, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (574, 229, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (575, 81, 230, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (576, 230, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (577, 81, 231, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (578, 231, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (579, 81, 232, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (580, 232, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (581, 81, 233, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (582, 233, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (583, 81, 234, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (584, 234, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (585, 81, 235, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (586, 235, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (587, 81, 236, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (588, 236, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (589, 81, 237, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (590, 237, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (594, 235, 85, 0, 0, NULL);
INSERT INTO `member_friends` VALUES (595, 81, 239, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (596, 239, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (597, 81, 240, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (598, 240, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (599, 81, 241, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (600, 241, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (601, 81, 242, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (602, 242, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (603, 81, 243, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (604, 243, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (605, 81, 244, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (606, 244, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (607, 211, 91, 0, 0, NULL);
INSERT INTO `member_friends` VALUES (608, 88, 106, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (609, 81, 245, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (610, 245, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (611, 81, 246, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (612, 246, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (616, 81, 248, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (615, 211, 85, 0, 0, NULL);
INSERT INTO `member_friends` VALUES (617, 248, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (618, 81, 249, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (619, 249, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (625, 235, 91, 0, 0, NULL);
INSERT INTO `member_friends` VALUES (626, 81, 252, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (627, 252, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (628, 81, 253, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (629, 253, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (630, 81, 254, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (631, 254, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (636, 81, 257, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (637, 257, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (638, 81, 258, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (639, 258, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (640, 81, 259, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (641, 259, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (642, 81, 260, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (643, 260, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (644, 81, 261, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (645, 261, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (646, 97, 118, 0, 0, NULL);
INSERT INTO `member_friends` VALUES (647, 81, 262, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (648, 262, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (649, 81, 263, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (650, 263, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (651, 81, 264, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (652, 264, 81, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (654, 81, 265, 1, 0, NULL);
INSERT INTO `member_friends` VALUES (655, 265, 81, 1, 0, NULL);

-- --------------------------------------------------------

-- 
-- Table structure for table `member_networking`
-- 

CREATE TABLE `member_networking` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `member_id` int(10) NOT NULL default '0',
  `field` varchar(255) NOT NULL default '',
  `sub_field` varchar(255) NOT NULL default '',
  `role` varchar(255) NOT NULL default '',
  `description` blob NOT NULL,
  PRIMARY KEY  (`id`)
) TYPE=MyISAM  AUTO_INCREMENT=8 ;

-- 
-- Dumping data for table `member_networking`
-- 

INSERT INTO `member_networking` VALUES (6, 91, '', '', '', 0x3c6469762069643d5c27766964656f5c27207374796c653d5c2777696474683a33303070785c273e3c623e3c6120687265663d5c27687474703a2f2f7777772e6d797370616365766964656f636f64652e636f6d2f6172746973742f536e6f6f70253230446f67672f5c273e536e6f6f7020446f67673c2f613e202d203c6120687265663d5c27687474703a2f2f7777772e6d797370616365766964656f636f64652e636f6d2f536e6f6f702d446f67672f33353734312d42697463682d506c656173652f5c273e426974636820506c656173653c2f613e3c2f623e3c62723e3c6120687265663d5c27687474703a2f2f7777772e6d797370616365766964656f636f64652e636f6d5c273e3c656d626564206e616d653d5c274d795370616365566964656f436f64655c27207372633d5c27687474703a2f2f7777772e6d797370616365766964656f636f64652e636f6d2f6173782f33353734312e6173785c2720747970653d5c276170706c69636174696f6e2f782d6d706c61796572325c272077696474683d5c273330305c27206865696768743d5c273330305c272053686f77436f6e74726f6c733d5c27315c272053686f775374617475734261723d5c27305c27206c6f6f703d5c27747275655c2720456e61626c65436f6e746578744d656e753d5c27305c2720446973706c617953697a653d5c27305c2720706c7567696e73706167653d5c27687474703a2f2f7777772e6d6963726f736f66742e636f6d2f57696e646f77732f446f776e6c6f6164732f436f6e74656e74732f50726f64756374732f4d65646961506c617965722f5c273e3c2f656d6265643e3c2f613e3c63656e7465723e3c666f6e74207374796c653d5c27666f6e742d73697a653a20313070743b5c273e3c6120687265663d5c27687474703a2f2f7777772e6d797370616365766964656f636f64652e636f6d5c273e566964656f20436f64653c2f613e206279203c6120687265663d5c27687474703a2f2f7777772e6d797370616365766964656f636f64652e636f6d5c273e4d79537061636520566964656f20436f64653c2f613e3c2f666f6e743e3c2f63656e7465723e);
INSERT INTO `member_networking` VALUES (7, 1234, 'student', 'son', 'son', 0x695c276d206120736f6e207468415420495320414c534f20412053545544454e54204154205343484f4f4c);

-- --------------------------------------------------------

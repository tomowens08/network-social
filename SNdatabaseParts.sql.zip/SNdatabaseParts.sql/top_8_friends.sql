-- --------------------------------------------------------

-- 
-- Table structure for table `top_8_friends`
-- 

CREATE TABLE `top_8_friends` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `member_id` int(10) NOT NULL default '0',
  `friend_id` int(10) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) TYPE=MyISAM  AUTO_INCREMENT=5 ;

-- 
-- Dumping data for table `top_8_friends`
-- 

INSERT INTO `top_8_friends` VALUES (1, 93, 91);
INSERT INTO `top_8_friends` VALUES (2, 25, 92);
INSERT INTO `top_8_friends` VALUES (3, 25, 94);
INSERT INTO `top_8_friends` VALUES (4, 25, 95);

-- --------------------------------------------------------

-- 
-- Table structure for table `video_albums`
-- 

CREATE TABLE `video_albums` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `album_title` varchar(255) NOT NULL default '',
  `album_desc` blob NOT NULL,
  `album_type` varchar(10) NOT NULL default '',
  `member_id` int(10) NOT NULL default '0',
  `posted_on` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`id`)
) TYPE=MyISAM  AUTO_INCREMENT=6 ;

-- 
-- Dumping data for table `video_albums`
-- 

INSERT INTO `video_albums` VALUES (2, 'asd', 0x616473, '1', 25, '05-01-2006 9:28:17');
INSERT INTO `video_albums` VALUES (4, 'Test', 0x54657374, '', 106, '06-18-2006 3:19:53');
INSERT INTO `video_albums` VALUES (5, 'Comedy', 0x436f6d656479, '1', 342, '08-30-2006 12:59:26');

-- --------------------------------------------------------

-- 
-- Table structure for table `video_category`
-- 

CREATE TABLE `video_category` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `cat_name` varchar(255) NOT NULL default '',
  `cat_desc` blob NOT NULL,
  PRIMARY KEY  (`id`)
) TYPE=MyISAM  AUTO_INCREMENT=26 ;

-- 
-- Dumping data for table `video_category`
-- 

INSERT INTO `video_category` VALUES (1, 'Animals', 0x416e696d616c73);
INSERT INTO `video_category` VALUES (2, 'Animation', 0x416e696d6174696f6e);
INSERT INTO `video_category` VALUES (3, 'Automotive', 0x4175746f6d6f74697665);
INSERT INTO `video_category` VALUES (4, 'Business/Advertising', 0x427573696e6573732f4164766572746973696e67);
INSERT INTO `video_category` VALUES (5, 'Comedy', 0x436f6d656479);
INSERT INTO `video_category` VALUES (6, 'Cooking', 0x436f6f6b696e67);
INSERT INTO `video_category` VALUES (7, 'Educational', 0x456475636174696f6e616c);
INSERT INTO `video_category` VALUES (8, 'Extreme Video', 0x45787472656d6520566964656f);
INSERT INTO `video_category` VALUES (9, 'Family', 0x46616d696c79);
INSERT INTO `video_category` VALUES (10, 'Funny Commercial', 0x46756e6e7920436f6d6d65726369616c);
INSERT INTO `video_category` VALUES (11, 'Hot Female', 0x486f742046656d616c65);
INSERT INTO `video_category` VALUES (12, 'Hot Male', 0x486f74204d616c65);
INSERT INTO `video_category` VALUES (13, 'Independent Film', 0x496e646570656e64656e742046696c6d);
INSERT INTO `video_category` VALUES (14, 'Instructional', 0x496e737472756374696f6e616c);
INSERT INTO `video_category` VALUES (15, 'Kids', 0x4b696473);
INSERT INTO `video_category` VALUES (16, 'Music Video', 0x4d7573696320566964656f);
INSERT INTO `video_category` VALUES (17, 'My Vacation/Vacation Spots', 0x4d79205661636174696f6e2f5661636174696f6e2053706f7473);
INSERT INTO `video_category` VALUES (18, 'Natural Wonders', 0x4e61747572616c20576f6e64657273);
INSERT INTO `video_category` VALUES (19, 'News', 0x4e657773);
INSERT INTO `video_category` VALUES (20, 'Party', 0x5061727479);
INSERT INTO `video_category` VALUES (21, 'Real Estate', 0x5265616c20457374617465);
INSERT INTO `video_category` VALUES (22, 'Real-Life Video', 0x5265616c2d4c69666520566964656f);
INSERT INTO `video_category` VALUES (23, 'School', 0x5363686f6f6c);
INSERT INTO `video_category` VALUES (24, 'Sports', 0x53706f727473);
INSERT INTO `video_category` VALUES (25, 'Video Blog', 0x566964656f20426c6f67);

-- --------------------------------------------------------

-- 
-- Table structure for table `video_comments`
-- 

CREATE TABLE `video_comments` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `video_id` int(10) NOT NULL default '0',
  `posted_on` varchar(255) NOT NULL default '',
  `mood` varchar(255) NOT NULL default '',
  `rate` int(10) NOT NULL default '0',
  `comment` blob NOT NULL,
  `recommend` varchar(10) NOT NULL default '',
  `posted_by` int(10) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) TYPE=MyISAM  AUTO_INCREMENT=3 ;

-- 
-- Dumping data for table `video_comments`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `video_favorite`
-- 

CREATE TABLE `video_favorite` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `member_id` int(10) NOT NULL default '0',
  `video_id` int(10) NOT NULL default '0',
  `posted_on` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`id`)
) TYPE=MyISAM  AUTO_INCREMENT=3 ;

-- 
-- Dumping data for table `video_favorite`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `video_members`
-- 

CREATE TABLE `video_members` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `video_album` int(10) NOT NULL default '0',
  `video_file` varchar(255) NOT NULL default '',
  `video_thumbnail` varchar(255) NOT NULL default '',
  `video_cat` int(10) NOT NULL default '0',
  `video_title` varchar(255) NOT NULL default '',
  `video_caption` varchar(255) NOT NULL default '',
  `video_tags` blob NOT NULL,
  `video_type` varchar(10) NOT NULL default '',
  `video_codes_allow` varchar(10) NOT NULL default '1',
  `member_id` int(10) NOT NULL default '0',
  `posted_on` varchar(255) NOT NULL default '',
  `views` int(10) NOT NULL default '0',
  `asx_file` varchar(255) NOT NULL default '',
  `upload_ip` varchar(255) NOT NULL default '',
  `total_comments` int(10) NOT NULL default '0',
  `total_favorite` int(10) NOT NULL default '0',
  `last_viewed` int(10) NOT NULL default '0',
  `featured` varchar(10) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) TYPE=MyISAM  AUTO_INCREMENT=11 ;

-- 
-- Dumping data for table `video_members`
-- 

INSERT INTO `video_members` VALUES (10, 5, 'videos/2006/342-10.wmv', 'videos/2006/342-10.jpg', 5, 'Comedy', '', 0x636f6d656479, '1', '1', 342, '09-01-2006 8:03:06', 62, 'videos/2006/342-10.asx', '69.251.1.0', 0, 0, 1307, '0');

-- --------------------------------------------------------

-- 
-- Table structure for table `video_playlist`
-- 

CREATE TABLE `video_playlist` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `member_id` int(10) NOT NULL default '0',
  `video_id` int(10) NOT NULL default '0',
  `posted_on` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`id`)
) TYPE=MyISAM  AUTO_INCREMENT=3 ;


 -- --------------------------------------------------------

-- 
-- Table structure for table `admin_control`
-- 

CREATE TABLE `admin_control` (
  `admin_id` int(10) unsigned NOT NULL auto_increment,
  `invite_message` blob,
  UNIQUE KEY `admin_id` (`admin_id`)
) TYPE=MyISAM  AUTO_INCREMENT = 2 ;

-- 
-- Dumping data for table `admin_control`
-- 

INSERT INTO `admin_control` (`admin_id`, `invite_message`) VALUES 
(1, '');

-- --------------------------------------------------------

 
-- --------------------------------------------------------

-- 
-- Table structure for table `misc`
-- 

CREATE TABLE `misc` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `invite_only` varchar(10) NOT NULL default '1',
  `default_friend_profile` int(10) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) TYPE=MyISAM  AUTO_INCREMENT=2 ;

-- 
-- Dumping data for table `misc`
-- 

INSERT INTO `misc` VALUES (1, '0', 81);

-- --------------------------------------------------------

-- 
-- Table structure for table `moderators_classified`
-- 

CREATE TABLE `moderators_classified` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `member_id` int(10) NOT NULL default '0',
  `added_on` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`id`)
) TYPE=MyISAM  AUTO_INCREMENT=4 ;

-- 
-- Dumping data for table `moderators_classified`
-- 

INSERT INTO `moderators_classified` VALUES (3, 81, '08-30-2006 11:22:12');

-- --------------------------------------------------------

-- 
-- Table structure for table `moderators_events`
-- 

CREATE TABLE `moderators_events` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `member_id` int(10) NOT NULL default '0',
  `added_on` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`id`)
) TYPE=MyISAM  AUTO_INCREMENT=5 ;

-- 
-- Dumping data for table `moderators_events`
-- 

INSERT INTO `moderators_events` VALUES (4, 81, '08-30-2006 11:21:39');

-- --------------------------------------------------------

-- 
-- Table structure for table `moderators_groups`
-- 

CREATE TABLE `moderators_groups` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `member_id` int(10) NOT NULL default '0',
  `added_on` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`id`)
) TYPE=MyISAM  AUTO_INCREMENT=3 ;

-- 
-- Dumping data for table `moderators_groups`
-- 

INSERT INTO `moderators_groups` VALUES (2, 81, '08-30-2006 11:21:11');

-- --------------------------------------------------------

-- 
-- Table structure for table `moderators_music`
-- 

CREATE TABLE `moderators_music` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `member_id` int(10) NOT NULL default '0',
  `added_on` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`id`)
) TYPE=MyISAM  AUTO_INCREMENT=2 ;

-- 
-- Dumping data for table `moderators_music`
-- 

INSERT INTO `moderators_music` VALUES (1, 106, '06-09-2006 9:18:12');

-- --------------------------------------------------------

-- 
-- Table structure for table `moderators_pics`
-- 

CREATE TABLE `moderators_pics` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `member_id` int(10) NOT NULL default '0',
  `added_on` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`id`)
) TYPE=MyISAM  AUTO_INCREMENT=3 ;

-- 
-- Dumping data for table `moderators_pics`
-- 

INSERT INTO `moderators_pics` VALUES (2, 81, '08-30-2006 11:20:15');

-- --------------------------------------------------------

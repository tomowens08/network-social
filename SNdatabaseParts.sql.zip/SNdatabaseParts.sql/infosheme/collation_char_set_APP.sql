-- 
-- Table structure for table `COLLATION_CHARACTER_SET_APPLICABILITY`
-- 

CREATE TEMPORARY TABLE `COLLATION_CHARACTER_SET_APPLICABILITY` (
  `COLLATION_NAME` varchar(64) NOT NULL default '',
  `CHARACTER_SET_NAME` varchar(64) NOT NULL default ''
) TYPE=MEMORY ;

-- 
-- Dumping data for table `COLLATION_CHARACTER_SET_APPLICABILITY`
-- 

INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES ('big5_chinese_ci', 'big5');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES ('big5_bin', 'big5');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES ('dec8_swedish_ci', 'dec8');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES ('dec8_bin', 'dec8');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES ('cp850_general_ci', 'cp850');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES ('cp850_bin', 'cp850');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES ('hp8_english_ci', 'hp8');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES ('hp8_bin', 'hp8');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES ('koi8r_general_ci', 'koi8r');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES ('koi8r_bin', 'koi8r');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES ('latin1_german1_ci', 'latin1');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES ('latin1_swedish_ci', 'latin1');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES ('latin1_danish_ci', 'latin1');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES ('latin1_german2_ci', 'latin1');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES ('latin1_bin', 'latin1');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES ('latin1_general_ci', 'latin1');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES ('latin1_general_cs', 'latin1');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES ('latin1_spanish_ci', 'latin1');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES ('latin2_czech_cs', 'latin2');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES ('latin2_general_ci', 'latin2');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES ('latin2_hungarian_ci', 'latin2');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES ('latin2_croatian_ci', 'latin2');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES ('latin2_bin', 'latin2');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES ('swe7_swedish_ci', 'swe7');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES ('swe7_bin', 'swe7');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES ('ascii_general_ci', 'ascii');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES ('ascii_bin', 'ascii');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES ('ujis_japanese_ci', 'ujis');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES ('ujis_bin', 'ujis');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES ('sjis_japanese_ci', 'sjis');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES ('sjis_bin', 'sjis');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES ('hebrew_general_ci', 'hebrew');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES ('hebrew_bin', 'hebrew');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES ('tis620_thai_ci', 'tis620');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES ('tis620_bin', 'tis620');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES ('euckr_korean_ci', 'euckr');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES ('euckr_bin', 'euckr');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES ('koi8u_general_ci', 'koi8u');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES ('koi8u_bin', 'koi8u');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES ('gb2312_chinese_ci', 'gb2312');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES ('gb2312_bin', 'gb2312');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES ('greek_general_ci', 'greek');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES ('greek_bin', 'greek');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES ('cp1250_general_ci', 'cp1250');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES ('cp1250_czech_cs', 'cp1250');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES ('cp1250_croatian_ci', 'cp1250');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES ('cp1250_bin', 'cp1250');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES ('gbk_chinese_ci', 'gbk');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES ('gbk_bin', 'gbk');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES ('latin5_turkish_ci', 'latin5');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES ('latin5_bin', 'latin5');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES ('armscii8_general_ci', 'armscii8');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES ('armscii8_bin', 'armscii8');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES ('utf8_general_ci', 'utf8');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES ('utf8_bin', 'utf8');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES ('utf8_unicode_ci', 'utf8');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES ('utf8_icelandic_ci', 'utf8');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES ('utf8_latvian_ci', 'utf8');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES ('utf8_romanian_ci', 'utf8');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES ('utf8_slovenian_ci', 'utf8');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES ('utf8_polish_ci', 'utf8');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES ('utf8_estonian_ci', 'utf8');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES ('utf8_spanish_ci', 'utf8');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES ('utf8_swedish_ci', 'utf8');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES ('utf8_turkish_ci', 'utf8');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES ('utf8_czech_ci', 'utf8');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES ('utf8_danish_ci', 'utf8');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES ('utf8_lithuanian_ci', 'utf8');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES ('utf8_slovak_ci', 'utf8');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES ('utf8_spanish2_ci', 'utf8');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES ('utf8_roman_ci', 'utf8');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES ('utf8_persian_ci', 'utf8');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES ('utf8_esperanto_ci', 'utf8');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES ('utf8_hungarian_ci', 'utf8');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES ('ucs2_general_ci', 'ucs2');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES ('ucs2_bin', 'ucs2');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES ('ucs2_unicode_ci', 'ucs2');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES ('ucs2_icelandic_ci', 'ucs2');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES ('ucs2_latvian_ci', 'ucs2');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES ('ucs2_romanian_ci', 'ucs2');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES ('ucs2_slovenian_ci', 'ucs2');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES ('ucs2_polish_ci', 'ucs2');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES ('ucs2_estonian_ci', 'ucs2');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES ('ucs2_spanish_ci', 'ucs2');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES ('ucs2_swedish_ci', 'ucs2');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES ('ucs2_turkish_ci', 'ucs2');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES ('ucs2_czech_ci', 'ucs2');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES ('ucs2_danish_ci', 'ucs2');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES ('ucs2_lithuanian_ci', 'ucs2');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES ('ucs2_slovak_ci', 'ucs2');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES ('ucs2_spanish2_ci', 'ucs2');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES ('ucs2_roman_ci', 'ucs2');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES ('ucs2_persian_ci', 'ucs2');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES ('ucs2_esperanto_ci', 'ucs2');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES ('ucs2_hungarian_ci', 'ucs2');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES ('cp866_general_ci', 'cp866');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES ('cp866_bin', 'cp866');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES ('keybcs2_general_ci', 'keybcs2');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES ('keybcs2_bin', 'keybcs2');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES ('macce_general_ci', 'macce');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES ('macce_bin', 'macce');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES ('macroman_general_ci', 'macroman');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES ('macroman_bin', 'macroman');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES ('cp852_general_ci', 'cp852');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES ('cp852_bin', 'cp852');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES ('latin7_estonian_cs', 'latin7');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES ('latin7_general_ci', 'latin7');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES ('latin7_general_cs', 'latin7');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES ('latin7_bin', 'latin7');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES ('cp1251_bulgarian_ci', 'cp1251');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES ('cp1251_ukrainian_ci', 'cp1251');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES ('cp1251_bin', 'cp1251');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES ('cp1251_general_ci', 'cp1251');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES ('cp1251_general_cs', 'cp1251');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES ('cp1256_general_ci', 'cp1256');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES ('cp1256_bin', 'cp1256');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES ('cp1257_lithuanian_ci', 'cp1257');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES ('cp1257_bin', 'cp1257');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES ('cp1257_general_ci', 'cp1257');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES ('binary', 'binary');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES ('geostd8_general_ci', 'geostd8');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES ('geostd8_bin', 'geostd8');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES ('cp932_japanese_ci', 'cp932');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES ('cp932_bin', 'cp932');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES ('eucjpms_japanese_ci', 'eucjpms');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES ('eucjpms_bin', 'eucjpms');

-- --------------------------------------------------------

-- 
-- Table structure for table `COLUMNS`
-- 

CREATE TEMPORARY TABLE `COLUMNS` (
  `TABLE_CATALOG` varchar(512) default NULL,
  `TABLE_SCHEMA` varchar(64) NOT NULL default '',
  `TABLE_NAME` varchar(64) NOT NULL default '',
  `COLUMN_NAME` varchar(64) NOT NULL default '',
  `ORDINAL_POSITION` bigint(21) NOT NULL default '0',
  `COLUMN_DEFAULT` longtext,
  `IS_NULLABLE` varchar(3) NOT NULL default '',
  `DATA_TYPE` varchar(64) NOT NULL default '',
  `CHARACTER_MAXIMUM_LENGTH` bigint(21) default NULL,
  `CHARACTER_OCTET_LENGTH` bigint(21) default NULL,
  `NUMERIC_PRECISION` bigint(21) default NULL,
  `NUMERIC_SCALE` bigint(21) default NULL,
  `CHARACTER_SET_NAME` varchar(64) default NULL,
  `COLLATION_NAME` varchar(64) default NULL,
  `COLUMN_TYPE` longtext NOT NULL,
  `COLUMN_KEY` varchar(3) NOT NULL default '',
  `EXTRA` varchar(20) NOT NULL default '',
  `PRIVILEGES` varchar(80) NOT NULL default '',
  `COLUMN_COMMENT` varchar(255) NOT NULL default ''
) TYPE=MyISAM ;

-- 
-- Dumping data for table `COLUMNS`
-- 

INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'CHARACTER_SETS', 'CHARACTER_SET_NAME', 1, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'CHARACTER_SETS', 'DEFAULT_COLLATE_NAME', 2, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'CHARACTER_SETS', 'DESCRIPTION', 3, '', 'NO', 'varchar', 60, 180, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(60)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'CHARACTER_SETS', 'MAXLEN', 4, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(3)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'COLLATIONS', 'COLLATION_NAME', 1, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'COLLATIONS', 'CHARACTER_SET_NAME', 2, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'COLLATIONS', 'ID', 3, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(11)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'COLLATIONS', 'IS_DEFAULT', 4, '', 'NO', 'varchar', 3, 9, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(3)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'COLLATIONS', 'IS_COMPILED', 5, '', 'NO', 'varchar', 3, 9, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(3)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'COLLATIONS', 'SORTLEN', 6, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(3)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'COLLATION_CHARACTER_SET_APPLICABILITY', 'COLLATION_NAME', 1, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'COLLATION_CHARACTER_SET_APPLICABILITY', 'CHARACTER_SET_NAME', 2, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'COLUMNS', 'TABLE_CATALOG', 1, NULL, 'YES', 'varchar', 512, 1536, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(512)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'COLUMNS', 'TABLE_SCHEMA', 2, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'COLUMNS', 'TABLE_NAME', 3, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'COLUMNS', 'COLUMN_NAME', 4, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'COLUMNS', 'ORDINAL_POSITION', 5, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'COLUMNS', 'COLUMN_DEFAULT', 6, NULL, 'YES', 'longtext', 4294967295, 4294967295, NULL, NULL, 'utf8', 'utf8_general_ci', 'longtext', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'COLUMNS', 'IS_NULLABLE', 7, '', 'NO', 'varchar', 3, 9, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(3)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'COLUMNS', 'DATA_TYPE', 8, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'COLUMNS', 'CHARACTER_MAXIMUM_LENGTH', 9, NULL, 'YES', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'COLUMNS', 'CHARACTER_OCTET_LENGTH', 10, NULL, 'YES', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'COLUMNS', 'NUMERIC_PRECISION', 11, NULL, 'YES', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'COLUMNS', 'NUMERIC_SCALE', 12, NULL, 'YES', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'COLUMNS', 'CHARACTER_SET_NAME', 13, NULL, 'YES', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'COLUMNS', 'COLLATION_NAME', 14, NULL, 'YES', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'COLUMNS', 'COLUMN_TYPE', 15, '', 'NO', 'longtext', 4294967295, 4294967295, NULL, NULL, 'utf8', 'utf8_general_ci', 'longtext', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'COLUMNS', 'COLUMN_KEY', 16, '', 'NO', 'varchar', 3, 9, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(3)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'COLUMNS', 'EXTRA', 17, '', 'NO', 'varchar', 20, 60, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(20)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'COLUMNS', 'PRIVILEGES', 18, '', 'NO', 'varchar', 80, 240, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(80)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'COLUMNS', 'COLUMN_COMMENT', 19, '', 'NO', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'COLUMN_PRIVILEGES', 'GRANTEE', 1, '', 'NO', 'varchar', 81, 243, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(81)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'COLUMN_PRIVILEGES', 'TABLE_CATALOG', 2, NULL, 'YES', 'varchar', 512, 1536, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(512)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'COLUMN_PRIVILEGES', 'TABLE_SCHEMA', 3, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'COLUMN_PRIVILEGES', 'TABLE_NAME', 4, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'COLUMN_PRIVILEGES', 'COLUMN_NAME', 5, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'COLUMN_PRIVILEGES', 'PRIVILEGE_TYPE', 6, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'COLUMN_PRIVILEGES', 'IS_GRANTABLE', 7, '', 'NO', 'varchar', 3, 9, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(3)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'KEY_COLUMN_USAGE', 'CONSTRAINT_CATALOG', 1, NULL, 'YES', 'varchar', 512, 1536, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(512)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'KEY_COLUMN_USAGE', 'CONSTRAINT_SCHEMA', 2, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'KEY_COLUMN_USAGE', 'CONSTRAINT_NAME', 3, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'KEY_COLUMN_USAGE', 'TABLE_CATALOG', 4, NULL, 'YES', 'varchar', 512, 1536, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(512)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'KEY_COLUMN_USAGE', 'TABLE_SCHEMA', 5, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'KEY_COLUMN_USAGE', 'TABLE_NAME', 6, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'KEY_COLUMN_USAGE', 'COLUMN_NAME', 7, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'KEY_COLUMN_USAGE', 'ORDINAL_POSITION', 8, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(10)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'KEY_COLUMN_USAGE', 'POSITION_IN_UNIQUE_CONSTRAINT', 9, NULL, 'YES', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(10)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'KEY_COLUMN_USAGE', 'REFERENCED_TABLE_SCHEMA', 10, NULL, 'YES', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'KEY_COLUMN_USAGE', 'REFERENCED_TABLE_NAME', 11, NULL, 'YES', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'KEY_COLUMN_USAGE', 'REFERENCED_COLUMN_NAME', 12, NULL, 'YES', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'PROFILING', 'QUERY_ID', 1, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(20)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'PROFILING', 'SEQ', 2, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(20)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'PROFILING', 'STATE', 3, '', 'NO', 'varchar', 30, 90, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(30)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'PROFILING', 'DURATION', 4, '', 'NO', 'varchar', 9, 27, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(9)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'PROFILING', 'CPU_USER', 5, NULL, 'YES', 'varchar', 9, 27, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(9)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'PROFILING', 'CPU_SYSTEM', 6, NULL, 'YES', 'varchar', 9, 27, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(9)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'PROFILING', 'CONTEXT_VOLUNTARY', 7, NULL, 'YES', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(20)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'PROFILING', 'CONTEXT_INVOLUNTARY', 8, NULL, 'YES', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(20)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'PROFILING', 'BLOCK_OPS_IN', 9, NULL, 'YES', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(20)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'PROFILING', 'BLOCK_OPS_OUT', 10, NULL, 'YES', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(20)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'PROFILING', 'MESSAGES_SENT', 11, NULL, 'YES', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(20)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'PROFILING', 'MESSAGES_RECEIVED', 12, NULL, 'YES', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(20)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'PROFILING', 'PAGE_FAULTS_MAJOR', 13, NULL, 'YES', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(20)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'PROFILING', 'PAGE_FAULTS_MINOR', 14, NULL, 'YES', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(20)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'PROFILING', 'SWAPS', 15, NULL, 'YES', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(20)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'PROFILING', 'SOURCE_FUNCTION', 16, NULL, 'YES', 'varchar', 30, 90, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(30)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'PROFILING', 'SOURCE_FILE', 17, NULL, 'YES', 'varchar', 20, 60, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(20)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'PROFILING', 'SOURCE_LINE', 18, NULL, 'YES', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(20)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'ROUTINES', 'SPECIFIC_NAME', 1, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'ROUTINES', 'ROUTINE_CATALOG', 2, NULL, 'YES', 'varchar', 512, 1536, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(512)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'ROUTINES', 'ROUTINE_SCHEMA', 3, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'ROUTINES', 'ROUTINE_NAME', 4, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'ROUTINES', 'ROUTINE_TYPE', 5, '', 'NO', 'varchar', 9, 27, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(9)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'ROUTINES', 'DTD_IDENTIFIER', 6, NULL, 'YES', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'ROUTINES', 'ROUTINE_BODY', 7, '', 'NO', 'varchar', 8, 24, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(8)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'ROUTINES', 'ROUTINE_DEFINITION', 8, NULL, 'YES', 'longtext', 4294967295, 4294967295, NULL, NULL, 'utf8', 'utf8_general_ci', 'longtext', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'ROUTINES', 'EXTERNAL_NAME', 9, NULL, 'YES', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'ROUTINES', 'EXTERNAL_LANGUAGE', 10, NULL, 'YES', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'ROUTINES', 'PARAMETER_STYLE', 11, '', 'NO', 'varchar', 8, 24, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(8)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'ROUTINES', 'IS_DETERMINISTIC', 12, '', 'NO', 'varchar', 3, 9, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(3)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'ROUTINES', 'SQL_DATA_ACCESS', 13, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'ROUTINES', 'SQL_PATH', 14, NULL, 'YES', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'ROUTINES', 'SECURITY_TYPE', 15, '', 'NO', 'varchar', 7, 21, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(7)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'ROUTINES', 'CREATED', 16, '0000-00-00 00:00:00', 'NO', 'datetime', NULL, NULL, NULL, NULL, NULL, NULL, 'datetime', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'ROUTINES', 'LAST_ALTERED', 17, '0000-00-00 00:00:00', 'NO', 'datetime', NULL, NULL, NULL, NULL, NULL, NULL, 'datetime', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'ROUTINES', 'SQL_MODE', 18, '', 'NO', 'longtext', 4294967295, 4294967295, NULL, NULL, 'utf8', 'utf8_general_ci', 'longtext', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'ROUTINES', 'ROUTINE_COMMENT', 19, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'ROUTINES', 'DEFINER', 20, '', 'NO', 'varchar', 77, 231, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(77)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'SCHEMATA', 'CATALOG_NAME', 1, NULL, 'YES', 'varchar', 512, 1536, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(512)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'SCHEMATA', 'SCHEMA_NAME', 2, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'SCHEMATA', 'DEFAULT_CHARACTER_SET_NAME', 3, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'SCHEMATA', 'DEFAULT_COLLATION_NAME', 4, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'SCHEMATA', 'SQL_PATH', 5, NULL, 'YES', 'varchar', 512, 1536, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(512)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'SCHEMA_PRIVILEGES', 'GRANTEE', 1, '', 'NO', 'varchar', 81, 243, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(81)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'SCHEMA_PRIVILEGES', 'TABLE_CATALOG', 2, NULL, 'YES', 'varchar', 512, 1536, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(512)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'SCHEMA_PRIVILEGES', 'TABLE_SCHEMA', 3, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'SCHEMA_PRIVILEGES', 'PRIVILEGE_TYPE', 4, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'SCHEMA_PRIVILEGES', 'IS_GRANTABLE', 5, '', 'NO', 'varchar', 3, 9, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(3)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'STATISTICS', 'TABLE_CATALOG', 1, NULL, 'YES', 'varchar', 512, 1536, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(512)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'STATISTICS', 'TABLE_SCHEMA', 2, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'STATISTICS', 'TABLE_NAME', 3, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'STATISTICS', 'NON_UNIQUE', 4, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(1)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'STATISTICS', 'INDEX_SCHEMA', 5, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'STATISTICS', 'INDEX_NAME', 6, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'STATISTICS', 'SEQ_IN_INDEX', 7, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(2)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'STATISTICS', 'COLUMN_NAME', 8, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'STATISTICS', 'COLLATION', 9, NULL, 'YES', 'varchar', 1, 3, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(1)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'STATISTICS', 'CARDINALITY', 10, NULL, 'YES', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'STATISTICS', 'SUB_PART', 11, NULL, 'YES', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(3)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'STATISTICS', 'PACKED', 12, NULL, 'YES', 'varchar', 10, 30, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(10)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'STATISTICS', 'NULLABLE', 13, '', 'NO', 'varchar', 3, 9, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(3)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'STATISTICS', 'INDEX_TYPE', 14, '', 'NO', 'varchar', 16, 48, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(16)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'STATISTICS', 'COMMENT', 15, NULL, 'YES', 'varchar', 16, 48, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(16)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'TABLES', 'TABLE_CATALOG', 1, NULL, 'YES', 'varchar', 512, 1536, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(512)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'TABLES', 'TABLE_SCHEMA', 2, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'TABLES', 'TABLE_NAME', 3, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'TABLES', 'TABLE_TYPE', 4, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'TABLES', 'ENGINE', 5, NULL, 'YES', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'TABLES', 'VERSION', 6, NULL, 'YES', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'TABLES', 'ROW_FORMAT', 7, NULL, 'YES', 'varchar', 10, 30, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(10)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'TABLES', 'TABLE_ROWS', 8, NULL, 'YES', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'TABLES', 'AVG_ROW_LENGTH', 9, NULL, 'YES', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'TABLES', 'DATA_LENGTH', 10, NULL, 'YES', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'TABLES', 'MAX_DATA_LENGTH', 11, NULL, 'YES', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'TABLES', 'INDEX_LENGTH', 12, NULL, 'YES', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'TABLES', 'DATA_FREE', 13, NULL, 'YES', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'TABLES', 'AUTO_INCREMENT', 14, NULL, 'YES', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'TABLES', 'CREATE_TIME', 15, NULL, 'YES', 'datetime', NULL, NULL, NULL, NULL, NULL, NULL, 'datetime', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'TABLES', 'UPDATE_TIME', 16, NULL, 'YES', 'datetime', NULL, NULL, NULL, NULL, NULL, NULL, 'datetime', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'TABLES', 'CHECK_TIME', 17, NULL, 'YES', 'datetime', NULL, NULL, NULL, NULL, NULL, NULL, 'datetime', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'TABLES', 'TABLE_COLLATION', 18, NULL, 'YES', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'TABLES', 'CHECKSUM', 19, NULL, 'YES', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'TABLES', 'CREATE_OPTIONS', 20, NULL, 'YES', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'TABLES', 'TABLE_COMMENT', 21, '', 'NO', 'varchar', 80, 240, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(80)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'TABLE_CONSTRAINTS', 'CONSTRAINT_CATALOG', 1, NULL, 'YES', 'varchar', 512, 1536, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(512)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'TABLE_CONSTRAINTS', 'CONSTRAINT_SCHEMA', 2, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'TABLE_CONSTRAINTS', 'CONSTRAINT_NAME', 3, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'TABLE_CONSTRAINTS', 'TABLE_SCHEMA', 4, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'TABLE_CONSTRAINTS', 'TABLE_NAME', 5, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'TABLE_CONSTRAINTS', 'CONSTRAINT_TYPE', 6, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'TABLE_PRIVILEGES', 'GRANTEE', 1, '', 'NO', 'varchar', 81, 243, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(81)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'TABLE_PRIVILEGES', 'TABLE_CATALOG', 2, NULL, 'YES', 'varchar', 512, 1536, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(512)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'TABLE_PRIVILEGES', 'TABLE_SCHEMA', 3, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'TABLE_PRIVILEGES', 'TABLE_NAME', 4, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'TABLE_PRIVILEGES', 'PRIVILEGE_TYPE', 5, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'TABLE_PRIVILEGES', 'IS_GRANTABLE', 6, '', 'NO', 'varchar', 3, 9, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(3)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'TRIGGERS', 'TRIGGER_CATALOG', 1, NULL, 'YES', 'varchar', 512, 1536, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(512)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'TRIGGERS', 'TRIGGER_SCHEMA', 2, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'TRIGGERS', 'TRIGGER_NAME', 3, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'TRIGGERS', 'EVENT_MANIPULATION', 4, '', 'NO', 'varchar', 6, 18, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(6)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'TRIGGERS', 'EVENT_OBJECT_CATALOG', 5, NULL, 'YES', 'varchar', 512, 1536, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(512)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'TRIGGERS', 'EVENT_OBJECT_SCHEMA', 6, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'TRIGGERS', 'EVENT_OBJECT_TABLE', 7, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'TRIGGERS', 'ACTION_ORDER', 8, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(4)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'TRIGGERS', 'ACTION_CONDITION', 9, NULL, 'YES', 'longtext', 4294967295, 4294967295, NULL, NULL, 'utf8', 'utf8_general_ci', 'longtext', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'TRIGGERS', 'ACTION_STATEMENT', 10, '', 'NO', 'longtext', 4294967295, 4294967295, NULL, NULL, 'utf8', 'utf8_general_ci', 'longtext', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'TRIGGERS', 'ACTION_ORIENTATION', 11, '', 'NO', 'varchar', 9, 27, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(9)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'TRIGGERS', 'ACTION_TIMING', 12, '', 'NO', 'varchar', 6, 18, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(6)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'TRIGGERS', 'ACTION_REFERENCE_OLD_TABLE', 13, NULL, 'YES', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'TRIGGERS', 'ACTION_REFERENCE_NEW_TABLE', 14, NULL, 'YES', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'TRIGGERS', 'ACTION_REFERENCE_OLD_ROW', 15, '', 'NO', 'varchar', 3, 9, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(3)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'TRIGGERS', 'ACTION_REFERENCE_NEW_ROW', 16, '', 'NO', 'varchar', 3, 9, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(3)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'TRIGGERS', 'CREATED', 17, NULL, 'YES', 'datetime', NULL, NULL, NULL, NULL, NULL, NULL, 'datetime', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'TRIGGERS', 'SQL_MODE', 18, '', 'NO', 'longtext', 4294967295, 4294967295, NULL, NULL, 'utf8', 'utf8_general_ci', 'longtext', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'TRIGGERS', 'DEFINER', 19, '', 'NO', 'longtext', 4294967295, 4294967295, NULL, NULL, 'utf8', 'utf8_general_ci', 'longtext', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'USER_PRIVILEGES', 'GRANTEE', 1, '', 'NO', 'varchar', 81, 243, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(81)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'USER_PRIVILEGES', 'TABLE_CATALOG', 2, NULL, 'YES', 'varchar', 512, 1536, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(512)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'USER_PRIVILEGES', 'PRIVILEGE_TYPE', 3, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'USER_PRIVILEGES', 'IS_GRANTABLE', 4, '', 'NO', 'varchar', 3, 9, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(3)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'VIEWS', 'TABLE_CATALOG', 1, NULL, 'YES', 'varchar', 512, 1536, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(512)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'VIEWS', 'TABLE_SCHEMA', 2, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'VIEWS', 'TABLE_NAME', 3, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'VIEWS', 'VIEW_DEFINITION', 4, '', 'NO', 'longtext', 4294967295, 4294967295, NULL, NULL, 'utf8', 'utf8_general_ci', 'longtext', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'VIEWS', 'CHECK_OPTION', 5, '', 'NO', 'varchar', 8, 24, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(8)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'VIEWS', 'IS_UPDATABLE', 6, '', 'NO', 'varchar', 3, 9, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(3)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'VIEWS', 'DEFINER', 7, '', 'NO', 'varchar', 77, 231, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(77)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'information_schema', 'VIEWS', 'SECURITY_TYPE', 8, '', 'NO', 'varchar', 7, 21, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(7)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'address_book', 'address_id', 1, NULL, 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10) unsigned', 'PRI', 'auto_increment', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'address_book', 'member_id', 2, NULL, 'YES', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'address_book', 'name', 3, NULL, 'YES', 'varchar', 200, 600, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(200)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'address_book', 'email', 4, NULL, 'YES', 'varchar', 200, 600, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(200)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'admin_control', 'admin_id', 1, NULL, 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10) unsigned', 'PRI', 'auto_increment', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'admin_control', 'invite_message', 2, NULL, 'YES', 'blob', 65535, 65535, NULL, NULL, NULL, NULL, 'blob', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'admin_message', 'message_id', 1, NULL, 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10) unsigned', 'PRI', 'auto_increment', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'admin_message', 'member_id', 2, NULL, 'YES', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'admin_message', 'subject', 3, NULL, 'YES', 'varchar', 200, 600, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(200)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'admin_message', 'message', 4, NULL, 'YES', 'blob', 65535, 65535, NULL, NULL, NULL, NULL, 'blob', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'admin_message', 'date_posted', 5, NULL, 'YES', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'admin_message', 'read_status', 6, NULL, 'YES', 'varchar', 10, 30, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'admin_reply', 'message_id', 1, NULL, 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10) unsigned', 'PRI', 'auto_increment', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'admin_reply', 'subject', 2, NULL, 'YES', 'varchar', 200, 600, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(200)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'admin_reply', 'message', 3, NULL, 'YES', 'blob', 65535, 65535, NULL, NULL, NULL, NULL, 'blob', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'admin_reply', 'member_id', 4, NULL, 'YES', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'admin_reply', 'posted_on', 5, NULL, 'YES', 'date', NULL, NULL, NULL, NULL, NULL, NULL, 'date', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'admin_users', 'admin_id', 1, NULL, 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10) unsigned', 'PRI', 'auto_increment', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'admin_users', 'admin_user', 2, NULL, 'YES', 'varchar', 100, 300, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(100)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'admin_users', 'admin_password', 3, NULL, 'YES', 'varchar', 100, 300, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(100)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'auth', 'id', 1, NULL, 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(12) unsigned', 'PRI', 'auto_increment', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'auth', 'date', 2, NULL, 'YES', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10) unsigned', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'auth', 'ip', 3, NULL, 'YES', 'varchar', 15, 45, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(15)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'auth', 'member_id', 4, NULL, 'YES', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10) unsigned', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'band_review', 'test_id', 1, NULL, 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10) unsigned', 'PRI', 'auto_increment', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'band_review', 'test_text', 2, NULL, 'YES', 'blob', 65535, 65535, NULL, NULL, NULL, NULL, 'blob', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'band_review', 'rank', 3, NULL, 'YES', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(11)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'band_review', 'test_user', 4, NULL, 'YES', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(11)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'band_review', 'member_id', 5, NULL, 'YES', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(11)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'band_review', 'approved', 6, NULL, 'YES', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(11)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'band_review', 'date_posted', 7, NULL, 'YES', 'date', NULL, NULL, NULL, NULL, NULL, NULL, 'date', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'banned_ip', 'id', 1, NULL, 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10) unsigned', 'PRI', 'auto_increment', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'banned_ip', 'ip_address', 2, '', 'NO', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'banned_ip', 'added_on', 3, '', 'NO', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'blog_comments', 'id', 1, NULL, 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10) unsigned', 'PRI', 'auto_increment', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'blog_comments', 'blog_id', 2, '0', 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'blog_comments', 'member_id', 3, '0', 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'blog_comments', 'posted_on', 4, '', 'NO', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'blog_comments', 'body', 5, NULL, 'NO', 'blob', 65535, 65535, NULL, NULL, NULL, NULL, 'blob', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'blog_comments', 'kudos', 6, '0', 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'blog_comments', 'comment_id', 7, '0', 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'blog_comments', 'posted_on1', 8, '', 'NO', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'blog_comments', 'approved', 9, '1', 'NO', 'tinyint', NULL, NULL, 3, 0, NULL, NULL, 'tinyint(3) unsigned', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'blog_moderators', 'id', 1, NULL, 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10) unsigned', 'PRI', 'auto_increment', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'blog_moderators', 'member_id', 2, '0', 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'blog_moderators', 'added_on', 3, '', 'NO', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'blog_mood', 'id', 1, NULL, 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10) unsigned', 'PRI', 'auto_increment', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'blog_mood', 'name', 2, '', 'NO', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'blog_mood', 'image', 3, '', 'NO', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'blog_preffered', 'id', 1, NULL, 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10) unsigned', 'PRI', 'auto_increment', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'blog_preffered', 'member_id', 2, '0', 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'blog_preffered', 'preffered_id', 3, '0', 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'blog_subscriptions', 'id', 1, NULL, 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10) unsigned', 'PRI', 'auto_increment', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'blog_subscriptions', 'member_id', 2, '0', 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'blog_subscriptions', 'sub_member_id', 3, '0', 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'blog_subscriptions', 'sub_on', 4, '', 'NO', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'blog_subscriptions', 'notify', 5, '', 'NO', 'varchar', 10, 30, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'blogs', 'id', 1, NULL, 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10) unsigned zerofill', 'PRI', 'auto_increment', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'blogs', 'member_id', 2, '0', 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'blogs', 'posted_day', 3, '', 'NO', 'varchar', 30, 90, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(30)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'blogs', 'posted_month', 4, '', 'NO', 'varchar', 30, 90, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(30)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'blogs', 'posted_year', 5, '', 'NO', 'varchar', 30, 90, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(30)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'blogs', 'posted_hour', 6, '', 'NO', 'varchar', 30, 90, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(30)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'blogs', 'posted_min', 7, '', 'NO', 'varchar', 30, 90, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(30)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'blogs', 'am_pm', 8, '', 'NO', 'varchar', 30, 90, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(30)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'blogs', 'subject', 9, '', 'NO', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'blogs', 'body', 10, NULL, 'NO', 'blob', 65535, 65535, NULL, NULL, NULL, NULL, 'blob', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'blogs', 'currently', 11, '', 'NO', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'blogs', 'mood', 12, '', 'NO', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'blogs', 'comments_allowed', 13, '', 'NO', 'varchar', 10, 30, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'blogs', 'privacy', 14, '', 'NO', 'varchar', 30, 90, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(30)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'blogs', 'last_updated', 15, '', 'NO', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'blogs', 'view', 16, '0', 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'board_main', 'member_id', 1, NULL, 'YES', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'board_main', 'message_id', 2, NULL, 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10) unsigned', 'PRI', 'auto_increment', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'board_main', 'subject', 3, NULL, 'YES', 'varchar', 200, 600, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(200)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'board_main', 'body', 4, NULL, 'YES', 'blob', 65535, 65535, NULL, NULL, NULL, NULL, 'blob', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'board_main', 'message_by', 5, NULL, 'YES', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'board_main', 'posted_on', 6, NULL, 'YES', 'date', NULL, NULL, NULL, NULL, NULL, NULL, 'date', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'board_reply', 'board_sub_id1', 1, NULL, 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10) unsigned', 'PRI', 'auto_increment', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'board_reply', 'board_sub_id', 2, NULL, 'YES', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'board_reply', 'board_id', 3, NULL, 'YES', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'board_reply', 'member_id', 4, NULL, 'YES', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'board_reply', 'subject', 5, NULL, 'YES', 'varchar', 200, 600, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(200)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'board_reply', 'message', 6, NULL, 'YES', 'blob', 65535, 65535, NULL, NULL, NULL, NULL, 'blob', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'board_reply', 'posted_on', 7, NULL, 'YES', 'date', NULL, NULL, NULL, NULL, NULL, NULL, 'date', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'board_sub', 'board_sub_id', 1, NULL, 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10) unsigned', 'PRI', 'auto_increment', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'board_sub', 'board_id', 2, NULL, 'YES', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'board_sub', 'member_id', 3, NULL, 'YES', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'board_sub', 'message', 4, NULL, 'YES', 'blob', 65535, 65535, NULL, NULL, NULL, NULL, 'blob', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'board_sub', 'subject', 5, NULL, 'YES', 'varchar', 200, 600, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(200)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'board_sub', 'posted_on', 6, NULL, 'YES', 'date', NULL, NULL, NULL, NULL, NULL, NULL, 'date', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'bookmarks', 'book_id', 1, NULL, 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10) unsigned', 'PRI', 'auto_increment', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'bookmarks', 'member_id', 2, NULL, 'YES', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'bookmarks', 'member_book_id', 3, NULL, 'YES', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'bookmarks', 'deleted', 4, NULL, 'YES', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'bulletin_message', 'id', 1, NULL, 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10) unsigned', 'PRI', 'auto_increment', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'bulletin_message', 'posted_by', 2, '0', 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'bulletin_message', 'subject', 3, '', 'NO', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'bulletin_message', 'message', 4, NULL, 'NO', 'blob', 65535, 65535, NULL, NULL, NULL, NULL, 'blob', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'bulletin_message', 'posted_on', 5, '', 'NO', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'cities', 'state_id', 1, NULL, 'YES', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'cities', 'city_id', 2, NULL, 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10) unsigned', 'PRI', 'auto_increment', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'cities', 'city_name', 3, NULL, 'YES', 'varchar', 200, 600, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(200)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'classified_cat', 'id', 1, NULL, 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10) unsigned', 'PRI', 'auto_increment', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'classified_cat', 'cat_name', 2, '', 'NO', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'classified_cat', 'cat_desc', 3, NULL, 'NO', 'blob', 65535, 65535, NULL, NULL, NULL, NULL, 'blob', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'classified_listing', 'id', 1, NULL, 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10) unsigned', 'PRI', 'auto_increment', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'classified_listing', 'member_id', 2, '0', 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'classified_listing', 'cat_id', 3, '0', 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'classified_listing', 'sub_cat_id', 4, '0', 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'classified_listing', 'subject', 5, '', 'NO', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'classified_listing', 'message', 6, NULL, 'NO', 'blob', 65535, 65535, NULL, NULL, NULL, NULL, 'blob', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'classified_listing', 'posted_on', 7, '', 'NO', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'classified_listing', 'views', 8, '0', 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'classified_sub_cat', 'id', 1, NULL, 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10) unsigned', 'PRI', 'auto_increment', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'classified_sub_cat', 'main_id', 2, '0', 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'classified_sub_cat', 'cat_name', 3, '', 'NO', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'classified_sub_cat', 'cat_desc', 4, NULL, 'NO', 'blob', 65535, 65535, NULL, NULL, NULL, NULL, 'blob', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'colleges', 'state_id', 1, NULL, 'YES', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'colleges', 'college_id', 2, NULL, 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10) unsigned', 'PRI', 'auto_increment', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'colleges', 'college_name', 3, NULL, 'YES', 'varchar', 200, 600, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(200)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'colleges', 'college_city', 4, NULL, 'YES', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'colleges', 'listed', 5, NULL, 'YES', 'varchar', 10, 30, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'disclaimer', 'disclaimer_id', 1, NULL, 'YES', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'disclaimer', 'disclaimer_text', 2, NULL, 'YES', 'blob', 65535, 65535, NULL, NULL, NULL, NULL, 'blob', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'events', 'id', 1, NULL, 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10) unsigned', 'PRI', 'auto_increment', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'events', 'event_by', 2, '0', 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'events', 'event_name', 3, '', 'NO', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'events', 'organizer', 4, '', 'NO', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'events', 'email', 5, '', 'NO', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'events', 'event_type', 6, '', 'NO', 'varchar', 10, 30, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'events', 'cat_id', 7, '0', 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'events', 'short_desc', 8, NULL, 'NO', 'blob', 65535, 65535, NULL, NULL, NULL, NULL, 'blob', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'events', 'long_desc', 9, NULL, 'NO', 'blob', 65535, 65535, NULL, NULL, NULL, NULL, 'blob', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'events', 'start_month', 10, '0', 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'events', 'start_day', 11, '0', 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'events', 'start_year', 12, '0', 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'events', 'start_hour', 13, '', 'NO', 'varchar', 10, 30, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'events', 'start_minute', 14, '', 'NO', 'varchar', 10, 30, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'events', 'start_marker', 15, '', 'NO', 'varchar', 10, 30, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'events', 'place', 16, '', 'NO', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'events', 'address', 17, '', 'NO', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'events', 'city', 18, '', 'NO', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'events', 'state', 19, '', 'NO', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'events', 'zip', 20, '', 'NO', 'varchar', 30, 90, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(30)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'events', 'country', 21, '', 'NO', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'events', 'featured', 22, '', 'NO', 'varchar', 10, 30, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'events', 'posted_on', 23, '', 'NO', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'events', 'start_date', 24, '0', 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'events_cat', 'id', 1, NULL, 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10) unsigned', 'PRI', 'auto_increment', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'events_cat', 'cat_name', 2, '', 'NO', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'events_cat', 'cat_desc', 3, NULL, 'NO', 'blob', 65535, 65535, NULL, NULL, NULL, NULL, 'blob', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'events_cat', 'cat_type', 4, '', 'NO', 'varchar', 10, 30, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'events_cat', 'type', 5, '', 'NO', 'varchar', 10, 30, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'events_cat', 'def', 6, '0', 'NO', 'tinyint', NULL, NULL, 3, 0, NULL, NULL, 'tinyint(3) unsigned', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'events_comments', 'id', 1, NULL, 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10) unsigned', 'PRI', 'auto_increment', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'events_comments', 'event_id', 2, '0', 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'events_comments', 'comment_by', 3, '0', 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'events_comments', 'comment', 4, NULL, 'NO', 'blob', 65535, 65535, NULL, NULL, NULL, NULL, 'blob', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'events_comments', 'posted_on', 5, '', 'NO', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'events_rsvp', 'id', 1, NULL, 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10) unsigned', 'PRI', 'auto_increment', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'events_rsvp', 'event_id', 2, '0', 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'events_rsvp', 'action', 3, '', 'NO', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'events_rsvp', 'comment', 4, NULL, 'NO', 'blob', 65535, 65535, NULL, NULL, NULL, NULL, 'blob', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'events_rsvp', 'add_calen', 5, '', 'NO', 'char', 1, 3, NULL, NULL, 'utf8', 'utf8_general_ci', 'char(1)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'events_rsvp', 'guests', 6, '0', 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'events_rsvp', 'rsvp_by', 7, '0', 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'events_rsvp', 'response', 8, '', 'NO', 'varchar', 10, 30, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'forum_main_cat', 'id', 1, NULL, 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10) unsigned', 'PRI', 'auto_increment', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'forum_main_cat', 'cat_name', 2, '', 'NO', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'forum_main_cat', 'cat_desc', 3, NULL, 'NO', 'blob', 65535, 65535, NULL, NULL, NULL, NULL, 'blob', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'forum_posts', 'id', 1, NULL, 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10) unsigned', 'PRI', 'auto_increment', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'forum_posts', 'main_forum_id', 2, '0', 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'forum_posts', 'sub_forum_id', 3, '0', 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'forum_posts', 'topic_id', 4, '0', 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'forum_posts', 'subject', 5, '', 'NO', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'forum_posts', 'message', 6, NULL, 'NO', 'blob', 65535, 65535, NULL, NULL, NULL, NULL, 'blob', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'forum_posts', 'posted_on', 7, '', 'NO', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'forum_posts', 'posted_by', 8, '0', 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'forum_sub_cat', 'id', 1, NULL, 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10) unsigned', 'PRI', 'auto_increment', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'forum_sub_cat', 'cat_name', 2, '', 'NO', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'forum_sub_cat', 'cat_desc', 3, NULL, 'NO', 'blob', 65535, 65535, NULL, NULL, NULL, NULL, 'blob', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'forum_sub_cat', 'main_cat_id', 4, '0', 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'forum_sub_cat', 'moderators', 5, '', 'NO', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'forum_sub_cat', 'creator_id', 6, NULL, 'YES', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10) unsigned', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'forum_sub_cat', 'creator_ip', 7, NULL, 'YES', 'varchar', 15, 45, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(15)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'forum_sub_cat', 'date_created', 8, NULL, 'YES', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10) unsigned', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'forum_topics', 'id', 1, NULL, 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10) unsigned', 'PRI', 'auto_increment', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'forum_topics', 'main_forum_id', 2, '0', 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'forum_topics', 'sub_forum_id', 3, '0', 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'forum_topics', 'subject', 4, '', 'NO', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'forum_topics', 'message', 5, NULL, 'NO', 'blob', 65535, 65535, NULL, NULL, NULL, NULL, 'blob', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'forum_topics', 'posted_on', 6, '', 'NO', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'forum_topics', 'posted_by', 7, '0', 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'g_bookmarks', 'book_id', 1, NULL, 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10) unsigned', 'PRI', 'auto_increment', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'g_bookmarks', 'member_id', 2, NULL, 'YES', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'g_bookmarks', 'member_book_id', 3, NULL, 'YES', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'g_bookmarks', 'deleted', 4, NULL, 'YES', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'g_journal', 'journal_id', 1, NULL, 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10) unsigned', 'PRI', 'auto_increment', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'g_journal', 'journal_of', 2, NULL, 'YES', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'g_journal', 'journal_date', 3, NULL, 'YES', 'varchar', 100, 300, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(100)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'g_journal', 'journal_time', 4, NULL, 'YES', 'varchar', 100, 300, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(100)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'g_journal', 'journal_text', 5, NULL, 'YES', 'blob', 65535, 65535, NULL, NULL, NULL, NULL, 'blob', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'g_messages', 'mess_id', 1, NULL, 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10) unsigned', 'PRI', 'auto_increment', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'g_messages', 'mess_by', 2, NULL, 'YES', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(11)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'g_messages', 'mess_to', 3, NULL, 'YES', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(11)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'g_messages', 'mess_text', 4, NULL, 'YES', 'blob', 65535, 65535, NULL, NULL, NULL, NULL, 'blob', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'g_messages', 'deleted', 5, NULL, 'YES', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(11)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'g_messages', 'subject', 6, NULL, 'YES', 'varchar', 200, 600, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(200)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'g_messages', 'date_posted', 7, NULL, 'YES', 'date', NULL, NULL, NULL, NULL, NULL, NULL, 'date', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'g_messages', 'mess_read', 8, NULL, 'YES', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(11)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'g_testimonials', 'test_id', 1, NULL, 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10) unsigned', 'PRI', 'auto_increment', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'g_testimonials', 'test_text', 2, NULL, 'YES', 'blob', 65535, 65535, NULL, NULL, NULL, NULL, 'blob', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'g_testimonials', 'test_user', 3, NULL, 'YES', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(11)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'g_testimonials', 'member_id', 4, NULL, 'YES', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(11)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'g_testimonials', 'approved', 5, NULL, 'YES', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(11)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'g_testimonials', 'date_posted', 6, NULL, 'YES', 'date', NULL, NULL, NULL, NULL, NULL, NULL, 'date', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'group_bulletin', 'id', 1, NULL, 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10) unsigned', 'PRI', 'auto_increment', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'group_bulletin', 'group_id', 2, '0', 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'group_bulletin', 'member_id', 3, '0', 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'group_bulletin', 'subject', 4, '', 'NO', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'group_bulletin', 'body', 5, NULL, 'NO', 'blob', 65535, 65535, NULL, NULL, NULL, NULL, 'blob', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'group_bulletin', 'posted_on', 6, '', 'NO', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'group_bulletin_reply', 'id', 1, NULL, 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10) unsigned', 'PRI', 'auto_increment', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'group_bulletin_reply', 'group_id', 2, '0', 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'group_bulletin_reply', 'member_id', 3, '0', 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'group_bulletin_reply', 'topic_id', 4, '0', 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'group_bulletin_reply', 'subject', 5, '0', 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'group_bulletin_reply', 'body', 6, NULL, 'NO', 'blob', 65535, 65535, NULL, NULL, NULL, NULL, 'blob', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'group_bulletin_reply', 'posted_on', 7, '', 'NO', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'group_cat', 'id', 1, NULL, 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10) unsigned', 'PRI', 'auto_increment', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'group_cat', 'cat_name', 2, '', 'NO', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'group_cat', 'cat_desc', 3, NULL, 'NO', 'blob', 65535, 65535, NULL, NULL, NULL, NULL, 'blob', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'group_friends', 'id', 1, NULL, 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10) unsigned', 'PRI', 'auto_increment', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'group_friends', 'member_id', 2, NULL, 'YES', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'group_friends', 'group_id', 3, NULL, 'YES', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'group_friends', 'approve', 4, NULL, 'YES', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'group_friends', 'deleted', 5, NULL, 'YES', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'group_friends', 'status', 6, '0', 'YES', 'tinyint', NULL, NULL, 3, 0, NULL, NULL, 'tinyint(3) unsigned', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'group_friends', 'date', 7, NULL, 'YES', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10) unsigned', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'group_friends', 'is_invited', 8, '0', 'YES', 'tinyint', NULL, NULL, 3, 0, NULL, NULL, 'tinyint(3) unsigned', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'group_invites', 'invite_id', 1, NULL, 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10) unsigned', 'PRI', 'auto_increment', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'group_invites', 'group_id', 2, NULL, 'YES', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'group_invites', 'member_id', 3, NULL, 'YES', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'group_invites', 'member_email', 4, NULL, 'YES', 'varchar', 100, 300, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(100)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'group_invites', 'member_name', 5, NULL, 'YES', 'varchar', 100, 300, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(100)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'group_invites', 'member_lname', 6, NULL, 'YES', 'varchar', 100, 300, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(100)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'group_photos', 'photo_id', 1, NULL, 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10) unsigned', 'PRI', 'auto_increment', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'group_photos', 'group_id', 2, NULL, 'YES', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(11)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'group_photos', 'group_by', 3, NULL, 'YES', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(11)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'group_photos', 'photo_url', 4, NULL, 'YES', 'varchar', 100, 300, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(100)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'group_photos', 'enable', 5, NULL, 'YES', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'group_photos', 'small_photos', 6, NULL, 'YES', 'varchar', 100, 300, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(100)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'group_topic_reply', 'id', 1, NULL, 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10) unsigned', 'PRI', 'auto_increment', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'group_topic_reply', 'group_id', 2, '0', 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'group_topic_reply', 'member_id', 3, '0', 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'group_topic_reply', 'topic_id', 4, '0', 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'group_topic_reply', 'subject', 5, '', 'NO', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'group_topic_reply', 'body', 6, NULL, 'NO', 'blob', 65535, 65535, NULL, NULL, NULL, NULL, 'blob', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'group_topic_reply', 'posted_on', 7, '', 'NO', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'group_topics', 'id', 1, NULL, 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10) unsigned', 'PRI', 'auto_increment', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'group_topics', 'group_id', 2, '0', 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'group_topics', 'member_id', 3, '0', 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'group_topics', 'subject', 4, '', 'NO', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'group_topics', 'body', 5, NULL, 'NO', 'blob', 65535, 65535, NULL, NULL, NULL, NULL, 'blob', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'group_topics', 'posted_on', 6, '', 'NO', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'groups', 'id', 1, NULL, 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10) unsigned', 'PRI', 'auto_increment', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'groups', 'group_name', 2, '', 'NO', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'groups', 'category', 3, '0', 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'groups', 'type', 4, '0', 'NO', 'tinyint', NULL, NULL, 3, 0, NULL, NULL, 'tinyint(3)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'groups', 'hidden_group', 5, '', 'NO', 'varchar', 10, 30, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'groups', 'hide_from_all', 6, '0', 'YES', 'tinyint', NULL, NULL, 3, 0, NULL, NULL, 'tinyint(3) unsigned', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'groups', 'members_invite', 7, '', 'NO', 'varchar', 10, 30, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'groups', 'public_forum', 8, '', 'NO', 'varchar', 10, 30, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'groups', 'post_bulletins', 9, '', 'NO', 'varchar', 10, 30, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'groups', 'post_images', 10, '', 'NO', 'varchar', 10, 30, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'groups', 'country', 11, '0', 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'groups', 'city', 12, '', 'NO', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'groups', 'state', 13, '', 'NO', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'groups', 'zip_code', 14, '', 'NO', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'groups', 'description', 15, NULL, 'NO', 'blob', 65535, 65535, NULL, NULL, NULL, NULL, 'blob', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'groups', 'member_id', 16, '0', 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'groups', 'featured', 17, '', 'NO', 'varchar', 10, 30, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'groups', 'posted_on', 18, '', 'NO', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'groups_creator', 'group_id', 1, NULL, 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10) unsigned', 'PRI', 'auto_increment', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'groups_creator', 'email', 2, NULL, 'YES', 'varchar', 100, 300, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(100)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'groups_creator', 'password', 3, NULL, 'YES', 'varchar', 100, 300, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(100)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'groups_creator', 'joined_on', 4, NULL, 'YES', 'date', NULL, NULL, NULL, NULL, NULL, NULL, 'date', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'groups_creator', 'last_login', 5, NULL, 'YES', 'date', NULL, NULL, NULL, NULL, NULL, NULL, 'date', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'groups_creator', 'group_name', 6, NULL, 'YES', 'varchar', 100, 300, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(100)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'groups_profile', 'group_id', 1, NULL, 'YES', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'groups_profile', 'group_state', 2, NULL, 'YES', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'groups_profile', 'group_city', 3, NULL, 'YES', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'groups_profile', 'group_school', 4, NULL, 'YES', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'groups_profile', 'group_zip', 5, NULL, 'YES', 'varchar', 10, 30, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'groups_profile', 'group_mission', 6, NULL, 'YES', 'blob', 65535, 65535, NULL, NULL, NULL, NULL, 'blob', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'groups_profile', 'general_info', 7, NULL, 'YES', 'blob', 65535, 65535, NULL, NULL, NULL, NULL, 'blob', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'groups_profile', 'group_contacts', 8, NULL, 'YES', 'varchar', 100, 300, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(100)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'groups_profile', 'group_activities', 9, NULL, 'YES', 'blob', 65535, 65535, NULL, NULL, NULL, NULL, 'blob', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'groups_profile', 'community_charity', 10, NULL, 'YES', 'blob', 65535, 65535, NULL, NULL, NULL, NULL, 'blob', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'groups_profile', 'group_headline', 11, NULL, 'YES', 'varchar', 100, 300, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(100)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'help', 'help_id', 1, NULL, 'YES', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'help', 'help_text', 2, NULL, 'YES', 'blob', 65535, 65535, NULL, NULL, NULL, NULL, 'blob', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'hotornot_rating', 'id', 1, NULL, 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10) unsigned', 'PRI', 'auto_increment', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'hotornot_rating', 'photo_id', 2, '0', 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'hotornot_rating', 'rating', 3, '0', 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'hotornot_rating', 'sess_id', 4, '', 'NO', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'hotornot_rating', 'rated_on', 5, '', 'NO', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'hotornot_rating', 'rated_by', 6, NULL, 'YES', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(11)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'invitations', 'id', 1, NULL, 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(12) unsigned', 'PRI', 'auto_increment', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'invitations', 'member_id', 2, '0', 'YES', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10) unsigned', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'invitations', 'friend_id', 3, '0', 'YES', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10) unsigned', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'invitations', 'group_id', 4, '0', 'YES', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10) unsigned', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'invitations', 'approve', 5, '0', 'YES', 'tinyint', NULL, NULL, 3, 0, NULL, NULL, 'tinyint(3) unsigned', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'invitations', 'deleted', 6, '0', 'YES', 'tinyint', NULL, NULL, 3, 0, NULL, NULL, 'tinyint(3) unsigned', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'invitations', 'is_invited', 7, '0', 'YES', 'tinyint', NULL, NULL, 3, 0, NULL, NULL, 'tinyint(3) unsigned', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'invitations', 'status', 8, '0', 'YES', 'tinyint', NULL, NULL, 3, 0, NULL, NULL, 'tinyint(3) unsigned', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'invitations', 'read', 9, '0', 'YES', 'tinyint', NULL, NULL, 3, 0, NULL, NULL, 'tinyint(3) unsigned', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'invitations', 'date', 10, '0', 'YES', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10) unsigned', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'invite_temp_emails', 'invite_id', 1, NULL, 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10) unsigned', 'PRI', 'auto_increment', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'invite_temp_emails', 'email', 2, NULL, 'YES', 'varchar', 100, 300, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(100)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'invite_temp_emails', 'name', 3, NULL, 'YES', 'varchar', 100, 300, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(100)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'invite_temp_emails', 'session_id', 4, NULL, 'YES', 'varchar', 200, 600, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(200)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'invite_temp_group_emails', 'invite_id', 1, NULL, 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10) unsigned', 'PRI', 'auto_increment', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'invite_temp_group_emails', 'email', 2, NULL, 'YES', 'varchar', 100, 300, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(100)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'invite_temp_group_emails', 'name', 3, NULL, 'YES', 'varchar', 100, 300, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(100)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'invite_temp_group_emails', 'session_id', 4, NULL, 'YES', 'varchar', 200, 600, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(200)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'invites', 'invite_id', 1, NULL, 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10) unsigned', 'PRI', 'auto_increment', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'invites', 'member_id', 2, NULL, 'YES', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'invites', 'member_email', 3, NULL, 'YES', 'varchar', 100, 300, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(100)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'invites', 'member_name', 4, NULL, 'YES', 'varchar', 100, 300, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(100)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'invites', 'member_lname', 5, NULL, 'YES', 'varchar', 100, 300, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(100)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'journal', 'journal_id', 1, NULL, 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10) unsigned', 'PRI', 'auto_increment', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'journal', 'journal_of', 2, NULL, 'YES', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'journal', 'journal_date', 3, NULL, 'YES', 'varchar', 100, 300, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(100)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'journal', 'journal_time', 4, NULL, 'YES', 'varchar', 100, 300, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(100)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'journal', 'journal_text', 5, NULL, 'YES', 'blob', 65535, 65535, NULL, NULL, NULL, NULL, 'blob', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'journal', 'subject', 6, NULL, 'YES', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'journal_comment', 'comment_id', 1, NULL, 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10) unsigned', 'PRI', 'auto_increment', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'journal_comment', 'journal_id', 2, NULL, 'YES', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'journal_comment', 'journal_by', 3, NULL, 'YES', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'journal_comment', 'journal_date', 4, NULL, 'YES', 'varchar', 100, 300, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(100)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'journal_comment', 'journal_time', 5, NULL, 'YES', 'varchar', 100, 300, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(100)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'journal_comment', 'journal_text', 6, NULL, 'YES', 'blob', 65535, 65535, NULL, NULL, NULL, NULL, 'blob', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'login_page', 'login_id', 1, NULL, 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10) unsigned', 'PRI', 'auto_increment', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'login_page', 'login_text', 2, NULL, 'YES', 'blob', 65535, 65535, NULL, NULL, NULL, NULL, 'blob', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'main_page', 'main_id', 1, NULL, 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10) unsigned', 'PRI', 'auto_increment', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'main_page', 'main_text', 2, NULL, 'YES', 'blob', 65535, 65535, NULL, NULL, NULL, NULL, 'blob', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'member_friends', 'id', 1, NULL, 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10) unsigned', 'PRI', 'auto_increment', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'member_friends', 'member_id', 2, NULL, 'YES', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'member_friends', 'friend_id', 3, NULL, 'YES', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'member_friends', 'approve', 4, NULL, 'YES', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'member_friends', 'deleted', 5, NULL, 'YES', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'member_friends', 'date', 6, NULL, 'YES', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10) unsigned', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'member_networking', 'id', 1, NULL, 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10) unsigned', 'PRI', 'auto_increment', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'member_networking', 'member_id', 2, '0', 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'member_networking', 'field', 3, '', 'NO', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'member_networking', 'sub_field', 4, '', 'NO', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'member_networking', 'role', 5, '', 'NO', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'member_networking', 'description', 6, NULL, 'NO', 'blob', 65535, 65535, NULL, NULL, NULL, NULL, 'blob', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'member_profile', 'member_id', 1, NULL, 'YES', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'member_profile', 'date_of_birth', 2, NULL, 'YES', 'varchar', 100, 300, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(100)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'member_profile', 'country', 3, NULL, 'YES', 'varchar', 50, 150, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(50)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'member_profile', 'zip', 4, NULL, 'YES', 'varchar', 10, 30, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'member_profile', 'hometown', 5, NULL, 'YES', 'varchar', 50, 150, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(50)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'member_profile', 'interests', 6, NULL, 'YES', 'blob', 65535, 65535, NULL, NULL, NULL, NULL, 'blob', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'member_profile', 'photo_id', 7, NULL, 'YES', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'member_profile', 'favourite_music', 8, NULL, 'YES', 'blob', 65535, 65535, NULL, NULL, NULL, NULL, 'blob', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'member_profile', 'favourite_books', 9, NULL, 'YES', 'blob', 65535, 65535, NULL, NULL, NULL, NULL, 'blob', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'member_profile', 'favourite_tv', 10, NULL, 'YES', 'blob', 65535, 65535, NULL, NULL, NULL, NULL, 'blob', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'member_profile', 'favourite_movies', 11, NULL, 'YES', 'blob', 65535, 65535, NULL, NULL, NULL, NULL, 'blob', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'member_profile', 'about_me', 12, NULL, 'YES', 'blob', 65535, 65535, NULL, NULL, NULL, NULL, 'blob', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'member_profile', 'about_friend', 13, NULL, 'YES', 'blob', 65535, 65535, NULL, NULL, NULL, NULL, 'blob', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'member_profile', 'status', 14, NULL, 'YES', 'blob', 65535, 65535, NULL, NULL, NULL, NULL, 'blob', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'member_profile', 'age', 15, NULL, 'YES', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'member_profile', 'occupation', 16, NULL, 'YES', 'varchar', 100, 300, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(100)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'member_profile', 'views', 17, '0', 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'member_profile', 'code', 18, NULL, 'YES', 'mediumtext', 16777215, 16777215, NULL, NULL, 'utf8', 'utf8_general_ci', 'mediumtext', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'member_profile', 'code_bg_img', 19, NULL, 'YES', 'varchar', 20, 60, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(20)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'members', 'member_id', 1, NULL, 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10) unsigned', 'PRI', 'auto_increment', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'members', 'display_name', 2, '', 'NO', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'members', 'member_name', 3, NULL, 'YES', 'varchar', 50, 150, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(50)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'members', 'member_lname', 4, NULL, 'YES', 'varchar', 50, 150, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(50)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'members', 'member_email', 5, NULL, 'YES', 'varchar', 100, 300, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(100)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'members', 'member_password', 6, NULL, 'YES', 'varchar', 50, 150, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(50)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'members', 'email_verify', 7, NULL, 'YES', 'char', 1, 3, NULL, NULL, 'utf8', 'utf8_general_ci', 'char(1)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'members', 'gender', 8, NULL, 'YES', 'varchar', 100, 300, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(100)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'members', 'dob', 9, NULL, 'YES', 'varchar', 100, 300, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(100)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'members', 'flag', 10, NULL, 'YES', 'char', 1, 3, NULL, NULL, 'utf8', 'utf8_general_ci', 'char(1)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'members', 'last_login', 11, NULL, 'YES', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'members', 'enable', 12, NULL, 'YES', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(11)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'members', 'current_state', 13, NULL, 'YES', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'members', 'birth_day', 14, NULL, 'YES', 'varchar', 30, 90, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(30)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'members', 'birth_month', 15, NULL, 'YES', 'varchar', 100, 300, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(100)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'members', 'birth_year', 16, NULL, 'YES', 'varchar', 100, 300, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(100)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'members', 'salutation', 17, NULL, 'YES', 'varchar', 5, 15, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(5)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'members', 'zip_code', 18, NULL, 'YES', 'varchar', 10, 30, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'members', 'online_now', 19, NULL, 'YES', 'char', 1, 3, NULL, NULL, 'utf8', 'utf8_general_ci', 'char(1)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'members', 'country', 20, '', 'NO', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'members', 'pack_id', 21, '0', 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'members', 'here_for', 22, '', 'NO', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'members', 'zip', 23, '', 'NO', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'members', 'music', 24, '0', 'NO', 'char', 3, 9, NULL, NULL, 'utf8', 'utf8_general_ci', 'char(3)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'members', 'genre', 25, '0', 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'members', 'city', 26, '', 'NO', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'members', 'views', 27, '0', 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'members', 'occupation', 28, '', 'NO', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'members', 'body_type', 29, '', 'NO', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'members', 'height_feet', 30, '', 'NO', 'varchar', 10, 30, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'members', 'height_inch', 31, '', 'NO', 'varchar', 10, 30, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'members', 'website', 32, '', 'NO', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'members', 'ethnicity', 33, '', 'NO', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'members', 'featured', 34, '0', 'NO', 'varchar', 10, 30, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'members', 'comment_setting', 35, '1', 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'members', 'status', 36, '0', 'NO', 'varchar', 10, 30, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'members', 'start_time', 37, '', 'NO', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'members', 'expire_time', 38, '', 'NO', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'members', 'enabled', 39, '1', 'NO', 'varchar', 10, 30, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'members', 'uploaded_img', 40, '0', 'YES', 'tinyint', NULL, NULL, 3, 0, NULL, NULL, 'tinyint(3) unsigned', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'members', 'added_about', 41, '0', 'YES', 'tinyint', NULL, NULL, 3, 0, NULL, NULL, 'tinyint(3) unsigned', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'members', 'songId', 42, NULL, 'YES', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(11)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'members', 'online', 43, NULL, 'YES', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10) unsigned', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'members', 'view_online', 44, '1', 'YES', 'tinyint', NULL, NULL, 3, 0, NULL, NULL, 'tinyint(3) unsigned', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'members', 'date_created', 45, NULL, 'YES', 'datetime', NULL, NULL, NULL, NULL, NULL, NULL, 'datetime', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'members', 'ip_created', 46, NULL, 'YES', 'varchar', 15, 45, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(15)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'members', 'notif_message', 47, '1', 'YES', 'tinyint', NULL, NULL, 3, 0, NULL, NULL, 'tinyint(3) unsigned', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'members', 'notif_journal', 48, '1', 'YES', 'tinyint', NULL, NULL, 3, 0, NULL, NULL, 'tinyint(3) unsigned', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'members', 'notif_comment', 49, '1', 'YES', 'tinyint', NULL, NULL, 3, 0, NULL, NULL, 'tinyint(3) unsigned', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'members', 'notif_friend_request', 50, '1', 'YES', 'tinyint', NULL, NULL, 3, 0, NULL, NULL, 'tinyint(3) unsigned', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'members', 'notif_group_invitation', 51, '1', 'YES', 'tinyint', NULL, NULL, 3, 0, NULL, NULL, 'tinyint(3) unsigned', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'members', 'gmt', 52, '-5', 'YES', 'float', NULL, NULL, 12, NULL, NULL, NULL, 'float', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'messages', 'mess_id', 1, NULL, 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10) unsigned', 'PRI', 'auto_increment', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'messages', 'mess_by', 2, NULL, 'YES', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(11)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'messages', 'mess_to', 3, NULL, 'YES', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(11)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'messages', 'mess_text', 4, NULL, 'YES', 'blob', 65535, 65535, NULL, NULL, NULL, NULL, 'blob', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'messages', 'deleted', 5, NULL, 'YES', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(11)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'messages', 'subject', 6, NULL, 'YES', 'varchar', 200, 600, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(200)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'messages', 'date_posted', 7, NULL, 'YES', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'messages', 'mess_read', 8, '0', 'YES', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(11)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'messages_sent', 'mess_id', 1, NULL, 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10) unsigned', 'PRI', 'auto_increment', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'messages_sent', 'mess_by', 2, NULL, 'YES', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(11)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'messages_sent', 'mess_to', 3, NULL, 'YES', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(11)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'messages_sent', 'mess_text', 4, NULL, 'YES', 'blob', 65535, 65535, NULL, NULL, NULL, NULL, 'blob', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'messages_sent', 'deleted', 5, NULL, 'YES', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(11)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'messages_sent', 'subject', 6, NULL, 'YES', 'varchar', 200, 600, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(200)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'messages_sent', 'date_posted', 7, NULL, 'YES', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'messages_sent', 'mess_read', 8, NULL, 'YES', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(11)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'misc', 'id', 1, NULL, 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10) unsigned', 'PRI', 'auto_increment', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'misc', 'invite_only', 2, '1', 'NO', 'varchar', 10, 30, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'misc', 'default_friend_profile', 3, '0', 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'moderators_classified', 'id', 1, NULL, 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10) unsigned', 'PRI', 'auto_increment', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'moderators_classified', 'member_id', 2, '0', 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'moderators_classified', 'added_on', 3, '', 'NO', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'moderators_events', 'id', 1, NULL, 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10) unsigned', 'PRI', 'auto_increment', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'moderators_events', 'member_id', 2, '0', 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'moderators_events', 'added_on', 3, '', 'NO', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'moderators_groups', 'id', 1, NULL, 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10) unsigned', 'PRI', 'auto_increment', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'moderators_groups', 'member_id', 2, '0', 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'moderators_groups', 'added_on', 3, '', 'NO', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'moderators_music', 'id', 1, NULL, 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10) unsigned', 'PRI', 'auto_increment', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'moderators_music', 'member_id', 2, '0', 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'moderators_music', 'added_on', 3, '', 'NO', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'moderators_pics', 'id', 1, NULL, 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10) unsigned', 'PRI', 'auto_increment', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'moderators_pics', 'member_id', 2, '0', 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'moderators_pics', 'added_on', 3, '', 'NO', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'most_popular', 'id', 1, NULL, 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10) unsigned', 'PRI', 'auto_increment', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'most_popular', 'member_id', 2, '0', 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'most_popular', 'avg_rank', 3, '0', 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'most_popular', 'num_friends', 4, '0', 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'music_genre', 'id', 1, NULL, 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10) unsigned', 'PRI', 'auto_increment', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'music_genre', 'cat_name', 2, '', 'NO', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'music_genre', 'cat_desc', 3, NULL, 'NO', 'blob', 65535, 65535, NULL, NULL, NULL, NULL, 'blob', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'music_member_profile', 'id', 1, NULL, 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10) unsigned', 'PRI', 'auto_increment', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'music_member_profile', 'user_id', 2, '0', 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'music_member_profile', 'user_name', 3, '', 'NO', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'music_member_profile', 'genre1', 4, '0', 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'music_member_profile', 'genre2', 5, '0', 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'music_member_profile', 'genre3', 6, '0', 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'music_member_profile', 'website', 7, '', 'NO', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'music_member_profile', 'label', 8, '', 'NO', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'music_member_profile', 'label_type', 9, '', 'NO', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'music_member_profile', 'here_for', 10, '', 'NO', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'music_members', 'id', 1, NULL, 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10) unsigned', 'PRI', 'auto_increment', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'music_members', 'member_id', 2, '0', 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'music_members', 'member_name', 3, '', 'NO', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'music_members', 'biography', 4, NULL, 'NO', 'blob', 65535, 65535, NULL, NULL, NULL, NULL, 'blob', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'music_members', 'instrument', 5, NULL, 'NO', 'blob', 65535, 65535, NULL, NULL, NULL, NULL, 'blob', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'music_members', 'influences', 6, NULL, 'NO', 'blob', 65535, 65535, NULL, NULL, NULL, NULL, 'blob', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'music_members', 'sounds_like', 7, NULL, 'NO', 'blob', 65535, 65535, NULL, NULL, NULL, NULL, 'blob', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'music_members', 'member_talent', 8, '', 'NO', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'music_profile', 'id', 1, NULL, 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10) unsigned', 'PRI', 'auto_increment', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'music_profile', 'member_id', 2, '0', 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'music_profile', 'headline', 3, '', 'NO', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'music_profile', 'bio', 4, NULL, 'NO', 'mediumtext', 16777215, 16777215, NULL, NULL, 'utf8', 'utf8_general_ci', 'mediumtext', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'music_profile', 'members', 5, NULL, 'NO', 'mediumtext', 16777215, 16777215, NULL, NULL, 'utf8', 'utf8_general_ci', 'mediumtext', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'music_profile', 'influences', 6, NULL, 'NO', 'mediumtext', 16777215, 16777215, NULL, NULL, 'utf8', 'utf8_general_ci', 'mediumtext', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'music_profile', 'sounds_like', 7, NULL, 'NO', 'mediumtext', 16777215, 16777215, NULL, NULL, 'utf8', 'utf8_general_ci', 'mediumtext', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'music_profile', 'website', 8, '', 'NO', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'music_profile', 'record_label', 9, NULL, 'NO', 'mediumtext', 16777215, 16777215, NULL, NULL, 'utf8', 'utf8_general_ci', 'mediumtext', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'music_profile', 'label_type', 10, NULL, 'NO', 'mediumtext', 16777215, 16777215, NULL, NULL, 'utf8', 'utf8_general_ci', 'mediumtext', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'music_shows', 'id', 1, NULL, 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10) unsigned', 'PRI', 'auto_increment', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'music_shows', 'member_id', 2, '0', 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'music_shows', 'show_month', 3, '', 'NO', 'varchar', 10, 30, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'music_shows', 'show_day', 4, '', 'NO', 'varchar', 10, 30, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'music_shows', 'show_year', 5, '', 'NO', 'varchar', 15, 45, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(15)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'music_shows', 'show_hour', 6, '', 'NO', 'varchar', 10, 30, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'music_shows', 'show_min', 7, '', 'NO', 'varchar', 10, 30, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'music_shows', 'show_marker', 8, '', 'NO', 'varchar', 10, 30, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'music_shows', 'venue', 9, '', 'NO', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'music_shows', 'cost', 10, '', 'NO', 'varchar', 30, 90, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(30)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'music_shows', 'address', 11, '', 'NO', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'music_shows', 'city', 12, '', 'NO', 'varchar', 50, 150, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(50)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'music_shows', 'zip_code', 13, '', 'NO', 'varchar', 10, 30, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'music_shows', 'state', 14, '', 'NO', 'varchar', 50, 150, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(50)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'music_shows', 'region', 15, '', 'NO', 'varchar', 10, 30, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'music_shows', 'country', 16, '', 'NO', 'varchar', 50, 150, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(50)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'music_shows', 'description', 17, NULL, 'NO', 'blob', 65535, 65535, NULL, NULL, NULL, NULL, 'blob', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'music_songs', 'id', 1, NULL, 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10) unsigned', 'PRI', 'auto_increment', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'music_songs', 'owner_id', 2, NULL, 'YES', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10) unsigned', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'music_songs', 'member_id', 3, '0', 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'music_songs', 'song_name', 4, '', 'NO', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'music_songs', 'song_file', 5, '', 'NO', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'music_songs', 'lyrics', 6, NULL, 'NO', 'blob', 65535, 65535, NULL, NULL, NULL, NULL, 'blob', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'music_songs', 'date', 7, NULL, 'YES', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10) unsigned', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'music_songs', 'def', 8, '0', 'YES', 'tinyint', NULL, NULL, 3, 0, NULL, NULL, 'tinyint(3) unsigned', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'news', 'id', 1, NULL, 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10) unsigned', 'PRI', 'auto_increment', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'news', 'news_heading', 2, '', 'NO', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'news', 'posted_on', 3, '', 'NO', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'news', 'news_body', 4, NULL, 'NO', 'blob', 65535, 65535, NULL, NULL, NULL, NULL, 'blob', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'news', 'news_thumbnail', 5, '', 'NO', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'news', 'views', 6, '0', 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'online_now', 'id', 1, NULL, 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10) unsigned', 'PRI', 'auto_increment', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'online_now', 'start_time', 2, '', 'NO', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'online_now', 'ip_address', 3, '', 'NO', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'online_now', 'member_id', 4, '0', 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'online_now', 'status', 5, '', 'NO', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'packages', 'id', 1, NULL, 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10) unsigned', 'PRI', 'auto_increment', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'packages', 'pack_name', 2, '', 'NO', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'packages', 'price', 3, '0.00', 'NO', 'double', NULL, NULL, 10, 2, NULL, NULL, 'double(10,2)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'packages', 'allowed_mods', 4, '', 'NO', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'pages', 'page_id', 1, NULL, 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10) unsigned', 'PRI', 'auto_increment', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'pages', 'about_us', 2, NULL, 'YES', 'blob', 65535, 65535, NULL, NULL, NULL, NULL, 'blob', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'pages', 'advertising_page', 3, NULL, 'YES', 'blob', 65535, 65535, NULL, NULL, NULL, NULL, 'blob', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'pages', 'music_features', 4, NULL, 'NO', 'blob', 65535, 65535, NULL, NULL, NULL, NULL, 'blob', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'pages', 'sponsors', 5, NULL, 'NO', 'blob', 65535, 65535, NULL, NULL, NULL, NULL, 'blob', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'pages', 'help', 6, NULL, 'NO', 'blob', 65535, 65535, NULL, NULL, NULL, NULL, 'blob', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'pages', 'admin_message', 7, NULL, 'NO', 'blob', 65535, 65535, NULL, NULL, NULL, NULL, 'blob', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'photo_rating', 'id', 1, NULL, 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10) unsigned', 'PRI', 'auto_increment', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'photo_rating', 'photo_id', 2, '0', 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'photo_rating', 'member_id', 3, '0', 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'photo_rating', 'rating', 4, '0', 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'photo_rating', 'comment', 5, NULL, 'NO', 'blob', 65535, 65535, NULL, NULL, NULL, NULL, 'blob', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'photo_rating', 'posted_by', 6, '0', 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'photo_rating', 'posted_on', 7, '', 'NO', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'photo_rating', 'approved', 8, '1', 'YES', 'tinyint', NULL, NULL, 3, 0, NULL, NULL, 'tinyint(3) unsigned', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'photos', 'photo_id', 1, NULL, 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10) unsigned', 'PRI', 'auto_increment', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'photos', 'member_id', 2, NULL, 'YES', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(11)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'photos', 'photo_url', 3, NULL, 'YES', 'varchar', 100, 300, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(100)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'photos', 'enable', 4, NULL, 'YES', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'photos', 'small_photos', 5, NULL, 'YES', 'varchar', 100, 300, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(100)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'photos', 'main_image', 6, '0', 'NO', 'varchar', 10, 30, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'photos', 'caption', 7, '', 'NO', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'polls', 'idpolls', 1, NULL, 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10) unsigned', 'PRI', 'auto_increment', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'polls', 'polls_categories_idpolls_categories', 2, '0', 'YES', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10) unsigned', 'MUL', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'polls', 'question', 3, NULL, 'YES', 'text', 65535, 65535, NULL, NULL, 'utf8', 'utf8_general_ci', 'text', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'polls', 'date_created', 4, NULL, 'YES', 'datetime', NULL, NULL, NULL, NULL, NULL, NULL, 'datetime', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'polls', 'owner_id', 5, NULL, 'YES', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10) unsigned', 'MUL', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'polls', 'is_default', 6, '0', 'YES', 'char', 1, 3, NULL, NULL, 'utf8', 'utf8_general_ci', 'char(1)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'polls', 'is_active', 7, '1', 'YES', 'char', 1, 3, NULL, NULL, 'utf8', 'utf8_general_ci', 'char(1)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'polls_answers', 'idpolls_answers', 1, NULL, 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10) unsigned', 'PRI', 'auto_increment', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'polls_answers', 'polls_idpolls', 2, '0', 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(11)', 'MUL', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'polls_answers', 'poll_answ_txt', 3, '', 'NO', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'polls_answers', 'poll_answ_votes', 4, '0', 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10) unsigned', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'polls_categories', 'idpolls_categories', 1, NULL, 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10) unsigned', 'PRI', 'auto_increment', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'polls_categories', 'cat_name', 2, NULL, 'YES', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', 'MUL', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'polls_categories', 'cat_desc', 3, NULL, 'YES', 'text', 65535, 65535, NULL, NULL, 'utf8', 'utf8_general_ci', 'text', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'polls_log', 'idpolls_log', 1, NULL, 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10) unsigned', 'PRI', 'auto_increment', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'polls_log', 'polls_answers_idpolls_answers', 2, '0', 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10) unsigned', 'MUL', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'polls_log', 'polls_idpolls', 3, '0', 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10) unsigned', 'MUL', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'polls_log', 'vote_datetime', 4, NULL, 'YES', 'datetime', NULL, NULL, NULL, NULL, NULL, NULL, 'datetime', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'polls_log', 'voter_id', 5, NULL, 'YES', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10) unsigned', 'MUL', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'polls_log', 'voter_ip', 6, NULL, 'YES', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10) unsigned', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'privacy', 'privacy_id', 1, NULL, 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10) unsigned', 'PRI', 'auto_increment', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'privacy', 'privacy_text', 2, NULL, 'YES', 'blob', 65535, 65535, NULL, NULL, NULL, NULL, 'blob', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'profile_back', 'id', 1, NULL, 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10) unsigned', 'PRI', 'auto_increment', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'profile_back', 'member_id', 2, '0', 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'profile_back', 'marital_status', 3, '', 'NO', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'profile_back', 'sexual', 4, '', 'NO', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'profile_back', 'home_town', 5, '', 'NO', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'profile_back', 'religion', 6, '', 'NO', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'profile_back', 'smoker', 7, '', 'NO', 'varchar', 30, 90, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(30)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'profile_back', 'children', 8, '', 'NO', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'profile_back', 'education', 9, '', 'NO', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'profile_back', 'income', 10, '', 'NO', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'profile_back', 'drinker', 11, '', 'NO', 'varchar', 20, 60, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(20)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'profile_company', 'id', 1, NULL, 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10) unsigned', 'PRI', 'auto_increment', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'profile_company', 'member_id', 2, '0', 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'profile_company', 'company_name', 3, '', 'NO', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'profile_company', 'company_state', 4, '', 'NO', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'profile_company', 'company_country', 5, '', 'NO', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'profile_company', 'date_employed', 6, '', 'NO', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'profile_company', 'title', 7, '', 'NO', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'profile_company', 'division', 8, '', 'NO', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'profile_company', 'company_city', 9, '', 'NO', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'profile_flag', 'flag_id', 1, NULL, 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10) unsigned', 'PRI', 'auto_increment', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'profile_flag', 'member_id', 2, NULL, 'YES', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(11)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'profile_flag', 'member_by', 3, NULL, 'YES', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(11)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'profile_interests', 'id', 1, NULL, 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10) unsigned', 'PRI', 'auto_increment', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'profile_interests', 'member_id', 2, '0', 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'profile_interests', 'headline', 3, '', 'NO', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'profile_interests', 'about_me', 4, NULL, 'NO', 'blob', 65535, 65535, NULL, NULL, NULL, NULL, 'blob', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'profile_interests', 'meet', 5, NULL, 'NO', 'blob', 65535, 65535, NULL, NULL, NULL, NULL, 'blob', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'profile_interests', 'interests', 6, NULL, 'NO', 'blob', 65535, 65535, NULL, NULL, NULL, NULL, 'blob', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'profile_interests', 'music', 7, NULL, 'NO', 'blob', 65535, 65535, NULL, NULL, NULL, NULL, 'blob', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'profile_interests', 'movies', 8, NULL, 'NO', 'blob', 65535, 65535, NULL, NULL, NULL, NULL, 'blob', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'profile_interests', 'television', 9, NULL, 'NO', 'blob', 65535, 65535, NULL, NULL, NULL, NULL, 'blob', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'profile_interests', 'heroes', 10, NULL, 'NO', 'blob', 65535, 65535, NULL, NULL, NULL, NULL, 'blob', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'profile_interests', 'books', 11, NULL, 'NO', 'blob', 65535, 65535, NULL, NULL, NULL, NULL, 'blob', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'profile_school', 'id', 1, NULL, 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10) unsigned', 'PRI', 'auto_increment', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'profile_school', 'member_id', 2, '0', 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'profile_school', 'school_name', 3, '', 'NO', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'profile_school', 'school_city', 4, '', 'NO', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'profile_school', 'school_state', 5, '', 'NO', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'profile_school', 'status', 6, '', 'NO', 'varchar', 30, 90, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(30)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'profile_school', 'date_from', 7, '', 'NO', 'varchar', 20, 60, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(20)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'profile_school', 'date_to', 8, '', 'NO', 'varchar', 20, 60, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(20)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'profile_school', 'degree', 9, '', 'NO', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'profile_school', 'current_courses', 10, '', 'NO', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'profile_school', 'clubs_organizations', 11, NULL, 'NO', 'blob', 65535, 65535, NULL, NULL, NULL, NULL, 'blob', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'profile_school', 'graduation_year', 12, '', 'NO', 'varchar', 20, 60, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(20)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'profile_school', 'major', 13, '', 'NO', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'profile_spam', 'id', 1, NULL, 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10) unsigned', 'PRI', 'auto_increment', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'profile_spam', 'member_id', 2, '0', 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'profile_spam', 'member_by', 3, '0', 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'profile_spam', 'mail_id', 4, '0', 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'profile_spam', 'reported_on', 5, '', 'NO', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'profile_views', 'date', 1, NULL, 'YES', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10) unsigned', 'MUL', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'profile_views', 'ip', 2, NULL, 'YES', 'varchar', 15, 45, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(15)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'profile_views', 'member_id', 3, NULL, 'YES', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10) unsigned', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'profile_views', 'profile_id', 4, NULL, 'YES', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10) unsigned', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'school_name', 'school_id', 1, NULL, 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10) unsigned', 'PRI', 'auto_increment', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'school_name', 'city_id', 2, NULL, 'YES', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(11)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'school_name', 'state_id', 3, NULL, 'YES', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(11)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'school_name', 'school_name', 4, NULL, 'YES', 'varchar', 100, 300, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(100)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'school_name', 'enable', 5, NULL, 'YES', 'char', 1, 3, NULL, NULL, 'utf8', 'utf8_general_ci', 'char(1)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'schools', 'school_id', 1, NULL, 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10) unsigned', 'PRI', 'auto_increment', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'schools', 'state_id', 2, NULL, 'YES', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(11)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'schools', 'school_name', 3, NULL, 'YES', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'schools', 'school_city', 4, NULL, 'YES', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(11)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'schools', 'listed', 5, NULL, 'YES', 'char', 1, 3, NULL, NULL, 'utf8', 'utf8_general_ci', 'char(1)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'settings', 'field_name', 1, NULL, 'YES', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'settings', 'field_value', 2, NULL, 'YES', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'shown_images', 'id', 1, NULL, 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10) unsigned', 'PRI', 'auto_increment', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'shown_images', 'session_id', 2, '', 'NO', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'shown_images', 'photo_id', 3, '0', 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'song_critisize', 'id', 1, NULL, 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10) unsigned', 'PRI', 'auto_increment', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'song_critisize', 'song_id', 2, '0', 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'song_critisize', 'posted_by', 3, '0', 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'song_critisize', 'comments', 4, NULL, 'NO', 'blob', 65535, 65535, NULL, NULL, NULL, NULL, 'blob', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'song_critisize', 'posted_on', 5, '', 'NO', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'song_rating', 'id', 1, NULL, 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10) unsigned', 'PRI', 'auto_increment', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'song_rating', 'rating_by', 2, '0', 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'song_rating', 'song_id', 3, '0', 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'song_rating', 'rating', 4, '0', 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'song_rating', 'rating_comment', 5, NULL, 'NO', 'blob', 65535, 65535, NULL, NULL, NULL, NULL, 'blob', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'states', 'state_id', 1, NULL, 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10) unsigned', 'PRI', 'auto_increment', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'states', 'state_name', 2, NULL, 'YES', 'varchar', 100, 300, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(100)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'states', 'def', 3, '0', 'YES', 'tinyint', NULL, NULL, 3, 0, NULL, NULL, 'tinyint(3) unsigned', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'states_1', 'state_id', 1, NULL, 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10) unsigned', 'PRI', 'auto_increment', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'states_1', 'state_name', 2, NULL, 'YES', 'varchar', 100, 300, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(100)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'terms', 'term_id', 1, NULL, 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10) unsigned', 'PRI', 'auto_increment', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'terms', 'term_text', 2, NULL, 'YES', 'blob', 65535, 65535, NULL, NULL, NULL, NULL, 'blob', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'testimonials', 'test_id', 1, NULL, 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10) unsigned', 'PRI', 'auto_increment', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'testimonials', 'test_text', 2, NULL, 'YES', 'blob', 65535, 65535, NULL, NULL, NULL, NULL, 'blob', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'testimonials', 'test_user', 3, NULL, 'YES', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(11)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'testimonials', 'member_id', 4, NULL, 'YES', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(11)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'testimonials', 'approved', 5, NULL, 'YES', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(11)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'testimonials', 'date_posted', 6, NULL, 'YES', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'top_8_friends', 'id', 1, NULL, 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10) unsigned', 'PRI', 'auto_increment', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'top_8_friends', 'member_id', 2, '0', 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'top_8_friends', 'friend_id', 3, '0', 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'video_albums', 'id', 1, NULL, 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10) unsigned', 'PRI', 'auto_increment', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'video_albums', 'album_title', 2, '', 'NO', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'video_albums', 'album_desc', 3, NULL, 'NO', 'blob', 65535, 65535, NULL, NULL, NULL, NULL, 'blob', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'video_albums', 'album_type', 4, '', 'NO', 'varchar', 10, 30, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'video_albums', 'member_id', 5, '0', 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'video_albums', 'posted_on', 6, '', 'NO', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'video_category', 'id', 1, NULL, 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10) unsigned', 'PRI', 'auto_increment', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'video_category', 'cat_name', 2, '', 'NO', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'video_category', 'cat_desc', 3, NULL, 'NO', 'blob', 65535, 65535, NULL, NULL, NULL, NULL, 'blob', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'video_comments', 'id', 1, NULL, 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10) unsigned', 'PRI', 'auto_increment', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'video_comments', 'video_id', 2, '0', 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'video_comments', 'posted_on', 3, '', 'NO', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'video_comments', 'mood', 4, '', 'NO', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'video_comments', 'rate', 5, '0', 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'video_comments', 'comment', 6, NULL, 'NO', 'blob', 65535, 65535, NULL, NULL, NULL, NULL, 'blob', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'video_comments', 'recommend', 7, '', 'NO', 'varchar', 10, 30, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'video_comments', 'posted_by', 8, '0', 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'video_favorite', 'id', 1, NULL, 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10) unsigned', 'PRI', 'auto_increment', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'video_favorite', 'member_id', 2, '0', 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'video_favorite', 'video_id', 3, '0', 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'video_favorite', 'posted_on', 4, '', 'NO', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'video_members', 'id', 1, NULL, 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10) unsigned', 'PRI', 'auto_increment', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'video_members', 'video_album', 2, '0', 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'video_members', 'video_file', 3, '', 'NO', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'video_members', 'video_thumbnail', 4, '', 'NO', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'video_members', 'video_cat', 5, '0', 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'video_members', 'video_title', 6, '', 'NO', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'video_members', 'video_caption', 7, '', 'NO', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'video_members', 'video_tags', 8, NULL, 'NO', 'blob', 65535, 65535, NULL, NULL, NULL, NULL, 'blob', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'video_members', 'video_type', 9, '', 'NO', 'varchar', 10, 30, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'video_members', 'video_codes_allow', 10, '1', 'NO', 'varchar', 10, 30, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'video_members', 'member_id', 11, '0', 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'video_members', 'posted_on', 12, '', 'NO', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'video_members', 'views', 13, '0', 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'video_members', 'asx_file', 14, '', 'NO', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'video_members', 'upload_ip', 15, '', 'NO', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'video_members', 'total_comments', 16, '0', 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'video_members', 'total_favorite', 17, '0', 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'video_members', 'last_viewed', 18, '0', 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'video_members', 'featured', 19, '0', 'NO', 'varchar', 10, 30, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'video_playlist', 'id', 1, NULL, 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10) unsigned', 'PRI', 'auto_increment', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'video_playlist', 'member_id', 2, '0', 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'video_playlist', 'video_id', 3, '0', 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES (NULL, 'ruskidom3', 'video_playlist', 'posted_on', 4, '', 'NO', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', '', '', 'select,insert,update', '');

-- --------------------------------------------------------

-- 
-- Table structure for table `COLUMN_PRIVILEGES`
-- 

CREATE TEMPORARY TABLE `COLUMN_PRIVILEGES` (
  `GRANTEE` varchar(81) NOT NULL default '',
  `TABLE_CATALOG` varchar(512) default NULL,
  `TABLE_SCHEMA` varchar(64) NOT NULL default '',
  `TABLE_NAME` varchar(64) NOT NULL default '',
  `COLUMN_NAME` varchar(64) NOT NULL default '',
  `PRIVILEGE_TYPE` varchar(64) NOT NULL default '',
  `IS_GRANTABLE` varchar(3) NOT NULL default ''
) TYPE=MEMORY ;

-- 
-- Dumping data for table `COLUMN_PRIVILEGES`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `KEY_COLUMN_USAGE`
-- 

CREATE TEMPORARY TABLE `KEY_COLUMN_USAGE` (
  `CONSTRAINT_CATALOG` varchar(512) default NULL,
  `CONSTRAINT_SCHEMA` varchar(64) NOT NULL default '',
  `CONSTRAINT_NAME` varchar(64) NOT NULL default '',
  `TABLE_CATALOG` varchar(512) default NULL,
  `TABLE_SCHEMA` varchar(64) NOT NULL default '',
  `TABLE_NAME` varchar(64) NOT NULL default '',
  `COLUMN_NAME` varchar(64) NOT NULL default '',
  `ORDINAL_POSITION` bigint(10) NOT NULL default '0',
  `POSITION_IN_UNIQUE_CONSTRAINT` bigint(10) default NULL,
  `REFERENCED_TABLE_SCHEMA` varchar(64) default NULL,
  `REFERENCED_TABLE_NAME` varchar(64) default NULL,
  `REFERENCED_COLUMN_NAME` varchar(64) default NULL
) TYPE=MEMORY ;

-- 
-- Dumping data for table `KEY_COLUMN_USAGE`
-- 

INSERT INTO `KEY_COLUMN_USAGE` VALUES (NULL, 'ruskidom3', 'address_id', NULL, 'ruskidom3', 'address_book', 'address_id', 1, NULL, NULL, NULL, NULL);
INSERT INTO `KEY_COLUMN_USAGE` VALUES (NULL, 'ruskidom3', 'admin_id', NULL, 'ruskidom3', 'admin_control', 'admin_id', 1, NULL, NULL, NULL, NULL);
INSERT INTO `KEY_COLUMN_USAGE` VALUES (NULL, 'ruskidom3', 'message_id', NULL, 'ruskidom3', 'admin_message', 'message_id', 1, NULL, NULL, NULL, NULL);
INSERT INTO `KEY_COLUMN_USAGE` VALUES (NULL, 'ruskidom3', 'message_id', NULL, 'ruskidom3', 'admin_reply', 'message_id', 1, NULL, NULL, NULL, NULL);
INSERT INTO `KEY_COLUMN_USAGE` VALUES (NULL, 'ruskidom3', 'admin_id', NULL, 'ruskidom3', 'admin_users', 'admin_id', 1, NULL, NULL, NULL, NULL);
INSERT INTO `KEY_COLUMN_USAGE` VALUES (NULL, 'ruskidom3', 'PRIMARY', NULL, 'ruskidom3', 'auth', 'id', 1, NULL, NULL, NULL, NULL);
INSERT INTO `KEY_COLUMN_USAGE` VALUES (NULL, 'ruskidom3', 'id', NULL, 'ruskidom3', 'auth', 'id', 1, NULL, NULL, NULL, NULL);
INSERT INTO `KEY_COLUMN_USAGE` VALUES (NULL, 'ruskidom3', 'test_id', NULL, 'ruskidom3', 'band_review', 'test_id', 1, NULL, NULL, NULL, NULL);
INSERT INTO `KEY_COLUMN_USAGE` VALUES (NULL, 'ruskidom3', 'PRIMARY', NULL, 'ruskidom3', 'banned_ip', 'id', 1, NULL, NULL, NULL, NULL);
INSERT INTO `KEY_COLUMN_USAGE` VALUES (NULL, 'ruskidom3', 'PRIMARY', NULL, 'ruskidom3', 'blog_comments', 'id', 1, NULL, NULL, NULL, NULL);
INSERT INTO `KEY_COLUMN_USAGE` VALUES (NULL, 'ruskidom3', 'PRIMARY', NULL, 'ruskidom3', 'blog_moderators', 'id', 1, NULL, NULL, NULL, NULL);
INSERT INTO `KEY_COLUMN_USAGE` VALUES (NULL, 'ruskidom3', 'PRIMARY', NULL, 'ruskidom3', 'blog_mood', 'id', 1, NULL, NULL, NULL, NULL);
INSERT INTO `KEY_COLUMN_USAGE` VALUES (NULL, 'ruskidom3', 'PRIMARY', NULL, 'ruskidom3', 'blog_preffered', 'id', 1, NULL, NULL, NULL, NULL);
INSERT INTO `KEY_COLUMN_USAGE` VALUES (NULL, 'ruskidom3', 'PRIMARY', NULL, 'ruskidom3', 'blog_subscriptions', 'id', 1, NULL, NULL, NULL, NULL);
INSERT INTO `KEY_COLUMN_USAGE` VALUES (NULL, 'ruskidom3', 'PRIMARY', NULL, 'ruskidom3', 'blogs', 'id', 1, NULL, NULL, NULL, NULL);
INSERT INTO `KEY_COLUMN_USAGE` VALUES (NULL, 'ruskidom3', 'board_id', NULL, 'ruskidom3', 'board_main', 'message_id', 1, NULL, NULL, NULL, NULL);
INSERT INTO `KEY_COLUMN_USAGE` VALUES (NULL, 'ruskidom3', 'board_sub_id1', NULL, 'ruskidom3', 'board_reply', 'board_sub_id1', 1, NULL, NULL, NULL, NULL);
INSERT INTO `KEY_COLUMN_USAGE` VALUES (NULL, 'ruskidom3', 'board_sub_id', NULL, 'ruskidom3', 'board_sub', 'board_sub_id', 1, NULL, NULL, NULL, NULL);
INSERT INTO `KEY_COLUMN_USAGE` VALUES (NULL, 'ruskidom3', 'book_id', NULL, 'ruskidom3', 'bookmarks', 'book_id', 1, NULL, NULL, NULL, NULL);
INSERT INTO `KEY_COLUMN_USAGE` VALUES (NULL, 'ruskidom3', 'PRIMARY', NULL, 'ruskidom3', 'bulletin_message', 'id', 1, NULL, NULL, NULL, NULL);
INSERT INTO `KEY_COLUMN_USAGE` VALUES (NULL, 'ruskidom3', 'city_id', NULL, 'ruskidom3', 'cities', 'city_id', 1, NULL, NULL, NULL, NULL);
INSERT INTO `KEY_COLUMN_USAGE` VALUES (NULL, 'ruskidom3', 'PRIMARY', NULL, 'ruskidom3', 'classified_cat', 'id', 1, NULL, NULL, NULL, NULL);
INSERT INTO `KEY_COLUMN_USAGE` VALUES (NULL, 'ruskidom3', 'PRIMARY', NULL, 'ruskidom3', 'classified_listing', 'id', 1, NULL, NULL, NULL, NULL);
INSERT INTO `KEY_COLUMN_USAGE` VALUES (NULL, 'ruskidom3', 'PRIMARY', NULL, 'ruskidom3', 'classified_sub_cat', 'id', 1, NULL, NULL, NULL, NULL);
INSERT INTO `KEY_COLUMN_USAGE` VALUES (NULL, 'ruskidom3', 'college_id', NULL, 'ruskidom3', 'colleges', 'college_id', 1, NULL, NULL, NULL, NULL);
INSERT INTO `KEY_COLUMN_USAGE` VALUES (NULL, 'ruskidom3', 'PRIMARY', NULL, 'ruskidom3', 'events', 'id', 1, NULL, NULL, NULL, NULL);
INSERT INTO `KEY_COLUMN_USAGE` VALUES (NULL, 'ruskidom3', 'PRIMARY', NULL, 'ruskidom3', 'events_cat', 'id', 1, NULL, NULL, NULL, NULL);
INSERT INTO `KEY_COLUMN_USAGE` VALUES (NULL, 'ruskidom3', 'PRIMARY', NULL, 'ruskidom3', 'events_comments', 'id', 1, NULL, NULL, NULL, NULL);
INSERT INTO `KEY_COLUMN_USAGE` VALUES (NULL, 'ruskidom3', 'PRIMARY', NULL, 'ruskidom3', 'events_rsvp', 'id', 1, NULL, NULL, NULL, NULL);
INSERT INTO `KEY_COLUMN_USAGE` VALUES (NULL, 'ruskidom3', 'PRIMARY', NULL, 'ruskidom3', 'forum_main_cat', 'id', 1, NULL, NULL, NULL, NULL);
INSERT INTO `KEY_COLUMN_USAGE` VALUES (NULL, 'ruskidom3', 'PRIMARY', NULL, 'ruskidom3', 'forum_posts', 'id', 1, NULL, NULL, NULL, NULL);
INSERT INTO `KEY_COLUMN_USAGE` VALUES (NULL, 'ruskidom3', 'PRIMARY', NULL, 'ruskidom3', 'forum_sub_cat', 'id', 1, NULL, NULL, NULL, NULL);
INSERT INTO `KEY_COLUMN_USAGE` VALUES (NULL, 'ruskidom3', 'PRIMARY', NULL, 'ruskidom3', 'forum_topics', 'id', 1, NULL, NULL, NULL, NULL);
INSERT INTO `KEY_COLUMN_USAGE` VALUES (NULL, 'ruskidom3', 'book_id', NULL, 'ruskidom3', 'g_bookmarks', 'book_id', 1, NULL, NULL, NULL, NULL);
INSERT INTO `KEY_COLUMN_USAGE` VALUES (NULL, 'ruskidom3', 'journal_id', NULL, 'ruskidom3', 'g_journal', 'journal_id', 1, NULL, NULL, NULL, NULL);
INSERT INTO `KEY_COLUMN_USAGE` VALUES (NULL, 'ruskidom3', 'mess_id', NULL, 'ruskidom3', 'g_messages', 'mess_id', 1, NULL, NULL, NULL, NULL);
INSERT INTO `KEY_COLUMN_USAGE` VALUES (NULL, 'ruskidom3', 'test_id', NULL, 'ruskidom3', 'g_testimonials', 'test_id', 1, NULL, NULL, NULL, NULL);
INSERT INTO `KEY_COLUMN_USAGE` VALUES (NULL, 'ruskidom3', 'PRIMARY', NULL, 'ruskidom3', 'group_bulletin', 'id', 1, NULL, NULL, NULL, NULL);
INSERT INTO `KEY_COLUMN_USAGE` VALUES (NULL, 'ruskidom3', 'PRIMARY', NULL, 'ruskidom3', 'group_bulletin_reply', 'id', 1, NULL, NULL, NULL, NULL);
INSERT INTO `KEY_COLUMN_USAGE` VALUES (NULL, 'ruskidom3', 'PRIMARY', NULL, 'ruskidom3', 'group_cat', 'id', 1, NULL, NULL, NULL, NULL);
INSERT INTO `KEY_COLUMN_USAGE` VALUES (NULL, 'ruskidom3', 'id', NULL, 'ruskidom3', 'group_friends', 'id', 1, NULL, NULL, NULL, NULL);
INSERT INTO `KEY_COLUMN_USAGE` VALUES (NULL, 'ruskidom3', 'invite_id', NULL, 'ruskidom3', 'group_invites', 'invite_id', 1, NULL, NULL, NULL, NULL);
INSERT INTO `KEY_COLUMN_USAGE` VALUES (NULL, 'ruskidom3', 'photo_id', NULL, 'ruskidom3', 'group_photos', 'photo_id', 1, NULL, NULL, NULL, NULL);
INSERT INTO `KEY_COLUMN_USAGE` VALUES (NULL, 'ruskidom3', 'PRIMARY', NULL, 'ruskidom3', 'group_topic_reply', 'id', 1, NULL, NULL, NULL, NULL);
INSERT INTO `KEY_COLUMN_USAGE` VALUES (NULL, 'ruskidom3', 'PRIMARY', NULL, 'ruskidom3', 'group_topics', 'id', 1, NULL, NULL, NULL, NULL);
INSERT INTO `KEY_COLUMN_USAGE` VALUES (NULL, 'ruskidom3', 'PRIMARY', NULL, 'ruskidom3', 'groups', 'id', 1, NULL, NULL, NULL, NULL);
INSERT INTO `KEY_COLUMN_USAGE` VALUES (NULL, 'ruskidom3', 'group_id', NULL, 'ruskidom3', 'groups_creator', 'group_id', 1, NULL, NULL, NULL, NULL);
INSERT INTO `KEY_COLUMN_USAGE` VALUES (NULL, 'ruskidom3', 'PRIMARY', NULL, 'ruskidom3', 'hotornot_rating', 'id', 1, NULL, NULL, NULL, NULL);
INSERT INTO `KEY_COLUMN_USAGE` VALUES (NULL, 'ruskidom3', 'PRIMARY', NULL, 'ruskidom3', 'invitations', 'id', 1, NULL, NULL, NULL, NULL);
INSERT INTO `KEY_COLUMN_USAGE` VALUES (NULL, 'ruskidom3', 'id', NULL, 'ruskidom3', 'invitations', 'id', 1, NULL, NULL, NULL, NULL);
INSERT INTO `KEY_COLUMN_USAGE` VALUES (NULL, 'ruskidom3', 'invite_id', NULL, 'ruskidom3', 'invite_temp_emails', 'invite_id', 1, NULL, NULL, NULL, NULL);
INSERT INTO `KEY_COLUMN_USAGE` VALUES (NULL, 'ruskidom3', 'invite_id', NULL, 'ruskidom3', 'invite_temp_group_emails', 'invite_id', 1, NULL, NULL, NULL, NULL);
INSERT INTO `KEY_COLUMN_USAGE` VALUES (NULL, 'ruskidom3', 'invite_id', NULL, 'ruskidom3', 'invites', 'invite_id', 1, NULL, NULL, NULL, NULL);
INSERT INTO `KEY_COLUMN_USAGE` VALUES (NULL, 'ruskidom3', 'journal_id', NULL, 'ruskidom3', 'journal', 'journal_id', 1, NULL, NULL, NULL, NULL);
INSERT INTO `KEY_COLUMN_USAGE` VALUES (NULL, 'ruskidom3', 'comment_id', NULL, 'ruskidom3', 'journal_comment', 'comment_id', 1, NULL, NULL, NULL, NULL);
INSERT INTO `KEY_COLUMN_USAGE` VALUES (NULL, 'ruskidom3', 'login_id', NULL, 'ruskidom3', 'login_page', 'login_id', 1, NULL, NULL, NULL, NULL);
INSERT INTO `KEY_COLUMN_USAGE` VALUES (NULL, 'ruskidom3', 'main_id', NULL, 'ruskidom3', 'main_page', 'main_id', 1, NULL, NULL, NULL, NULL);
INSERT INTO `KEY_COLUMN_USAGE` VALUES (NULL, 'ruskidom3', 'id', NULL, 'ruskidom3', 'member_friends', 'id', 1, NULL, NULL, NULL, NULL);
INSERT INTO `KEY_COLUMN_USAGE` VALUES (NULL, 'ruskidom3', 'PRIMARY', NULL, 'ruskidom3', 'member_networking', 'id', 1, NULL, NULL, NULL, NULL);
INSERT INTO `KEY_COLUMN_USAGE` VALUES (NULL, 'ruskidom3', 'member_id', NULL, 'ruskidom3', 'members', 'member_id', 1, NULL, NULL, NULL, NULL);
INSERT INTO `KEY_COLUMN_USAGE` VALUES (NULL, 'ruskidom3', 'mess_id', NULL, 'ruskidom3', 'messages', 'mess_id', 1, NULL, NULL, NULL, NULL);
INSERT INTO `KEY_COLUMN_USAGE` VALUES (NULL, 'ruskidom3', 'mess_id', NULL, 'ruskidom3', 'messages_sent', 'mess_id', 1, NULL, NULL, NULL, NULL);
INSERT INTO `KEY_COLUMN_USAGE` VALUES (NULL, 'ruskidom3', 'PRIMARY', NULL, 'ruskidom3', 'misc', 'id', 1, NULL, NULL, NULL, NULL);
INSERT INTO `KEY_COLUMN_USAGE` VALUES (NULL, 'ruskidom3', 'PRIMARY', NULL, 'ruskidom3', 'moderators_classified', 'id', 1, NULL, NULL, NULL, NULL);
INSERT INTO `KEY_COLUMN_USAGE` VALUES (NULL, 'ruskidom3', 'PRIMARY', NULL, 'ruskidom3', 'moderators_events', 'id', 1, NULL, NULL, NULL, NULL);
INSERT INTO `KEY_COLUMN_USAGE` VALUES (NULL, 'ruskidom3', 'PRIMARY', NULL, 'ruskidom3', 'moderators_groups', 'id', 1, NULL, NULL, NULL, NULL);
INSERT INTO `KEY_COLUMN_USAGE` VALUES (NULL, 'ruskidom3', 'PRIMARY', NULL, 'ruskidom3', 'moderators_music', 'id', 1, NULL, NULL, NULL, NULL);
INSERT INTO `KEY_COLUMN_USAGE` VALUES (NULL, 'ruskidom3', 'PRIMARY', NULL, 'ruskidom3', 'moderators_pics', 'id', 1, NULL, NULL, NULL, NULL);
INSERT INTO `KEY_COLUMN_USAGE` VALUES (NULL, 'ruskidom3', 'PRIMARY', NULL, 'ruskidom3', 'most_popular', 'id', 1, NULL, NULL, NULL, NULL);
INSERT INTO `KEY_COLUMN_USAGE` VALUES (NULL, 'ruskidom3', 'PRIMARY', NULL, 'ruskidom3', 'music_genre', 'id', 1, NULL, NULL, NULL, NULL);
INSERT INTO `KEY_COLUMN_USAGE` VALUES (NULL, 'ruskidom3', 'PRIMARY', NULL, 'ruskidom3', 'music_member_profile', 'id', 1, NULL, NULL, NULL, NULL);
INSERT INTO `KEY_COLUMN_USAGE` VALUES (NULL, 'ruskidom3', 'PRIMARY', NULL, 'ruskidom3', 'music_members', 'id', 1, NULL, NULL, NULL, NULL);
INSERT INTO `KEY_COLUMN_USAGE` VALUES (NULL, 'ruskidom3', 'PRIMARY', NULL, 'ruskidom3', 'music_profile', 'id', 1, NULL, NULL, NULL, NULL);
INSERT INTO `KEY_COLUMN_USAGE` VALUES (NULL, 'ruskidom3', 'PRIMARY', NULL, 'ruskidom3', 'music_shows', 'id', 1, NULL, NULL, NULL, NULL);
INSERT INTO `KEY_COLUMN_USAGE` VALUES (NULL, 'ruskidom3', 'PRIMARY', NULL, 'ruskidom3', 'music_songs', 'id', 1, NULL, NULL, NULL, NULL);
INSERT INTO `KEY_COLUMN_USAGE` VALUES (NULL, 'ruskidom3', 'PRIMARY', NULL, 'ruskidom3', 'news', 'id', 1, NULL, NULL, NULL, NULL);
INSERT INTO `KEY_COLUMN_USAGE` VALUES (NULL, 'ruskidom3', 'PRIMARY', NULL, 'ruskidom3', 'online_now', 'id', 1, NULL, NULL, NULL, NULL);
INSERT INTO `KEY_COLUMN_USAGE` VALUES (NULL, 'ruskidom3', 'PRIMARY', NULL, 'ruskidom3', 'packages', 'id', 1, NULL, NULL, NULL, NULL);
INSERT INTO `KEY_COLUMN_USAGE` VALUES (NULL, 'ruskidom3', 'page_id', NULL, 'ruskidom3', 'pages', 'page_id', 1, NULL, NULL, NULL, NULL);
INSERT INTO `KEY_COLUMN_USAGE` VALUES (NULL, 'ruskidom3', 'PRIMARY', NULL, 'ruskidom3', 'photo_rating', 'id', 1, NULL, NULL, NULL, NULL);
INSERT INTO `KEY_COLUMN_USAGE` VALUES (NULL, 'ruskidom3', 'photo_id', NULL, 'ruskidom3', 'photos', 'photo_id', 1, NULL, NULL, NULL, NULL);
INSERT INTO `KEY_COLUMN_USAGE` VALUES (NULL, 'ruskidom3', 'PRIMARY', NULL, 'ruskidom3', 'polls', 'idpolls', 1, NULL, NULL, NULL, NULL);
INSERT INTO `KEY_COLUMN_USAGE` VALUES (NULL, 'ruskidom3', 'PRIMARY', NULL, 'ruskidom3', 'polls_answers', 'idpolls_answers', 1, NULL, NULL, NULL, NULL);
INSERT INTO `KEY_COLUMN_USAGE` VALUES (NULL, 'ruskidom3', 'PRIMARY', NULL, 'ruskidom3', 'polls_categories', 'idpolls_categories', 1, NULL, NULL, NULL, NULL);
INSERT INTO `KEY_COLUMN_USAGE` VALUES (NULL, 'ruskidom3', 'PRIMARY', NULL, 'ruskidom3', 'polls_log', 'idpolls_log', 1, NULL, NULL, NULL, NULL);
INSERT INTO `KEY_COLUMN_USAGE` VALUES (NULL, 'ruskidom3', 'privacy_id', NULL, 'ruskidom3', 'privacy', 'privacy_id', 1, NULL, NULL, NULL, NULL);
INSERT INTO `KEY_COLUMN_USAGE` VALUES (NULL, 'ruskidom3', 'PRIMARY', NULL, 'ruskidom3', 'profile_back', 'id', 1, NULL, NULL, NULL, NULL);
INSERT INTO `KEY_COLUMN_USAGE` VALUES (NULL, 'ruskidom3', 'PRIMARY', NULL, 'ruskidom3', 'profile_company', 'id', 1, NULL, NULL, NULL, NULL);
INSERT INTO `KEY_COLUMN_USAGE` VALUES (NULL, 'ruskidom3', 'flag_id', NULL, 'ruskidom3', 'profile_flag', 'flag_id', 1, NULL, NULL, NULL, NULL);
INSERT INTO `KEY_COLUMN_USAGE` VALUES (NULL, 'ruskidom3', 'PRIMARY', NULL, 'ruskidom3', 'profile_interests', 'id', 1, NULL, NULL, NULL, NULL);
INSERT INTO `KEY_COLUMN_USAGE` VALUES (NULL, 'ruskidom3', 'PRIMARY', NULL, 'ruskidom3', 'profile_school', 'id', 1, NULL, NULL, NULL, NULL);
INSERT INTO `KEY_COLUMN_USAGE` VALUES (NULL, 'ruskidom3', 'PRIMARY', NULL, 'ruskidom3', 'profile_spam', 'id', 1, NULL, NULL, NULL, NULL);
INSERT INTO `KEY_COLUMN_USAGE` VALUES (NULL, 'ruskidom3', 'school_id', NULL, 'ruskidom3', 'school_name', 'school_id', 1, NULL, NULL, NULL, NULL);
INSERT INTO `KEY_COLUMN_USAGE` VALUES (NULL, 'ruskidom3', 'school_id', NULL, 'ruskidom3', 'schools', 'school_id', 1, NULL, NULL, NULL, NULL);
INSERT INTO `KEY_COLUMN_USAGE` VALUES (NULL, 'ruskidom3', 'PRIMARY', NULL, 'ruskidom3', 'shown_images', 'id', 1, NULL, NULL, NULL, NULL);
INSERT INTO `KEY_COLUMN_USAGE` VALUES (NULL, 'ruskidom3', 'PRIMARY', NULL, 'ruskidom3', 'song_critisize', 'id', 1, NULL, NULL, NULL, NULL);
INSERT INTO `KEY_COLUMN_USAGE` VALUES (NULL, 'ruskidom3', 'PRIMARY', NULL, 'ruskidom3', 'song_rating', 'id', 1, NULL, NULL, NULL, NULL);
INSERT INTO `KEY_COLUMN_USAGE` VALUES (NULL, 'ruskidom3', 'state_id', NULL, 'ruskidom3', 'states', 'state_id', 1, NULL, NULL, NULL, NULL);
INSERT INTO `KEY_COLUMN_USAGE` VALUES (NULL, 'ruskidom3', 'state_id', NULL, 'ruskidom3', 'states_1', 'state_id', 1, NULL, NULL, NULL, NULL);
INSERT INTO `KEY_COLUMN_USAGE` VALUES (NULL, 'ruskidom3', 'term_id', NULL, 'ruskidom3', 'terms', 'term_id', 1, NULL, NULL, NULL, NULL);
INSERT INTO `KEY_COLUMN_USAGE` VALUES (NULL, 'ruskidom3', 'test_id', NULL, 'ruskidom3', 'testimonials', 'test_id', 1, NULL, NULL, NULL, NULL);
INSERT INTO `KEY_COLUMN_USAGE` VALUES (NULL, 'ruskidom3', 'PRIMARY', NULL, 'ruskidom3', 'top_8_friends', 'id', 1, NULL, NULL, NULL, NULL);
INSERT INTO `KEY_COLUMN_USAGE` VALUES (NULL, 'ruskidom3', 'PRIMARY', NULL, 'ruskidom3', 'video_albums', 'id', 1, NULL, NULL, NULL, NULL);
INSERT INTO `KEY_COLUMN_USAGE` VALUES (NULL, 'ruskidom3', 'PRIMARY', NULL, 'ruskidom3', 'video_category', 'id', 1, NULL, NULL, NULL, NULL);
INSERT INTO `KEY_COLUMN_USAGE` VALUES (NULL, 'ruskidom3', 'PRIMARY', NULL, 'ruskidom3', 'video_comments', 'id', 1, NULL, NULL, NULL, NULL);
INSERT INTO `KEY_COLUMN_USAGE` VALUES (NULL, 'ruskidom3', 'PRIMARY', NULL, 'ruskidom3', 'video_favorite', 'id', 1, NULL, NULL, NULL, NULL);
INSERT INTO `KEY_COLUMN_USAGE` VALUES (NULL, 'ruskidom3', 'PRIMARY', NULL, 'ruskidom3', 'video_members', 'id', 1, NULL, NULL, NULL, NULL);
INSERT INTO `KEY_COLUMN_USAGE` VALUES (NULL, 'ruskidom3', 'PRIMARY', NULL, 'ruskidom3', 'video_playlist', 'id', 1, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

-- 
-- Table structure for table `PROFILING`
-- 

CREATE TEMPORARY TABLE `PROFILING` (
  `QUERY_ID` bigint(20) NOT NULL default '0',
  `SEQ` bigint(20) NOT NULL default '0',
  `STATE` varchar(30) NOT NULL default '',
  `DURATION` varchar(9) NOT NULL default '',
  `CPU_USER` varchar(9) default NULL,
  `CPU_SYSTEM` varchar(9) default NULL,
  `CONTEXT_VOLUNTARY` bigint(20) default NULL,
  `CONTEXT_INVOLUNTARY` bigint(20) default NULL,
  `BLOCK_OPS_IN` bigint(20) default NULL,
  `BLOCK_OPS_OUT` bigint(20) default NULL,
  `MESSAGES_SENT` bigint(20) default NULL,
  `MESSAGES_RECEIVED` bigint(20) default NULL,
  `PAGE_FAULTS_MAJOR` bigint(20) default NULL,
  `PAGE_FAULTS_MINOR` bigint(20) default NULL,
  `SWAPS` bigint(20) default NULL,
  `SOURCE_FUNCTION` varchar(30) default NULL,
  `SOURCE_FILE` varchar(20) default NULL,
  `SOURCE_LINE` bigint(20) default NULL
) TYPE=MEMORY ;

-- 
-- Dumping data for table `PROFILING`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `ROUTINES`
-- 

CREATE TEMPORARY TABLE `ROUTINES` (
  `SPECIFIC_NAME` varchar(64) NOT NULL default '',
  `ROUTINE_CATALOG` varchar(512) default NULL,
  `ROUTINE_SCHEMA` varchar(64) NOT NULL default '',
  `ROUTINE_NAME` varchar(64) NOT NULL default '',
  `ROUTINE_TYPE` varchar(9) NOT NULL default '',
  `DTD_IDENTIFIER` varchar(64) default NULL,
  `ROUTINE_BODY` varchar(8) NOT NULL default '',
  `ROUTINE_DEFINITION` longtext,
  `EXTERNAL_NAME` varchar(64) default NULL,
  `EXTERNAL_LANGUAGE` varchar(64) default NULL,
  `PARAMETER_STYLE` varchar(8) NOT NULL default '',
  `IS_DETERMINISTIC` varchar(3) NOT NULL default '',
  `SQL_DATA_ACCESS` varchar(64) NOT NULL default '',
  `SQL_PATH` varchar(64) default NULL,
  `SECURITY_TYPE` varchar(7) NOT NULL default '',
  `CREATED` datetime NOT NULL default '0000-00-00 00:00:00',
  `LAST_ALTERED` datetime NOT NULL default '0000-00-00 00:00:00',
  `SQL_MODE` longtext NOT NULL,
  `ROUTINE_COMMENT` varchar(64) NOT NULL default '',
  `DEFINER` varchar(77) NOT NULL default ''
) TYPE=MyISAM ;

-- 
-- Dumping data for table `ROUTINES`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `SCHEMATA`
-- 

CREATE TEMPORARY TABLE `SCHEMATA` (
  `CATALOG_NAME` varchar(512) default NULL,
  `SCHEMA_NAME` varchar(64) NOT NULL default '',
  `DEFAULT_CHARACTER_SET_NAME` varchar(64) NOT NULL default '',
  `DEFAULT_COLLATION_NAME` varchar(64) NOT NULL default '',
  `SQL_PATH` varchar(512) default NULL
) TYPE=MEMORY ;

-- 
-- Dumping data for table `SCHEMATA`
-- 

INSERT INTO `SCHEMATA` VALUES (NULL, 'information_schema', 'utf8', 'utf8_general_ci', NULL);
INSERT INTO `SCHEMATA` VALUES (NULL, 'ruskidom3', 'utf8', 'utf8_general_ci', NULL);

-- --------------------------------------------------------

-- 
-- Table structure for table `SCHEMA_PRIVILEGES`
-- 

CREATE TEMPORARY TABLE `SCHEMA_PRIVILEGES` (
  `GRANTEE` varchar(81) NOT NULL default '',
  `TABLE_CATALOG` varchar(512) default NULL,
  `TABLE_SCHEMA` varchar(64) NOT NULL default '',
  `PRIVILEGE_TYPE` varchar(64) NOT NULL default '',
  `IS_GRANTABLE` varchar(3) NOT NULL default ''
) TYPE=MEMORY ;

-- 
-- Dumping data for table `SCHEMA_PRIVILEGES`
-- 

INSERT INTO `SCHEMA_PRIVILEGES` VALUES ('''ruskidom3''@''%''', NULL, 'ruskidom3', 'SELECT', 'NO');
INSERT INTO `SCHEMA_PRIVILEGES` VALUES ('''ruskidom3''@''%''', NULL, 'ruskidom3', 'INSERT', 'NO');
INSERT INTO `SCHEMA_PRIVILEGES` VALUES ('''ruskidom3''@''%''', NULL, 'ruskidom3', 'UPDATE', 'NO');
INSERT INTO `SCHEMA_PRIVILEGES` VALUES ('''ruskidom3''@''%''', NULL, 'ruskidom3', 'DELETE', 'NO');
INSERT INTO `SCHEMA_PRIVILEGES` VALUES ('''ruskidom3''@''%''', NULL, 'ruskidom3', 'CREATE', 'NO');
INSERT INTO `SCHEMA_PRIVILEGES` VALUES ('''ruskidom3''@''%''', NULL, 'ruskidom3', 'DROP', 'NO');
INSERT INTO `SCHEMA_PRIVILEGES` VALUES ('''ruskidom3''@''%''', NULL, 'ruskidom3', 'INDEX', 'NO');
INSERT INTO `SCHEMA_PRIVILEGES` VALUES ('''ruskidom3''@''%''', NULL, 'ruskidom3', 'ALTER', 'NO');
INSERT INTO `SCHEMA_PRIVILEGES` VALUES ('''ruskidom3''@''%''', NULL, 'ruskidom3', 'CREATE TEMPORARY TABLES', 'NO');
INSERT INTO `SCHEMA_PRIVILEGES` VALUES ('''ruskidom3''@''%''', NULL, 'ruskidom3', 'LOCK TABLES', 'NO');
INSERT INTO `SCHEMA_PRIVILEGES` VALUES ('''ruskidom3''@''%''', NULL, 'ruskidom3', 'EXECUTE', 'NO');
INSERT INTO `SCHEMA_PRIVILEGES` VALUES ('''ruskidom3''@''%''', NULL, 'ruskidom3', 'CREATE VIEW', 'NO');
INSERT INTO `SCHEMA_PRIVILEGES` VALUES ('''ruskidom3''@''%''', NULL, 'ruskidom3', 'SHOW VIEW', 'NO');
INSERT INTO `SCHEMA_PRIVILEGES` VALUES ('''ruskidom3''@''%''', NULL, 'ruskidom3', 'CREATE ROUTINE', 'NO');
INSERT INTO `SCHEMA_PRIVILEGES` VALUES ('''ruskidom3''@''%''', NULL, 'ruskidom3', 'ALTER ROUTINE', 'NO');

-- --------------------------------------------------------

-- 
-- Table structure for table `STATISTICS`
-- 

CREATE TEMPORARY TABLE `STATISTICS` (
  `TABLE_CATALOG` varchar(512) default NULL,
  `TABLE_SCHEMA` varchar(64) NOT NULL default '',
  `TABLE_NAME` varchar(64) NOT NULL default '',
  `NON_UNIQUE` bigint(1) NOT NULL default '0',
  `INDEX_SCHEMA` varchar(64) NOT NULL default '',
  `INDEX_NAME` varchar(64) NOT NULL default '',
  `SEQ_IN_INDEX` bigint(2) NOT NULL default '0',
  `COLUMN_NAME` varchar(64) NOT NULL default '',
  `COLLATION` varchar(1) default NULL,
  `CARDINALITY` bigint(21) default NULL,
  `SUB_PART` bigint(3) default NULL,
  `PACKED` varchar(10) default NULL,
  `NULLABLE` varchar(3) NOT NULL default '',
  `INDEX_TYPE` varchar(16) NOT NULL default '',
  `COMMENT` varchar(16) default NULL
) TYPE=MEMORY ;

-- 
-- Dumping data for table `STATISTICS`
-- 

INSERT INTO `STATISTICS` VALUES (NULL, 'ruskidom3', 'address_book', 0, 'ruskidom3', 'address_id', 1, 'address_id', 'A', 16, NULL, NULL, '', 'BTREE', '');
INSERT INTO `STATISTICS` VALUES (NULL, 'ruskidom3', 'admin_control', 0, 'ruskidom3', 'admin_id', 1, 'admin_id', 'A', 1, NULL, NULL, '', 'BTREE', '');
INSERT INTO `STATISTICS` VALUES (NULL, 'ruskidom3', 'admin_message', 0, 'ruskidom3', 'message_id', 1, 'message_id', 'A', 2530, NULL, NULL, '', 'BTREE', '');
INSERT INTO `STATISTICS` VALUES (NULL, 'ruskidom3', 'admin_reply', 0, 'ruskidom3', 'message_id', 1, 'message_id', 'A', 1, NULL, NULL, '', 'BTREE', '');
INSERT INTO `STATISTICS` VALUES (NULL, 'ruskidom3', 'admin_users', 0, 'ruskidom3', 'admin_id', 1, 'admin_id', 'A', 2, NULL, NULL, '', 'BTREE', '');
INSERT INTO `STATISTICS` VALUES (NULL, 'ruskidom3', 'auth', 0, 'ruskidom3', 'PRIMARY', 1, 'id', 'A', 13638, NULL, NULL, '', 'BTREE', '');
INSERT INTO `STATISTICS` VALUES (NULL, 'ruskidom3', 'auth', 0, 'ruskidom3', 'id', 1, 'id', 'A', 13638, NULL, NULL, '', 'BTREE', '');
INSERT INTO `STATISTICS` VALUES (NULL, 'ruskidom3', 'auth', 1, 'ruskidom3', 'id_2', 1, 'id', 'A', NULL, NULL, NULL, '', 'BTREE', '');
INSERT INTO `STATISTICS` VALUES (NULL, 'ruskidom3', 'band_review', 0, 'ruskidom3', 'test_id', 1, 'test_id', 'A', 0, NULL, NULL, '', 'BTREE', '');
INSERT INTO `STATISTICS` VALUES (NULL, 'ruskidom3', 'banned_ip', 0, 'ruskidom3', 'PRIMARY', 1, 'id', 'A', 0, NULL, NULL, '', 'BTREE', '');
INSERT INTO `STATISTICS` VALUES (NULL, 'ruskidom3', 'blog_comments', 0, 'ruskidom3', 'PRIMARY', 1, 'id', 'A', 5, NULL, NULL, '', 'BTREE', '');
INSERT INTO `STATISTICS` VALUES (NULL, 'ruskidom3', 'blog_moderators', 0, 'ruskidom3', 'PRIMARY', 1, 'id', 'A', 1, NULL, NULL, '', 'BTREE', '');
INSERT INTO `STATISTICS` VALUES (NULL, 'ruskidom3', 'blog_mood', 0, 'ruskidom3', 'PRIMARY', 1, 'id', 'A', 1, NULL, NULL, '', 'BTREE', '');
INSERT INTO `STATISTICS` VALUES (NULL, 'ruskidom3', 'blog_preffered', 0, 'ruskidom3', 'PRIMARY', 1, 'id', 'A', 0, NULL, NULL, '', 'BTREE', '');
INSERT INTO `STATISTICS` VALUES (NULL, 'ruskidom3', 'blog_subscriptions', 0, 'ruskidom3', 'PRIMARY', 1, 'id', 'A', 41, NULL, NULL, '', 'BTREE', '');
INSERT INTO `STATISTICS` VALUES (NULL, 'ruskidom3', 'blogs', 0, 'ruskidom3', 'PRIMARY', 1, 'id', 'A', 27, NULL, NULL, '', 'BTREE', '');
INSERT INTO `STATISTICS` VALUES (NULL, 'ruskidom3', 'board_main', 0, 'ruskidom3', 'board_id', 1, 'message_id', 'A', 0, NULL, NULL, '', 'BTREE', '');
INSERT INTO `STATISTICS` VALUES (NULL, 'ruskidom3', 'board_reply', 0, 'ruskidom3', 'board_sub_id1', 1, 'board_sub_id1', 'A', 1, NULL, NULL, '', 'BTREE', '');
INSERT INTO `STATISTICS` VALUES (NULL, 'ruskidom3', 'board_sub', 0, 'ruskidom3', 'board_sub_id', 1, 'board_sub_id', 'A', 1, NULL, NULL, '', 'BTREE', '');
INSERT INTO `STATISTICS` VALUES (NULL, 'ruskidom3', 'bookmarks', 0, 'ruskidom3', 'book_id', 1, 'book_id', 'A', 84, NULL, NULL, '', 'BTREE', '');
INSERT INTO `STATISTICS` VALUES (NULL, 'ruskidom3', 'bulletin_message', 0, 'ruskidom3', 'PRIMARY', 1, 'id', 'A', 0, NULL, NULL, '', 'BTREE', '');
INSERT INTO `STATISTICS` VALUES (NULL, 'ruskidom3', 'cities', 0, 'ruskidom3', 'city_id', 1, 'city_id', 'A', 2, NULL, NULL, '', 'BTREE', '');
INSERT INTO `STATISTICS` VALUES (NULL, 'ruskidom3', 'classified_cat', 0, 'ruskidom3', 'PRIMARY', 1, 'id', 'A', 7, NULL, NULL, '', 'BTREE', '');
INSERT INTO `STATISTICS` VALUES (NULL, 'ruskidom3', 'classified_listing', 0, 'ruskidom3', 'PRIMARY', 1, 'id', 'A', 2, NULL, NULL, '', 'BTREE', '');
INSERT INTO `STATISTICS` VALUES (NULL, 'ruskidom3', 'classified_sub_cat', 0, 'ruskidom3', 'PRIMARY', 1, 'id', 'A', 1, NULL, NULL, '', 'BTREE', '');
INSERT INTO `STATISTICS` VALUES (NULL, 'ruskidom3', 'colleges', 0, 'ruskidom3', 'college_id', 1, 'college_id', 'A', 2, NULL, NULL, '', 'BTREE', '');
INSERT INTO `STATISTICS` VALUES (NULL, 'ruskidom3', 'events', 0, 'ruskidom3', 'PRIMARY', 1, 'id', 'A', 4, NULL, NULL, '', 'BTREE', '');
INSERT INTO `STATISTICS` VALUES (NULL, 'ruskidom3', 'events_cat', 0, 'ruskidom3', 'PRIMARY', 1, 'id', 'A', 5, NULL, NULL, '', 'BTREE', '');
INSERT INTO `STATISTICS` VALUES (NULL, 'ruskidom3', 'events_comments', 0, 'ruskidom3', 'PRIMARY', 1, 'id', 'A', 5, NULL, NULL, '', 'BTREE', '');
INSERT INTO `STATISTICS` VALUES (NULL, 'ruskidom3', 'events_rsvp', 0, 'ruskidom3', 'PRIMARY', 1, 'id', 'A', 6, NULL, NULL, '', 'BTREE', '');
INSERT INTO `STATISTICS` VALUES (NULL, 'ruskidom3', 'forum_main_cat', 0, 'ruskidom3', 'PRIMARY', 1, 'id', 'A', 14, NULL, NULL, '', 'BTREE', '');
INSERT INTO `STATISTICS` VALUES (NULL, 'ruskidom3', 'forum_posts', 0, 'ruskidom3', 'PRIMARY', 1, 'id', 'A', 19, NULL, NULL, '', 'BTREE', '');
INSERT INTO `STATISTICS` VALUES (NULL, 'ruskidom3', 'forum_sub_cat', 0, 'ruskidom3', 'PRIMARY', 1, 'id', 'A', 23, NULL, NULL, '', 'BTREE', '');
INSERT INTO `STATISTICS` VALUES (NULL, 'ruskidom3', 'forum_topics', 0, 'ruskidom3', 'PRIMARY', 1, 'id', 'A', 18, NULL, NULL, '', 'BTREE', '');
INSERT INTO `STATISTICS` VALUES (NULL, 'ruskidom3', 'g_bookmarks', 0, 'ruskidom3', 'book_id', 1, 'book_id', 'A', 1, NULL, NULL, '', 'BTREE', '');
INSERT INTO `STATISTICS` VALUES (NULL, 'ruskidom3', 'g_journal', 0, 'ruskidom3', 'journal_id', 1, 'journal_id', 'A', 0, NULL, NULL, '', 'BTREE', '');
INSERT INTO `STATISTICS` VALUES (NULL, 'ruskidom3', 'g_messages', 0, 'ruskidom3', 'mess_id', 1, 'mess_id', 'A', 1, NULL, NULL, '', 'BTREE', '');
INSERT INTO `STATISTICS` VALUES (NULL, 'ruskidom3', 'g_testimonials', 0, 'ruskidom3', 'test_id', 1, 'test_id', 'A', 0, NULL, NULL, '', 'BTREE', '');
INSERT INTO `STATISTICS` VALUES (NULL, 'ruskidom3', 'group_bulletin', 0, 'ruskidom3', 'PRIMARY', 1, 'id', 'A', 7, NULL, NULL, '', 'BTREE', '');
INSERT INTO `STATISTICS` VALUES (NULL, 'ruskidom3', 'group_bulletin_reply', 0, 'ruskidom3', 'PRIMARY', 1, 'id', 'A', 0, NULL, NULL, '', 'BTREE', '');
INSERT INTO `STATISTICS` VALUES (NULL, 'ruskidom3', 'group_cat', 0, 'ruskidom3', 'PRIMARY', 1, 'id', 'A', 5, NULL, NULL, '', 'BTREE', '');
INSERT INTO `STATISTICS` VALUES (NULL, 'ruskidom3', 'group_friends', 0, 'ruskidom3', 'id', 1, 'id', 'A', 3, NULL, NULL, '', 'BTREE', '');
INSERT INTO `STATISTICS` VALUES (NULL, 'ruskidom3', 'group_invites', 0, 'ruskidom3', 'invite_id', 1, 'invite_id', 'A', 0, NULL, NULL, '', 'BTREE', '');
INSERT INTO `STATISTICS` VALUES (NULL, 'ruskidom3', 'group_photos', 0, 'ruskidom3', 'photo_id', 1, 'photo_id', 'A', 23, NULL, NULL, '', 'BTREE', '');
INSERT INTO `STATISTICS` VALUES (NULL, 'ruskidom3', 'group_topic_reply', 0, 'ruskidom3', 'PRIMARY', 1, 'id', 'A', 22, NULL, NULL, '', 'BTREE', '');
INSERT INTO `STATISTICS` VALUES (NULL, 'ruskidom3', 'group_topics', 0, 'ruskidom3', 'PRIMARY', 1, 'id', 'A', 14, NULL, NULL, '', 'BTREE', '');
INSERT INTO `STATISTICS` VALUES (NULL, 'ruskidom3', 'groups', 0, 'ruskidom3', 'PRIMARY', 1, 'id', 'A', 22, NULL, NULL, '', 'BTREE', '');
INSERT INTO `STATISTICS` VALUES (NULL, 'ruskidom3', 'groups_creator', 0, 'ruskidom3', 'group_id', 1, 'group_id', 'A', 0, NULL, NULL, '', 'BTREE', '');
INSERT INTO `STATISTICS` VALUES (NULL, 'ruskidom3', 'hotornot_rating', 0, 'ruskidom3', 'PRIMARY', 1, 'id', 'A', 738, NULL, NULL, '', 'BTREE', '');
INSERT INTO `STATISTICS` VALUES (NULL, 'ruskidom3', 'invitations', 0, 'ruskidom3', 'PRIMARY', 1, 'id', 'A', 5351, NULL, NULL, '', 'BTREE', '');
INSERT INTO `STATISTICS` VALUES (NULL, 'ruskidom3', 'invitations', 0, 'ruskidom3', 'id', 1, 'id', 'A', 5351, NULL, NULL, '', 'BTREE', '');
INSERT INTO `STATISTICS` VALUES (NULL, 'ruskidom3', 'invitations', 1, 'ruskidom3', 'id_2', 1, 'id', 'A', NULL, NULL, NULL, '', 'BTREE', '');
INSERT INTO `STATISTICS` VALUES (NULL, 'ruskidom3', 'invite_temp_emails', 0, 'ruskidom3', 'invite_id', 1, 'invite_id', 'A', 337, NULL, NULL, '', 'BTREE', '');
INSERT INTO `STATISTICS` VALUES (NULL, 'ruskidom3', 'invite_temp_group_emails', 0, 'ruskidom3', 'invite_id', 1, 'invite_id', 'A', 4, NULL, NULL, '', 'BTREE', '');
INSERT INTO `STATISTICS` VALUES (NULL, 'ruskidom3', 'invites', 0, 'ruskidom3', 'invite_id', 1, 'invite_id', 'A', 1887, NULL, NULL, '', 'BTREE', '');
INSERT INTO `STATISTICS` VALUES (NULL, 'ruskidom3', 'journal', 0, 'ruskidom3', 'journal_id', 1, 'journal_id', 'A', 219, NULL, NULL, '', 'BTREE', '');
INSERT INTO `STATISTICS` VALUES (NULL, 'ruskidom3', 'journal_comment', 0, 'ruskidom3', 'comment_id', 1, 'comment_id', 'A', 7, NULL, NULL, '', 'BTREE', '');
INSERT INTO `STATISTICS` VALUES (NULL, 'ruskidom3', 'login_page', 0, 'ruskidom3', 'login_id', 1, 'login_id', 'A', 1, NULL, NULL, '', 'BTREE', '');
INSERT INTO `STATISTICS` VALUES (NULL, 'ruskidom3', 'main_page', 0, 'ruskidom3', 'main_id', 1, 'main_id', 'A', 1, NULL, NULL, '', 'BTREE', '');
INSERT INTO `STATISTICS` VALUES (NULL, 'ruskidom3', 'member_friends', 0, 'ruskidom3', 'id', 1, 'id', 'A', 536, NULL, NULL, '', 'BTREE', '');
INSERT INTO `STATISTICS` VALUES (NULL, 'ruskidom3', 'member_networking', 0, 'ruskidom3', 'PRIMARY', 1, 'id', 'A', 2, NULL, NULL, '', 'BTREE', '');
INSERT INTO `STATISTICS` VALUES (NULL, 'ruskidom3', 'members', 0, 'ruskidom3', 'member_id', 1, 'member_id', 'A', 1273, NULL, NULL, '', 'BTREE', '');
INSERT INTO `STATISTICS` VALUES (NULL, 'ruskidom3', 'messages', 0, 'ruskidom3', 'mess_id', 1, 'mess_id', 'A', 3944, NULL, NULL, '', 'BTREE', '');
INSERT INTO `STATISTICS` VALUES (NULL, 'ruskidom3', 'messages_sent', 0, 'ruskidom3', 'mess_id', 1, 'mess_id', 'A', 42, NULL, NULL, '', 'BTREE', '');
INSERT INTO `STATISTICS` VALUES (NULL, 'ruskidom3', 'misc', 0, 'ruskidom3', 'PRIMARY', 1, 'id', 'A', 1, NULL, NULL, '', 'BTREE', '');
INSERT INTO `STATISTICS` VALUES (NULL, 'ruskidom3', 'moderators_classified', 0, 'ruskidom3', 'PRIMARY', 1, 'id', 'A', 1, NULL, NULL, '', 'BTREE', '');
INSERT INTO `STATISTICS` VALUES (NULL, 'ruskidom3', 'moderators_events', 0, 'ruskidom3', 'PRIMARY', 1, 'id', 'A', 1, NULL, NULL, '', 'BTREE', '');
INSERT INTO `STATISTICS` VALUES (NULL, 'ruskidom3', 'moderators_groups', 0, 'ruskidom3', 'PRIMARY', 1, 'id', 'A', 1, NULL, NULL, '', 'BTREE', '');
INSERT INTO `STATISTICS` VALUES (NULL, 'ruskidom3', 'moderators_music', 0, 'ruskidom3', 'PRIMARY', 1, 'id', 'A', 1, NULL, NULL, '', 'BTREE', '');
INSERT INTO `STATISTICS` VALUES (NULL, 'ruskidom3', 'moderators_pics', 0, 'ruskidom3', 'PRIMARY', 1, 'id', 'A', 1, NULL, NULL, '', 'BTREE', '');
INSERT INTO `STATISTICS` VALUES (NULL, 'ruskidom3', 'most_popular', 0, 'ruskidom3', 'PRIMARY', 1, 'id', 'A', 596, NULL, NULL, '', 'BTREE', '');
INSERT INTO `STATISTICS` VALUES (NULL, 'ruskidom3', 'music_genre', 0, 'ruskidom3', 'PRIMARY', 1, 'id', 'A', 17, NULL, NULL, '', 'BTREE', '');
INSERT INTO `STATISTICS` VALUES (NULL, 'ruskidom3', 'music_member_profile', 0, 'ruskidom3', 'PRIMARY', 1, 'id', 'A', 27, NULL, NULL, '', 'BTREE', '');
INSERT INTO `STATISTICS` VALUES (NULL, 'ruskidom3', 'music_members', 0, 'ruskidom3', 'PRIMARY', 1, 'id', 'A', 0, NULL, NULL, '', 'BTREE', '');
INSERT INTO `STATISTICS` VALUES (NULL, 'ruskidom3', 'music_profile', 0, 'ruskidom3', 'PRIMARY', 1, 'id', 'A', 41, NULL, NULL, '', 'BTREE', '');
INSERT INTO `STATISTICS` VALUES (NULL, 'ruskidom3', 'music_shows', 0, 'ruskidom3', 'PRIMARY', 1, 'id', 'A', 0, NULL, NULL, '', 'BTREE', '');
INSERT INTO `STATISTICS` VALUES (NULL, 'ruskidom3', 'music_songs', 0, 'ruskidom3', 'PRIMARY', 1, 'id', 'A', 408, NULL, NULL, '', 'BTREE', '');
INSERT INTO `STATISTICS` VALUES (NULL, 'ruskidom3', 'news', 0, 'ruskidom3', 'PRIMARY', 1, 'id', 'A', 1, NULL, NULL, '', 'BTREE', '');
INSERT INTO `STATISTICS` VALUES (NULL, 'ruskidom3', 'online_now', 0, 'ruskidom3', 'PRIMARY', 1, 'id', 'A', 1, NULL, NULL, '', 'BTREE', '');
INSERT INTO `STATISTICS` VALUES (NULL, 'ruskidom3', 'packages', 0, 'ruskidom3', 'PRIMARY', 1, 'id', 'A', 1, NULL, NULL, '', 'BTREE', '');
INSERT INTO `STATISTICS` VALUES (NULL, 'ruskidom3', 'pages', 0, 'ruskidom3', 'page_id', 1, 'page_id', 'A', 1, NULL, NULL, '', 'BTREE', '');
INSERT INTO `STATISTICS` VALUES (NULL, 'ruskidom3', 'photo_rating', 0, 'ruskidom3', 'PRIMARY', 1, 'id', 'A', 705, NULL, NULL, '', 'BTREE', '');
INSERT INTO `STATISTICS` VALUES (NULL, 'ruskidom3', 'photos', 0, 'ruskidom3', 'photo_id', 1, 'photo_id', 'A', 1829, NULL, NULL, '', 'BTREE', '');
INSERT INTO `STATISTICS` VALUES (NULL, 'ruskidom3', 'polls', 0, 'ruskidom3', 'PRIMARY', 1, 'idpolls', 'A', 16, NULL, NULL, '', 'BTREE', '');
INSERT INTO `STATISTICS` VALUES (NULL, 'ruskidom3', 'polls', 1, 'ruskidom3', 'polls_owner', 1, 'owner_id', 'A', NULL, NULL, NULL, 'YES', 'BTREE', '');
INSERT INTO `STATISTICS` VALUES (NULL, 'ruskidom3', 'polls', 1, 'ruskidom3', 'polls_FKIndex1', 1, 'polls_categories_idpolls_categories', 'A', NULL, NULL, NULL, 'YES', 'BTREE', '');
INSERT INTO `STATISTICS` VALUES (NULL, 'ruskidom3', 'polls_answers', 0, 'ruskidom3', 'PRIMARY', 1, 'idpolls_answers', 'A', 92, NULL, NULL, '', 'BTREE', '');
INSERT INTO `STATISTICS` VALUES (NULL, 'ruskidom3', 'polls_answers', 1, 'ruskidom3', 'polls_idpolls', 1, 'polls_idpolls', 'A', NULL, NULL, NULL, '', 'BTREE', '');
INSERT INTO `STATISTICS` VALUES (NULL, 'ruskidom3', 'polls_answers', 1, 'ruskidom3', 'polls_idpolls', 2, 'poll_answ_votes', 'A', NULL, NULL, NULL, '', 'BTREE', '');
INSERT INTO `STATISTICS` VALUES (NULL, 'ruskidom3', 'polls_categories', 0, 'ruskidom3', 'PRIMARY', 1, 'idpolls_categories', 'A', 0, NULL, NULL, '', 'BTREE', '');
INSERT INTO `STATISTICS` VALUES (NULL, 'ruskidom3', 'polls_categories', 1, 'ruskidom3', 'polls_categories_nm', 1, 'cat_name', 'A', NULL, NULL, NULL, 'YES', 'BTREE', '');
INSERT INTO `STATISTICS` VALUES (NULL, 'ruskidom3', 'polls_log', 0, 'ruskidom3', 'PRIMARY', 1, 'idpolls_log', 'A', 63, NULL, NULL, '', 'BTREE', '');
INSERT INTO `STATISTICS` VALUES (NULL, 'ruskidom3', 'polls_log', 1, 'ruskidom3', 'polls_voter_id', 1, 'voter_id', 'A', NULL, NULL, NULL, 'YES', 'BTREE', '');
INSERT INTO `STATISTICS` VALUES (NULL, 'ruskidom3', 'polls_log', 1, 'ruskidom3', 'polls_log_FKIndex1', 1, 'polls_idpolls', 'A', NULL, NULL, NULL, '', 'BTREE', '');
INSERT INTO `STATISTICS` VALUES (NULL, 'ruskidom3', 'polls_log', 1, 'ruskidom3', 'polls_log_FKIndex2', 1, 'polls_answers_idpolls_answers', 'A', NULL, NULL, NULL, '', 'BTREE', '');
INSERT INTO `STATISTICS` VALUES (NULL, 'ruskidom3', 'privacy', 0, 'ruskidom3', 'privacy_id', 1, 'privacy_id', 'A', 1, NULL, NULL, '', 'BTREE', '');
INSERT INTO `STATISTICS` VALUES (NULL, 'ruskidom3', 'profile_back', 0, 'ruskidom3', 'PRIMARY', 1, 'id', 'A', 281, NULL, NULL, '', 'BTREE', '');
INSERT INTO `STATISTICS` VALUES (NULL, 'ruskidom3', 'profile_company', 0, 'ruskidom3', 'PRIMARY', 1, 'id', 'A', 29, NULL, NULL, '', 'BTREE', '');
INSERT INTO `STATISTICS` VALUES (NULL, 'ruskidom3', 'profile_flag', 0, 'ruskidom3', 'flag_id', 1, 'flag_id', 'A', 22, NULL, NULL, '', 'BTREE', '');
INSERT INTO `STATISTICS` VALUES (NULL, 'ruskidom3', 'profile_interests', 0, 'ruskidom3', 'PRIMARY', 1, 'id', 'A', 395, NULL, NULL, '', 'BTREE', '');
INSERT INTO `STATISTICS` VALUES (NULL, 'ruskidom3', 'profile_school', 0, 'ruskidom3', 'PRIMARY', 1, 'id', 'A', 145, NULL, NULL, '', 'BTREE', '');
INSERT INTO `STATISTICS` VALUES (NULL, 'ruskidom3', 'profile_spam', 0, 'ruskidom3', 'PRIMARY', 1, 'id', 'A', 2, NULL, NULL, '', 'BTREE', '');
INSERT INTO `STATISTICS` VALUES (NULL, 'ruskidom3', 'profile_views', 1, 'ruskidom3', 'date', 1, 'date', 'A', NULL, NULL, NULL, 'YES', 'BTREE', '');
INSERT INTO `STATISTICS` VALUES (NULL, 'ruskidom3', 'school_name', 0, 'ruskidom3', 'school_id', 1, 'school_id', 'A', 0, NULL, NULL, '', 'BTREE', '');
INSERT INTO `STATISTICS` VALUES (NULL, 'ruskidom3', 'schools', 0, 'ruskidom3', 'school_id', 1, 'school_id', 'A', 6, NULL, NULL, '', 'BTREE', '');
INSERT INTO `STATISTICS` VALUES (NULL, 'ruskidom3', 'shown_images', 0, 'ruskidom3', 'PRIMARY', 1, 'id', 'A', 1085, NULL, NULL, '', 'BTREE', '');
INSERT INTO `STATISTICS` VALUES (NULL, 'ruskidom3', 'song_critisize', 0, 'ruskidom3', 'PRIMARY', 1, 'id', 'A', 0, NULL, NULL, '', 'BTREE', '');
INSERT INTO `STATISTICS` VALUES (NULL, 'ruskidom3', 'song_rating', 0, 'ruskidom3', 'PRIMARY', 1, 'id', 'A', 0, NULL, NULL, '', 'BTREE', '');
INSERT INTO `STATISTICS` VALUES (NULL, 'ruskidom3', 'states', 0, 'ruskidom3', 'state_id', 1, 'state_id', 'A', 46, NULL, NULL, '', 'BTREE', '');
INSERT INTO `STATISTICS` VALUES (NULL, 'ruskidom3', 'states_1', 0, 'ruskidom3', 'state_id', 1, 'state_id', 'A', 51, NULL, NULL, '', 'BTREE', '');
INSERT INTO `STATISTICS` VALUES (NULL, 'ruskidom3', 'terms', 0, 'ruskidom3', 'term_id', 1, 'term_id', 'A', 1, NULL, NULL, '', 'BTREE', '');
INSERT INTO `STATISTICS` VALUES (NULL, 'ruskidom3', 'testimonials', 0, 'ruskidom3', 'test_id', 1, 'test_id', 'A', 1181, NULL, NULL, '', 'BTREE', '');
INSERT INTO `STATISTICS` VALUES (NULL, 'ruskidom3', 'top_8_friends', 0, 'ruskidom3', 'PRIMARY', 1, 'id', 'A', 4, NULL, NULL, '', 'BTREE', '');
INSERT INTO `STATISTICS` VALUES (NULL, 'ruskidom3', 'video_albums', 0, 'ruskidom3', 'PRIMARY', 1, 'id', 'A', 3, NULL, NULL, '', 'BTREE', '');
INSERT INTO `STATISTICS` VALUES (NULL, 'ruskidom3', 'video_category', 0, 'ruskidom3', 'PRIMARY', 1, 'id', 'A', 25, NULL, NULL, '', 'BTREE', '');
INSERT INTO `STATISTICS` VALUES (NULL, 'ruskidom3', 'video_comments', 0, 'ruskidom3', 'PRIMARY', 1, 'id', 'A', 0, NULL, NULL, '', 'BTREE', '');
INSERT INTO `STATISTICS` VALUES (NULL, 'ruskidom3', 'video_favorite', 0, 'ruskidom3', 'PRIMARY', 1, 'id', 'A', 0, NULL, NULL, '', 'BTREE', '');
INSERT INTO `STATISTICS` VALUES (NULL, 'ruskidom3', 'video_members', 0, 'ruskidom3', 'PRIMARY', 1, 'id', 'A', 1, NULL, NULL, '', 'BTREE', '');
INSERT INTO `STATISTICS` VALUES (NULL, 'ruskidom3', 'video_playlist', 0, 'ruskidom3', 'PRIMARY', 1, 'id', 'A', 0, NULL, NULL, '', 'BTREE', '');

-- --------------------------------------------------------

-- 
-- Table structure for table `TABLES`
-- 

CREATE TEMPORARY TABLE `TABLES` (
  `TABLE_CATALOG` varchar(512) default NULL,
  `TABLE_SCHEMA` varchar(64) NOT NULL default '',
  `TABLE_NAME` varchar(64) NOT NULL default '',
  `TABLE_TYPE` varchar(64) NOT NULL default '',
  `ENGINE` varchar(64) default NULL,
  `VERSION` bigint(21) default NULL,
  `ROW_FORMAT` varchar(10) default NULL,
  `TABLE_ROWS` bigint(21) default NULL,
  `AVG_ROW_LENGTH` bigint(21) default NULL,
  `DATA_LENGTH` bigint(21) default NULL,
  `MAX_DATA_LENGTH` bigint(21) default NULL,
  `INDEX_LENGTH` bigint(21) default NULL,
  `DATA_FREE` bigint(21) default NULL,
  `AUTO_INCREMENT` bigint(21) default NULL,
  `CREATE_TIME` datetime default NULL,
  `UPDATE_TIME` datetime default NULL,
  `CHECK_TIME` datetime default NULL,
  `TABLE_COLLATION` varchar(64) default NULL,
  `CHECKSUM` bigint(21) default NULL,
  `CREATE_OPTIONS` varchar(255) default NULL,
  `TABLE_COMMENT` varchar(80) NOT NULL default ''
) TYPE=MEMORY ;

-- 
-- Dumping data for table `TABLES`
-- 

INSERT INTO `TABLES` VALUES (NULL, 'information_schema', 'CHARACTER_SETS', 'SYSTEM VIEW', 'MEMORY', 0, 'Fixed', NULL, 576, 0, 1048320, 0, 0, NULL, NULL, NULL, NULL, 'utf8_general_ci', NULL, 'max_rows=1820', '');
INSERT INTO `TABLES` VALUES (NULL, 'information_schema', 'COLLATIONS', 'SYSTEM VIEW', 'MEMORY', 0, 'Fixed', NULL, 423, 0, 1048194, 0, 0, NULL, NULL, NULL, NULL, 'utf8_general_ci', NULL, 'max_rows=2478', '');
INSERT INTO `TABLES` VALUES (NULL, 'information_schema', 'COLLATION_CHARACTER_SET_APPLICABILITY', 'SYSTEM VIEW', 'MEMORY', 0, 'Fixed', NULL, 387, 0, 1048383, 0, 0, NULL, NULL, NULL, NULL, 'utf8_general_ci', NULL, 'max_rows=2709', '');
INSERT INTO `TABLES` VALUES (NULL, 'information_schema', 'COLUMNS', 'SYSTEM VIEW', 'MyISAM', 0, 'Dynamic', NULL, 0, 0, 281474976710655, 1024, 0, NULL, '2007-09-08 18:06:49', '2007-09-08 18:06:49', NULL, 'utf8_general_ci', NULL, 'max_rows=272', '');
INSERT INTO `TABLES` VALUES (NULL, 'information_schema', 'COLUMN_PRIVILEGES', 'SYSTEM VIEW', 'MEMORY', 0, 'Fixed', NULL, 2565, 0, 1046520, 0, 0, NULL, NULL, NULL, NULL, 'utf8_general_ci', NULL, 'max_rows=408', '');
INSERT INTO `TABLES` VALUES (NULL, 'information_schema', 'KEY_COLUMN_USAGE', 'SYSTEM VIEW', 'MEMORY', 0, 'Fixed', NULL, 4637, 0, 1047962, 0, 0, NULL, NULL, NULL, NULL, 'utf8_general_ci', NULL, 'max_rows=226', '');
INSERT INTO `TABLES` VALUES (NULL, 'information_schema', 'PROFILING', 'SYSTEM VIEW', 'MEMORY', 0, 'Fixed', NULL, 425, 0, 1048475, 0, 0, NULL, NULL, NULL, NULL, 'utf8_general_ci', NULL, 'max_rows=2467', '');
INSERT INTO `TABLES` VALUES (NULL, 'information_schema', 'ROUTINES', 'SYSTEM VIEW', 'MyISAM', 0, 'Dynamic', NULL, 0, 0, 281474976710655, 1024, 0, NULL, '2007-09-08 18:06:49', '2007-09-08 18:06:49', NULL, 'utf8_general_ci', NULL, 'max_rows=286', '');
INSERT INTO `TABLES` VALUES (NULL, 'information_schema', 'SCHEMATA', 'SYSTEM VIEW', 'MEMORY', 0, 'Fixed', NULL, 3656, 0, 1045616, 0, 0, NULL, NULL, NULL, NULL, 'utf8_general_ci', NULL, 'max_rows=286', '');
INSERT INTO `TABLES` VALUES (NULL, 'information_schema', 'SCHEMA_PRIVILEGES', 'SYSTEM VIEW', 'MEMORY', 0, 'Fixed', NULL, 2179, 0, 1048099, 0, 0, NULL, NULL, NULL, NULL, 'utf8_general_ci', NULL, 'max_rows=481', '');
INSERT INTO `TABLES` VALUES (NULL, 'information_schema', 'STATISTICS', 'SYSTEM VIEW', 'MEMORY', 0, 'Fixed', NULL, 2679, 0, 1047489, 0, 0, NULL, NULL, NULL, NULL, 'utf8_general_ci', NULL, 'max_rows=391', '');
INSERT INTO `TABLES` VALUES (NULL, 'information_schema', 'TABLES', 'SYSTEM VIEW', 'MEMORY', 0, 'Fixed', NULL, 3641, 0, 1044967, 0, 0, NULL, NULL, NULL, NULL, 'utf8_general_ci', NULL, 'max_rows=287', '');
INSERT INTO `TABLES` VALUES (NULL, 'information_schema', 'TABLE_CONSTRAINTS', 'SYSTEM VIEW', 'MEMORY', 0, 'Fixed', NULL, 2504, 0, 1046672, 0, 0, NULL, NULL, NULL, NULL, 'utf8_general_ci', NULL, 'max_rows=418', '');
INSERT INTO `TABLES` VALUES (NULL, 'information_schema', 'TABLE_PRIVILEGES', 'SYSTEM VIEW', 'MEMORY', 0, 'Fixed', NULL, 2372, 0, 1048424, 0, 0, NULL, NULL, NULL, NULL, 'utf8_general_ci', NULL, 'max_rows=442', '');
INSERT INTO `TABLES` VALUES (NULL, 'information_schema', 'TRIGGERS', 'SYSTEM VIEW', 'MyISAM', 0, 'Dynamic', NULL, 0, 0, 281474976710655, 1024, 0, NULL, '2007-09-08 18:06:49', '2007-09-08 18:06:49', NULL, 'utf8_general_ci', NULL, 'max_rows=239', '');
INSERT INTO `TABLES` VALUES (NULL, 'information_schema', 'USER_PRIVILEGES', 'SYSTEM VIEW', 'MEMORY', 0, 'Fixed', NULL, 1986, 0, 1046622, 0, 0, NULL, NULL, NULL, NULL, 'utf8_general_ci', NULL, 'max_rows=527', '');
INSERT INTO `TABLES` VALUES (NULL, 'information_schema', 'VIEWS', 'SYSTEM VIEW', 'MyISAM', 0, 'Dynamic', NULL, 0, 0, 281474976710655, 1024, 0, NULL, '2007-09-08 18:06:49', '2007-09-08 18:06:49', NULL, 'utf8_general_ci', NULL, 'max_rows=471', '');
INSERT INTO `TABLES` VALUES (NULL, 'ruskidom3', 'address_book', 'BASE TABLE', 'MyISAM', 10, 'Dynamic', 16, 40, 652, 281474976710655, 2048, 0, 113, '2007-03-21 07:06:10', '2007-03-21 07:06:10', NULL, 'utf8_general_ci', NULL, '', '');
INSERT INTO `TABLES` VALUES (NULL, 'ruskidom3', 'admin_control', 'BASE TABLE', 'MyISAM', 10, 'Dynamic', 1, 20, 20, 281474976710655, 2048, 0, 2, '2007-03-21 07:06:10', '2007-03-21 07:06:10', NULL, 'utf8_general_ci', NULL, '', '');
INSERT INTO `TABLES` VALUES (NULL, 'ruskidom3', 'admin_message', 'BASE TABLE', 'MyISAM', 10, 'Dynamic', 2530, 75, 192648, 281474976710655, 27648, 608, 2597, '2007-03-21 07:06:10', '2007-06-03 15:50:42', NULL, 'utf8_general_ci', NULL, '', '');
INSERT INTO `TABLES` VALUES (NULL, 'ruskidom3', 'admin_reply', 'BASE TABLE', 'MyISAM', 10, 'Dynamic', 1, 32, 32, 281474976710655, 2048, 0, 5, '2007-03-21 07:06:10', '2007-05-29 15:29:17', NULL, 'utf8_general_ci', NULL, '', '');
INSERT INTO `TABLES` VALUES (NULL, 'ruskidom3', 'admin_users', 'BASE TABLE', 'MyISAM', 10, 'Dynamic', 2, 28, 56, 281474976710655, 2048, 0, 5, '2007-03-21 07:06:10', '2007-05-29 19:32:37', NULL, 'utf8_general_ci', NULL, '', '');
INSERT INTO `TABLES` VALUES (NULL, 'ruskidom3', 'auth', 'BASE TABLE', 'MyISAM', 10, 'Dynamic', 13638, 32, 437224, 281474976710655, 424960, 0, 13639, '2007-03-21 07:06:10', '2007-06-06 14:45:08', NULL, 'utf8_general_ci', NULL, '', '');
INSERT INTO `TABLES` VALUES (NULL, 'ruskidom3', 'band_review', 'BASE TABLE', 'MyISAM', 10, 'Dynamic', 0, 0, 0, 281474976710655, 1024, 0, 7, '2007-03-21 07:06:17', '2007-03-21 07:06:17', NULL, 'utf8_general_ci', NULL, '', '');
INSERT INTO `TABLES` VALUES (NULL, 'ruskidom3', 'banned_ip', 'BASE TABLE', 'MyISAM', 10, 'Dynamic', 0, 0, 0, 281474976710655, 1024, 0, 1, '2007-03-21 07:06:17', '2007-03-21 07:06:17', NULL, 'utf8_general_ci', NULL, '', '');
INSERT INTO `TABLES` VALUES (NULL, 'ruskidom3', 'blog_comments', 'BASE TABLE', 'MyISAM', 10, 'Dynamic', 5, 248, 1244, 281474976710655, 2048, 0, 35, '2007-03-21 07:06:17', '2007-03-21 07:06:17', NULL, 'utf8_general_ci', NULL, '', '');
INSERT INTO `TABLES` VALUES (NULL, 'ruskidom3', 'blog_moderators', 'BASE TABLE', 'MyISAM', 10, 'Dynamic', 1, 32, 32, 281474976710655, 2048, 0, 2, '2007-03-21 07:06:17', '2007-03-21 07:06:17', NULL, 'utf8_general_ci', NULL, '', '');
INSERT INTO `TABLES` VALUES (NULL, 'ruskidom3', 'blog_mood', 'BASE TABLE', 'MyISAM', 10, 'Dynamic', 1, 40, 40, 281474976710655, 2048, 0, 3, '2007-03-21 07:06:17', '2007-03-21 07:06:17', NULL, 'utf8_general_ci', NULL, '', '');
INSERT INTO `TABLES` VALUES (NULL, 'ruskidom3', 'blog_preffered', 'BASE TABLE', 'MyISAM', 10, 'Fixed', 0, 0, 0, 3659174697238527, 1024, 0, 9, '2007-03-21 07:06:17', '2007-03-21 07:06:17', NULL, 'utf8_general_ci', NULL, '', '');
INSERT INTO `TABLES` VALUES (NULL, 'ruskidom3', 'blog_subscriptions', 'BASE TABLE', 'MyISAM', 10, 'Dynamic', 41, 32, 1312, 281474976710655, 2048, 0, 51, '2007-03-21 07:06:17', '2007-03-21 07:06:17', NULL, 'utf8_general_ci', NULL, '', '');
INSERT INTO `TABLES` VALUES (NULL, 'ruskidom3', 'blogs', 'BASE TABLE', 'MyISAM', 10, 'Dynamic', 27, 3424, 92468, 281474976710655, 2048, 0, 45, '2007-03-21 07:06:17', '2007-03-21 07:06:17', NULL, 'utf8_general_ci', NULL, '', '');
INSERT INTO `TABLES` VALUES (NULL, 'ruskidom3', 'board_main', 'BASE TABLE', 'MyISAM', 10, 'Dynamic', 0, 0, 0, 281474976710655, 1024, 0, 7, '2007-03-21 07:06:17', '2007-03-21 07:06:17', NULL, 'utf8_general_ci', NULL, '', '');
INSERT INTO `TABLES` VALUES (NULL, 'ruskidom3', 'board_reply', 'BASE TABLE', 'MyISAM', 10, 'Dynamic', 1, 40, 40, 281474976710655, 2048, 0, 29, '2007-03-21 07:06:17', '2007-03-21 07:06:17', NULL, 'utf8_general_ci', NULL, '', '');
INSERT INTO `TABLES` VALUES (NULL, 'ruskidom3', 'board_sub', 'BASE TABLE', 'MyISAM', 10, 'Dynamic', 1, 36, 36, 281474976710655, 2048, 0, 8, '2007-03-21 07:06:17', '2007-03-21 07:06:17', NULL, 'utf8_general_ci', NULL, '', '');
INSERT INTO `TABLES` VALUES (NULL, 'ruskidom3', 'bookmarks', 'BASE TABLE', 'MyISAM', 10, 'Fixed', 84, 17, 1428, 4785074604081151, 2048, 0, 106, '2007-03-21 07:06:17', '2007-03-21 07:06:17', NULL, 'utf8_general_ci', NULL, '', '');
INSERT INTO `TABLES` VALUES (NULL, 'ruskidom3', 'bulletin_message', 'BASE TABLE', 'MyISAM', 10, 'Dynamic', 0, 0, 0, 281474976710655, 1024, 0, 1, '2007-03-21 07:06:17', '2007-03-21 07:06:17', NULL, 'utf8_general_ci', NULL, '', '');
INSERT INTO `TABLES` VALUES (NULL, 'ruskidom3', 'cities', 'BASE TABLE', 'MyISAM', 10, 'Dynamic', 2, 20, 40, 281474976710655, 2048, 0, 4, '2007-03-21 07:06:17', '2007-03-21 07:06:17', NULL, 'utf8_general_ci', NULL, '', '');
INSERT INTO `TABLES` VALUES (NULL, 'ruskidom3', 'classified_cat', 'BASE TABLE', 'MyISAM', 10, 'Dynamic', 7, 35, 248, 281474976710655, 2048, 0, 12, '2007-03-21 07:06:17', '2007-05-27 17:48:33', NULL, 'utf8_general_ci', NULL, '', '');
INSERT INTO `TABLES` VALUES (NULL, 'ruskidom3', 'classified_listing', 'BASE TABLE', 'MyISAM', 10, 'Dynamic', 2, 420, 840, 281474976710655, 2048, 0, 10, '2007-03-21 07:06:17', '2007-05-18 00:23:05', NULL, 'utf8_general_ci', NULL, '', '');
INSERT INTO `TABLES` VALUES (NULL, 'ruskidom3', 'classified_sub_cat', 'BASE TABLE', 'MyISAM', 10, 'Dynamic', 1, 44, 44, 281474976710655, 2048, 0, 3, '2007-03-21 07:06:18', '2007-03-21 07:06:18', NULL, 'utf8_general_ci', NULL, '', '');
INSERT INTO `TABLES` VALUES (NULL, 'ruskidom3', 'colleges', 'BASE TABLE', 'MyISAM', 10, 'Dynamic', 2, 28, 56, 281474976710655, 2048, 0, 3, '2007-03-21 07:06:18', '2007-03-21 07:06:18', NULL, 'utf8_general_ci', NULL, '', '');
INSERT INTO `TABLES` VALUES (NULL, 'ruskidom3', 'disclaimer', 'BASE TABLE', 'MyISAM', 10, 'Dynamic', 1, 20, 20, 281474976710655, 1024, 0, NULL, '2007-03-21 07:06:18', '2007-03-21 07:06:18', NULL, 'utf8_general_ci', NULL, '', '');
INSERT INTO `TABLES` VALUES (NULL, 'ruskidom3', 'events', 'BASE TABLE', 'MyISAM', 10, 'Dynamic', 4, 532, 2128, 281474976710655, 2048, 0, 20, '2007-03-21 07:08:12', '2007-03-21 07:08:12', NULL, 'utf8_general_ci', NULL, '', '');
INSERT INTO `TABLES` VALUES (NULL, 'ruskidom3', 'events_cat', 'BASE TABLE', 'MyISAM', 10, 'Dynamic', 5, 32, 164, 281474976710655, 2048, 0, 7, '2007-03-21 07:08:12', '2007-03-21 07:08:12', NULL, 'utf8_general_ci', NULL, '', '');
INSERT INTO `TABLES` VALUES (NULL, 'ruskidom3', 'events_comments', 'BASE TABLE', 'MyISAM', 10, 'Dynamic', 5, 45, 228, 281474976710655, 2048, 0, 6, '2007-03-21 07:08:12', '2007-03-21 07:08:12', NULL, 'utf8_general_ci', NULL, '', '');
INSERT INTO `TABLES` VALUES (NULL, 'ruskidom3', 'events_rsvp', 'BASE TABLE', 'MyISAM', 10, 'Dynamic', 6, 33, 200, 281474976710655, 2048, 0, 7, '2007-03-21 07:08:12', '2007-03-21 07:08:12', NULL, 'utf8_general_ci', NULL, '', '');
INSERT INTO `TABLES` VALUES (NULL, 'ruskidom3', 'forum_main_cat', 'BASE TABLE', 'MyISAM', 10, 'Dynamic', 14, 25, 352, 281474976710655, 2048, 0, 17, '2007-03-21 07:08:12', '2007-03-21 07:08:12', NULL, 'utf8_general_ci', NULL, '', '');
INSERT INTO `TABLES` VALUES (NULL, 'ruskidom3', 'forum_posts', 'BASE TABLE', 'MyISAM', 10, 'Dynamic', 19, 282, 5364, 281474976710655, 2048, 0, 21, '2007-03-21 07:08:12', '2007-03-21 07:08:12', NULL, 'utf8_general_ci', NULL, '', '');
INSERT INTO `TABLES` VALUES (NULL, 'ruskidom3', 'forum_sub_cat', 'BASE TABLE', 'MyISAM', 10, 'Dynamic', 23, 56, 1292, 281474976710655, 2048, 0, 25, '2007-03-21 07:08:12', '2007-06-05 09:27:03', NULL, 'utf8_general_ci', NULL, '', '');
INSERT INTO `TABLES` VALUES (NULL, 'ruskidom3', 'forum_topics', 'BASE TABLE', 'MyISAM', 10, 'Dynamic', 18, 907, 16328, 281474976710655, 2048, 0, 20, '2007-03-21 07:08:12', '2007-03-21 07:08:12', NULL, 'utf8_general_ci', NULL, '', '');
INSERT INTO `TABLES` VALUES (NULL, 'ruskidom3', 'g_bookmarks', 'BASE TABLE', 'MyISAM', 10, 'Fixed', 1, 17, 17, 4785074604081151, 2048, 0, 8, '2007-03-21 07:08:12', '2007-03-21 07:08:12', NULL, 'utf8_general_ci', NULL, '', '');
INSERT INTO `TABLES` VALUES (NULL, 'ruskidom3', 'g_journal', 'BASE TABLE', 'MyISAM', 10, 'Dynamic', 0, 0, 0, 281474976710655, 1024, 0, 5, '2007-03-21 07:08:12', '2007-03-21 07:08:12', NULL, 'utf8_general_ci', NULL, '', '');
INSERT INTO `TABLES` VALUES (NULL, 'ruskidom3', 'g_messages', 'BASE TABLE', 'MyISAM', 10, 'Dynamic', 1, 36, 36, 281474976710655, 2048, 0, 40, '2007-03-21 07:08:12', '2007-03-21 07:08:12', NULL, 'utf8_general_ci', NULL, '', '');
INSERT INTO `TABLES` VALUES (NULL, 'ruskidom3', 'g_testimonials', 'BASE TABLE', 'MyISAM', 10, 'Dynamic', 0, 0, 0, 281474976710655, 1024, 0, 8, '2007-03-21 07:08:12', '2007-03-21 07:08:12', NULL, 'utf8_general_ci', NULL, '', '');
INSERT INTO `TABLES` VALUES (NULL, 'ruskidom3', 'group_bulletin', 'BASE TABLE', 'MyISAM', 10, 'Dynamic', 7, 202, 1416, 281474976710655, 2048, 0, 14, '2007-03-21 07:08:12', '2007-03-21 07:08:12', NULL, 'utf8_general_ci', NULL, '', '');
INSERT INTO `TABLES` VALUES (NULL, 'ruskidom3', 'group_bulletin_reply', 'BASE TABLE', 'MyISAM', 10, 'Dynamic', 0, 0, 0, 281474976710655, 1024, 0, 1, '2007-03-21 07:08:12', '2007-03-21 07:08:12', NULL, 'utf8_general_ci', NULL, '', '');
INSERT INTO `TABLES` VALUES (NULL, 'ruskidom3', 'group_cat', 'BASE TABLE', 'MyISAM', 10, 'Dynamic', 5, 32, 164, 281474976710655, 2048, 0, 7, '2007-03-21 07:08:12', '2007-03-21 07:08:12', NULL, 'utf8_general_ci', NULL, '', '');
INSERT INTO `TABLES` VALUES (NULL, 'ruskidom3', 'group_friends', 'BASE TABLE', 'MyISAM', 10, 'Fixed', 3, 27, 81, 7599824371187711, 2048, 0, 26, '2007-03-21 07:08:12', '2007-03-21 07:08:12', NULL, 'utf8_general_ci', NULL, '', '');
INSERT INTO `TABLES` VALUES (NULL, 'ruskidom3', 'group_invites', 'BASE TABLE', 'MyISAM', 10, 'Dynamic', 0, 0, 0, 281474976710655, 1024, 0, 17, '2007-03-21 07:08:12', '2007-03-21 07:08:12', NULL, 'utf8_general_ci', NULL, '', '');
INSERT INTO `TABLES` VALUES (NULL, 'ruskidom3', 'group_photos', 'BASE TABLE', 'MyISAM', 10, 'Dynamic', 23, 48, 1116, 281474976710655, 2048, 0, 30, '2007-03-21 07:08:12', '2007-03-21 07:08:12', NULL, 'utf8_general_ci', NULL, '', '');
INSERT INTO `TABLES` VALUES (NULL, 'ruskidom3', 'group_topic_reply', 'BASE TABLE', 'MyISAM', 10, 'Dynamic', 22, 236, 5196, 281474976710655, 2048, 0, 30, '2007-03-21 07:08:12', '2007-03-21 07:08:12', NULL, 'utf8_general_ci', NULL, '', '');
INSERT INTO `TABLES` VALUES (NULL, 'ruskidom3', 'group_topics', 'BASE TABLE', 'MyISAM', 10, 'Dynamic', 14, 353, 4944, 281474976710655, 2048, 0, 22, '2007-03-21 07:08:12', '2007-03-25 08:45:39', NULL, 'utf8_general_ci', NULL, '', '');
INSERT INTO `TABLES` VALUES (NULL, 'ruskidom3', 'groups', 'BASE TABLE', 'MyISAM', 10, 'Dynamic', 22, 167, 3680, 281474976710655, 2048, 0, 32, '2007-03-21 07:08:12', '2007-03-21 07:08:12', NULL, 'utf8_general_ci', NULL, '', '');
INSERT INTO `TABLES` VALUES (NULL, 'ruskidom3', 'groups_creator', 'BASE TABLE', 'MyISAM', 10, 'Dynamic', 0, 0, 0, 281474976710655, 1024, 0, 5, '2007-03-21 07:08:13', '2007-03-21 07:08:13', NULL, 'utf8_general_ci', NULL, '', '');
INSERT INTO `TABLES` VALUES (NULL, 'ruskidom3', 'groups_profile', 'BASE TABLE', 'MyISAM', 10, 'Dynamic', 1, 84, 84, 281474976710655, 1024, 0, NULL, '2007-03-21 07:08:13', '2007-03-21 07:08:13', NULL, 'utf8_general_ci', NULL, '', '');
INSERT INTO `TABLES` VALUES (NULL, 'ruskidom3', 'help', 'BASE TABLE', 'MyISAM', 10, 'Dynamic', 1, 7844, 7844, 281474976710655, 1024, 0, NULL, '2007-03-21 07:08:13', '2007-03-21 07:08:13', NULL, 'utf8_general_ci', NULL, '', '');
INSERT INTO `TABLES` VALUES (NULL, 'ruskidom3', 'hotornot_rating', 'BASE TABLE', 'MyISAM', 10, 'Dynamic', 738, 74, 54696, 281474976710655, 10240, 0, 785, '2007-03-21 07:08:13', '2007-03-21 07:08:13', NULL, 'utf8_general_ci', NULL, '', '');
INSERT INTO `TABLES` VALUES (NULL, 'ruskidom3', 'invitations', 'BASE TABLE', 'MyISAM', 10, 'Fixed', 5351, 27, 144477, 7599824371187711, 179200, 0, 5359, '2007-03-21 07:08:13', '2007-06-06 14:46:18', NULL, 'utf8_general_ci', NULL, '', '');
INSERT INTO `TABLES` VALUES (NULL, 'ruskidom3', 'invite_temp_emails', 'BASE TABLE', 'MyISAM', 10, 'Dynamic', 337, 58, 19660, 281474976710655, 6144, 0, 438, '2007-03-21 07:08:16', '2007-06-04 08:38:06', NULL, 'utf8_general_ci', NULL, '', '');
INSERT INTO `TABLES` VALUES (NULL, 'ruskidom3', 'invite_temp_group_emails', 'BASE TABLE', 'MyISAM', 10, 'Dynamic', 4, 63, 252, 281474976710655, 2048, 0, 27, '2007-03-21 07:08:16', '2007-03-21 07:08:16', NULL, 'utf8_general_ci', NULL, '', '');
INSERT INTO `TABLES` VALUES (NULL, 'ruskidom3', 'invites', 'BASE TABLE', 'MyISAM', 10, 'Dynamic', 1887, 47, 90964, 281474976710655, 25600, 392, 3766, '2007-03-21 07:08:16', '2007-06-06 14:47:37', NULL, 'utf8_general_ci', NULL, '', '');
INSERT INTO `TABLES` VALUES (NULL, 'ruskidom3', 'journal', 'BASE TABLE', 'MyISAM', 10, 'Dynamic', 219, 1116, 244500, 281474976710655, 5120, 0, 284, '2007-03-21 07:08:17', '2007-05-31 14:15:26', NULL, 'utf8_general_ci', NULL, '', '');
INSERT INTO `TABLES` VALUES (NULL, 'ruskidom3', 'journal_comment', 'BASE TABLE', 'MyISAM', 10, 'Dynamic', 7, 75, 528, 281474976710655, 2048, 0, 14, '2007-03-21 07:08:17', '2007-03-21 07:08:17', NULL, 'utf8_general_ci', NULL, '', '');
INSERT INTO `TABLES` VALUES (NULL, 'ruskidom3', 'login_page', 'BASE TABLE', 'MyISAM', 10, 'Dynamic', 1, 24, 24, 281474976710655, 2048, 0, 2, '2007-03-21 07:08:17', '2007-03-21 07:08:17', NULL, 'utf8_general_ci', NULL, '', '');
INSERT INTO `TABLES` VALUES (NULL, 'ruskidom3', 'main_page', 'BASE TABLE', 'MyISAM', 10, 'Dynamic', 1, 392, 392, 281474976710655, 2048, 0, 2, '2007-03-21 07:08:17', '2007-03-21 07:08:17', NULL, 'utf8_general_ci', NULL, '', '');
INSERT INTO `TABLES` VALUES (NULL, 'ruskidom3', 'member_friends', 'BASE TABLE', 'MyISAM', 10, 'Fixed', 536, 25, 13400, 7036874417766399, 10240, 0, 656, '2007-03-21 07:08:17', '2007-03-21 07:08:18', NULL, 'utf8_general_ci', NULL, '', '');
INSERT INTO `TABLES` VALUES (NULL, 'ruskidom3', 'member_networking', 'BASE TABLE', 'MyISAM', 10, 'Dynamic', 2, 446, 892, 281474976710655, 2048, 0, 8, '2007-03-21 07:08:18', '2007-03-21 07:08:18', NULL, 'utf8_general_ci', NULL, '', '');
INSERT INTO `TABLES` VALUES (NULL, 'ruskidom3', 'member_profile', 'BASE TABLE', 'MyISAM', 10, 'Dynamic', 89, 2127, 190020, 281474976710655, 1024, 680, NULL, '2007-03-21 07:08:18', '2007-05-08 13:30:01', NULL, 'utf8_general_ci', NULL, '', '');
INSERT INTO `TABLES` VALUES (NULL, 'ruskidom3', 'members', 'BASE TABLE', 'MyISAM', 10, 'Dynamic', 1273, 212, 270388, 281474976710655, 20480, 0, 1391, '2007-03-21 07:08:18', '2007-06-07 04:47:22', NULL, 'utf8_general_ci', NULL, '', '');
INSERT INTO `TABLES` VALUES (NULL, 'ruskidom3', 'messages', 'BASE TABLE', 'MyISAM', 10, 'Dynamic', 3944, 1032, 4073764, 281474976710655, 54272, 0, 4570, '2007-03-21 07:13:56', '2007-05-29 17:39:53', NULL, 'utf8_general_ci', NULL, '', '');
INSERT INTO `TABLES` VALUES (NULL, 'ruskidom3', 'messages_sent', 'BASE TABLE', 'MyISAM', 10, 'Dynamic', 42, 2923, 122772, 281474976710655, 2048, 0, 4571, '2007-03-21 07:13:56', '2007-05-29 17:39:53', NULL, 'utf8_general_ci', NULL, '', '');
INSERT INTO `TABLES` VALUES (NULL, 'ruskidom3', 'misc', 'BASE TABLE', 'MyISAM', 10, 'Dynamic', 1, 20, 20, 281474976710655, 2048, 0, 2, '2007-03-21 07:09:32', '2007-03-21 07:09:32', NULL, 'utf8_general_ci', NULL, '', '');
INSERT INTO `TABLES` VALUES (NULL, 'ruskidom3', 'moderators_classified', 'BASE TABLE', 'MyISAM', 10, 'Dynamic', 1, 32, 32, 281474976710655, 2048, 0, 4, '2007-03-21 07:09:32', '2007-03-21 07:09:32', NULL, 'utf8_general_ci', NULL, '', '');
INSERT INTO `TABLES` VALUES (NULL, 'ruskidom3', 'moderators_events', 'BASE TABLE', 'MyISAM', 10, 'Dynamic', 1, 32, 32, 281474976710655, 2048, 0, 5, '2007-03-21 07:09:32', '2007-03-21 07:09:32', NULL, 'utf8_general_ci', NULL, '', '');
INSERT INTO `TABLES` VALUES (NULL, 'ruskidom3', 'moderators_groups', 'BASE TABLE', 'MyISAM', 10, 'Dynamic', 1, 32, 32, 281474976710655, 2048, 0, 3, '2007-03-21 07:09:32', '2007-03-21 07:09:33', NULL, 'utf8_general_ci', NULL, '', '');
INSERT INTO `TABLES` VALUES (NULL, 'ruskidom3', 'moderators_music', 'BASE TABLE', 'MyISAM', 10, 'Dynamic', 1, 32, 32, 281474976710655, 2048, 0, 2, '2007-03-21 07:09:33', '2007-03-21 07:09:33', NULL, 'utf8_general_ci', NULL, '', '');
INSERT INTO `TABLES` VALUES (NULL, 'ruskidom3', 'moderators_pics', 'BASE TABLE', 'MyISAM', 10, 'Dynamic', 1, 32, 32, 281474976710655, 2048, 0, 3, '2007-03-21 07:09:33', '2007-03-21 07:09:33', NULL, 'utf8_general_ci', NULL, '', '');
INSERT INTO `TABLES` VALUES (NULL, 'ruskidom3', 'most_popular', 'BASE TABLE', 'MyISAM', 10, 'Fixed', 596, 17, 10132, 4785074604081151, 8192, 0, 76615, '2007-03-21 07:09:33', '2007-03-21 07:09:33', NULL, 'utf8_general_ci', NULL, '', '');
INSERT INTO `TABLES` VALUES (NULL, 'ruskidom3', 'music_genre', 'BASE TABLE', 'MyISAM', 10, 'Dynamic', 17, 20, 348, 281474976710655, 2048, 0, 20, '2007-03-21 07:09:33', '2007-03-21 07:09:33', NULL, 'utf8_general_ci', NULL, '', '');
INSERT INTO `TABLES` VALUES (NULL, 'ruskidom3', 'music_member_profile', 'BASE TABLE', 'MyISAM', 10, 'Dynamic', 27, 118, 3212, 281474976710655, 2048, 0, 41, '2007-03-21 07:09:33', '2007-05-18 00:59:26', NULL, 'utf8_general_ci', NULL, '', '');
INSERT INTO `TABLES` VALUES (NULL, 'ruskidom3', 'music_members', 'BASE TABLE', 'MyISAM', 10, 'Dynamic', 0, 0, 0, 281474976710655, 1024, 0, 3, '2007-03-21 07:09:33', '2007-03-21 07:09:33', NULL, 'utf8_general_ci', NULL, '', '');
INSERT INTO `TABLES` VALUES (NULL, 'ruskidom3', 'music_profile', 'BASE TABLE', 'MyISAM', 10, 'Dynamic', 41, 1261, 51732, 281474976710655, 2048, 0, 58, '2007-03-21 07:09:33', '2007-05-29 00:11:34', NULL, 'utf8_general_ci', NULL, '', '');
INSERT INTO `TABLES` VALUES (NULL, 'ruskidom3', 'music_shows', 'BASE TABLE', 'MyISAM', 10, 'Dynamic', 0, 0, 0, 281474976710655, 1024, 0, 7, '2007-03-21 07:09:33', '2007-03-21 07:09:33', NULL, 'utf8_general_ci', NULL, '', '');
INSERT INTO `TABLES` VALUES (NULL, 'ruskidom3', 'music_songs', 'BASE TABLE', 'MyISAM', 10, 'Dynamic', 408, 103, 42224, 281474976710655, 7168, 84, 553, '2007-03-21 07:09:33', '2007-04-02 09:56:43', NULL, 'utf8_general_ci', NULL, '', '');
INSERT INTO `TABLES` VALUES (NULL, 'ruskidom3', 'news', 'BASE TABLE', 'MyISAM', 10, 'Dynamic', 1, 76, 76, 281474976710655, 2048, 0, 2, '2007-03-21 07:09:33', '2007-03-21 07:09:33', NULL, 'utf8_general_ci', NULL, '', '');
INSERT INTO `TABLES` VALUES (NULL, 'ruskidom3', 'online_now', 'BASE TABLE', 'MyISAM', 10, 'Dynamic', 1, 44, 44, 281474976710655, 2048, 0, 6449, '2007-03-21 07:09:33', '2007-03-21 07:09:33', NULL, 'utf8_general_ci', NULL, '', '');
INSERT INTO `TABLES` VALUES (NULL, 'ruskidom3', 'packages', 'BASE TABLE', 'MyISAM', 10, 'Dynamic', 1, 80, 80, 281474976710655, 2048, 0, 4, '2007-03-21 07:09:33', '2007-03-21 07:09:33', NULL, 'utf8_general_ci', NULL, '', '');
INSERT INTO `TABLES` VALUES (NULL, 'ruskidom3', 'pages', 'BASE TABLE', 'MyISAM', 10, 'Dynamic', 1, 44, 44, 281474976710655, 2048, 0, 2, '2007-03-21 07:09:34', '2007-03-21 07:09:34', NULL, 'utf8_general_ci', NULL, '', '');
INSERT INTO `TABLES` VALUES (NULL, 'ruskidom3', 'photo_rating', 'BASE TABLE', 'MyISAM', 10, 'Dynamic', 705, 81, 57436, 281474976710655, 11264, 0, 740, '2007-03-21 07:09:34', '2007-05-29 15:41:24', NULL, 'utf8_general_ci', NULL, '', '');
INSERT INTO `TABLES` VALUES (NULL, 'ruskidom3', 'photos', 'BASE TABLE', 'MyISAM', 10, 'Dynamic', 1829, 50, 93852, 281474976710655, 29696, 676, 2759, '2007-03-21 07:09:34', '2007-06-03 22:32:40', NULL, 'utf8_general_ci', NULL, '', '');
INSERT INTO `TABLES` VALUES (NULL, 'ruskidom3', 'polls', 'BASE TABLE', 'MyISAM', 10, 'Dynamic', 16, 55, 884, 281474976710655, 4096, 0, 29, '2007-03-21 07:09:35', '2007-03-21 07:09:35', NULL, 'utf8_general_ci', NULL, '', '');
INSERT INTO `TABLES` VALUES (NULL, 'ruskidom3', 'polls_answers', 'BASE TABLE', 'MyISAM', 10, 'Dynamic', 92, 24, 2292, 281474976710655, 5120, 0, 135, '2007-03-21 07:09:35', '2007-03-21 07:09:35', NULL, 'utf8_general_ci', NULL, '', '');
INSERT INTO `TABLES` VALUES (NULL, 'ruskidom3', 'polls_categories', 'BASE TABLE', 'MyISAM', 10, 'Dynamic', 0, 0, 0, 281474976710655, 1024, 0, 3, '2007-03-21 07:09:35', '2007-03-21 07:09:35', NULL, 'utf8_general_ci', NULL, '', '');
INSERT INTO `TABLES` VALUES (NULL, 'ruskidom3', 'polls_log', 'BASE TABLE', 'MyISAM', 10, 'Fixed', 63, 29, 1827, 8162774324609023, 5120, 0, 64, '2007-03-21 07:09:35', '2007-03-21 07:09:35', NULL, 'utf8_general_ci', NULL, '', '');
INSERT INTO `TABLES` VALUES (NULL, 'ruskidom3', 'privacy', 'BASE TABLE', 'MyISAM', 10, 'Dynamic', 1, 7612, 7612, 281474976710655, 2048, 0, 2, '2007-03-21 07:09:35', '2007-03-21 07:09:35', NULL, 'utf8_general_ci', NULL, '', '');
INSERT INTO `TABLES` VALUES (NULL, 'ruskidom3', 'profile_back', 'BASE TABLE', 'MyISAM', 10, 'Dynamic', 281, 63, 17880, 281474976710655, 5120, 0, 292, '2007-03-21 07:09:35', '2007-05-26 20:14:32', NULL, 'utf8_general_ci', NULL, '', '');
INSERT INTO `TABLES` VALUES (NULL, 'ruskidom3', 'profile_company', 'BASE TABLE', 'MyISAM', 10, 'Dynamic', 29, 75, 2180, 281474976710655, 2048, 0, 38, '2007-03-21 07:09:36', '2007-04-05 12:51:23', NULL, 'utf8_general_ci', NULL, '', '');
INSERT INTO `TABLES` VALUES (NULL, 'ruskidom3', 'profile_flag', 'BASE TABLE', 'MyISAM', 10, 'Fixed', 22, 13, 286, 3659174697238527, 2048, 0, 43, '2007-03-21 07:09:36', '2007-03-21 07:09:36', NULL, 'utf8_general_ci', NULL, '', '');
INSERT INTO `TABLES` VALUES (NULL, 'ruskidom3', 'profile_interests', 'BASE TABLE', 'MyISAM', 10, 'Dynamic', 395, 3309, 1340120, 281474976710655, 7168, 32952, 416, '2007-03-21 07:13:56', '2007-05-29 12:43:40', NULL, 'utf8_general_ci', NULL, '', '');
INSERT INTO `TABLES` VALUES (NULL, 'ruskidom3', 'profile_school', 'BASE TABLE', 'MyISAM', 10, 'Dynamic', 145, 108, 15684, 281474976710655, 4096, 0, 168, '2007-03-21 07:09:36', '2007-03-21 07:09:36', NULL, 'utf8_general_ci', NULL, '', '');
INSERT INTO `TABLES` VALUES (NULL, 'ruskidom3', 'profile_spam', 'BASE TABLE', 'MyISAM', 10, 'Dynamic', 2, 20, 40, 281474976710655, 2048, 0, 3, '2007-03-21 07:09:36', '2007-03-21 07:09:36', NULL, 'utf8_general_ci', NULL, '', '');
INSERT INTO `TABLES` VALUES (NULL, 'ruskidom3', 'profile_views', 'BASE TABLE', 'MyISAM', 10, 'Dynamic', 5144, 28, 145320, 281474976710655, 59392, 0, NULL, '2007-03-21 07:13:56', '2007-06-07 04:47:22', NULL, 'utf8_general_ci', NULL, '', '');
INSERT INTO `TABLES` VALUES (NULL, 'ruskidom3', 'school_name', 'BASE TABLE', 'MyISAM', 10, 'Dynamic', 0, 0, 0, 281474976710655, 1024, 0, 1, '2007-03-21 07:09:36', '2007-03-21 07:09:36', NULL, 'utf8_general_ci', NULL, '', '');
INSERT INTO `TABLES` VALUES (NULL, 'ruskidom3', 'schools', 'BASE TABLE', 'MyISAM', 10, 'Dynamic', 6, 31, 188, 281474976710655, 2048, 0, 7, '2007-03-21 07:09:36', '2007-03-21 07:09:36', NULL, 'utf8_general_ci', NULL, '', '');
INSERT INTO `TABLES` VALUES (NULL, 'ruskidom3', 'settings', 'BASE TABLE', 'MyISAM', 10, 'Dynamic', 1, 24, 24, 281474976710655, 1024, 0, NULL, '2007-03-21 07:09:36', '2007-03-21 07:09:36', NULL, 'utf8_general_ci', NULL, '', '');
INSERT INTO `TABLES` VALUES (NULL, 'ruskidom3', 'shown_images', 'BASE TABLE', 'MyISAM', 10, 'Dynamic', 1085, 48, 52080, 281474976710655, 13312, 0, 1258, '2007-03-21 07:09:36', '2007-05-27 20:39:14', NULL, 'utf8_general_ci', NULL, '', '');
INSERT INTO `TABLES` VALUES (NULL, 'ruskidom3', 'song_critisize', 'BASE TABLE', 'MyISAM', 10, 'Dynamic', 0, 0, 0, 281474976710655, 1024, 0, 5, '2007-03-21 07:09:37', '2007-03-21 07:09:37', NULL, 'utf8_general_ci', NULL, '', '');
INSERT INTO `TABLES` VALUES (NULL, 'ruskidom3', 'song_rating', 'BASE TABLE', 'MyISAM', 10, 'Dynamic', 0, 0, 0, 281474976710655, 1024, 0, 4, '2007-03-21 07:09:37', '2007-03-21 07:09:37', NULL, 'utf8_general_ci', NULL, '', '');
INSERT INTO `TABLES` VALUES (NULL, 'ruskidom3', 'states', 'BASE TABLE', 'MyISAM', 10, 'Dynamic', 46, 20, 956, 281474976710655, 2048, 0, 47, '2007-03-21 07:09:37', '2007-03-21 07:09:37', NULL, 'utf8_general_ci', NULL, '', '');
INSERT INTO `TABLES` VALUES (NULL, 'ruskidom3', 'states_1', 'BASE TABLE', 'MyISAM', 10, 'Dynamic', 51, 21, 1076, 281474976710655, 2048, 0, 52, '2007-03-21 07:09:37', '2007-03-21 07:09:37', NULL, 'utf8_general_ci', NULL, '', '');
INSERT INTO `TABLES` VALUES (NULL, 'ruskidom3', 'terms', 'BASE TABLE', 'MyISAM', 10, 'Dynamic', 1, 15616, 15616, 281474976710655, 2048, 0, 2, '2007-03-21 07:09:37', '2007-03-21 07:09:37', NULL, 'utf8_general_ci', NULL, '', '');
INSERT INTO `TABLES` VALUES (NULL, 'ruskidom3', 'testimonials', 'BASE TABLE', 'MyISAM', 10, 'Dynamic', 1181, 151, 178780, 281474976710655, 17408, 0, 1329, '2007-03-21 07:09:37', '2007-05-24 09:44:58', NULL, 'utf8_general_ci', NULL, '', '');
INSERT INTO `TABLES` VALUES (NULL, 'ruskidom3', 'top_8_friends', 'BASE TABLE', 'MyISAM', 10, 'Fixed', 4, 13, 52, 3659174697238527, 2048, 0, 5, '2007-03-21 07:09:38', '2007-03-21 07:09:38', NULL, 'utf8_general_ci', NULL, '', '');
INSERT INTO `TABLES` VALUES (NULL, 'ruskidom3', 'video_albums', 'BASE TABLE', 'MyISAM', 10, 'Dynamic', 3, 46, 140, 281474976710655, 2048, 0, 6, '2007-03-21 07:09:38', '2007-03-21 07:09:38', NULL, 'utf8_general_ci', NULL, '', '');
INSERT INTO `TABLES` VALUES (NULL, 'ruskidom3', 'video_category', 'BASE TABLE', 'MyISAM', 10, 'Dynamic', 25, 34, 852, 281474976710655, 2048, 0, 26, '2007-03-21 07:09:38', '2007-03-21 07:09:38', NULL, 'utf8_general_ci', NULL, '', '');
INSERT INTO `TABLES` VALUES (NULL, 'ruskidom3', 'video_comments', 'BASE TABLE', 'MyISAM', 10, 'Dynamic', 0, 0, 0, 281474976710655, 1024, 0, 3, '2007-03-21 07:09:38', '2007-03-21 07:09:38', NULL, 'utf8_general_ci', NULL, '', '');
INSERT INTO `TABLES` VALUES (NULL, 'ruskidom3', 'video_favorite', 'BASE TABLE', 'MyISAM', 10, 'Dynamic', 0, 0, 0, 281474976710655, 1024, 0, 3, '2007-03-21 07:09:38', '2007-03-21 07:09:38', NULL, 'utf8_general_ci', NULL, '', '');
INSERT INTO `TABLES` VALUES (NULL, 'ruskidom3', 'video_members', 'BASE TABLE', 'MyISAM', 10, 'Dynamic', 1, 152, 152, 281474976710655, 2048, 0, 11, '2007-03-21 07:09:38', '2007-05-29 19:30:22', NULL, 'utf8_general_ci', NULL, '', '');
INSERT INTO `TABLES` VALUES (NULL, 'ruskidom3', 'video_playlist', 'BASE TABLE', 'MyISAM', 10, 'Dynamic', 0, 0, 0, 281474976710655, 1024, 0, 3, '2007-03-21 07:09:38', '2007-03-21 07:09:38', NULL, 'utf8_general_ci', NULL, '', '');

-- --------------------------------------------------------

-- 
-- Table structure for table `TABLE_CONSTRAINTS`
-- 

CREATE TEMPORARY TABLE `TABLE_CONSTRAINTS` (
  `CONSTRAINT_CATALOG` varchar(512) default NULL,
  `CONSTRAINT_SCHEMA` varchar(64) NOT NULL default '',
  `CONSTRAINT_NAME` varchar(64) NOT NULL default '',
  `TABLE_SCHEMA` varchar(64) NOT NULL default '',
  `TABLE_NAME` varchar(64) NOT NULL default '',
  `CONSTRAINT_TYPE` varchar(64) NOT NULL default ''
) TYPE=MEMORY ;

-- 
-- Dumping data for table `TABLE_CONSTRAINTS`
-- 

INSERT INTO `TABLE_CONSTRAINTS` VALUES (NULL, 'ruskidom3', 'address_id', 'ruskidom3', 'address_book', 'UNIQUE');
INSERT INTO `TABLE_CONSTRAINTS` VALUES (NULL, 'ruskidom3', 'admin_id', 'ruskidom3', 'admin_control', 'UNIQUE');
INSERT INTO `TABLE_CONSTRAINTS` VALUES (NULL, 'ruskidom3', 'message_id', 'ruskidom3', 'admin_message', 'UNIQUE');
INSERT INTO `TABLE_CONSTRAINTS` VALUES (NULL, 'ruskidom3', 'message_id', 'ruskidom3', 'admin_reply', 'UNIQUE');
INSERT INTO `TABLE_CONSTRAINTS` VALUES (NULL, 'ruskidom3', 'admin_id', 'ruskidom3', 'admin_users', 'UNIQUE');
INSERT INTO `TABLE_CONSTRAINTS` VALUES (NULL, 'ruskidom3', 'PRIMARY', 'ruskidom3', 'auth', 'PRIMARY KEY');
INSERT INTO `TABLE_CONSTRAINTS` VALUES (NULL, 'ruskidom3', 'id', 'ruskidom3', 'auth', 'UNIQUE');
INSERT INTO `TABLE_CONSTRAINTS` VALUES (NULL, 'ruskidom3', 'test_id', 'ruskidom3', 'band_review', 'UNIQUE');
INSERT INTO `TABLE_CONSTRAINTS` VALUES (NULL, 'ruskidom3', 'PRIMARY', 'ruskidom3', 'banned_ip', 'PRIMARY KEY');
INSERT INTO `TABLE_CONSTRAINTS` VALUES (NULL, 'ruskidom3', 'PRIMARY', 'ruskidom3', 'blog_comments', 'PRIMARY KEY');
INSERT INTO `TABLE_CONSTRAINTS` VALUES (NULL, 'ruskidom3', 'PRIMARY', 'ruskidom3', 'blog_moderators', 'PRIMARY KEY');
INSERT INTO `TABLE_CONSTRAINTS` VALUES (NULL, 'ruskidom3', 'PRIMARY', 'ruskidom3', 'blog_mood', 'PRIMARY KEY');
INSERT INTO `TABLE_CONSTRAINTS` VALUES (NULL, 'ruskidom3', 'PRIMARY', 'ruskidom3', 'blog_preffered', 'PRIMARY KEY');
INSERT INTO `TABLE_CONSTRAINTS` VALUES (NULL, 'ruskidom3', 'PRIMARY', 'ruskidom3', 'blog_subscriptions', 'PRIMARY KEY');
INSERT INTO `TABLE_CONSTRAINTS` VALUES (NULL, 'ruskidom3', 'PRIMARY', 'ruskidom3', 'blogs', 'PRIMARY KEY');
INSERT INTO `TABLE_CONSTRAINTS` VALUES (NULL, 'ruskidom3', 'board_id', 'ruskidom3', 'board_main', 'UNIQUE');
INSERT INTO `TABLE_CONSTRAINTS` VALUES (NULL, 'ruskidom3', 'board_sub_id1', 'ruskidom3', 'board_reply', 'UNIQUE');
INSERT INTO `TABLE_CONSTRAINTS` VALUES (NULL, 'ruskidom3', 'board_sub_id', 'ruskidom3', 'board_sub', 'UNIQUE');
INSERT INTO `TABLE_CONSTRAINTS` VALUES (NULL, 'ruskidom3', 'book_id', 'ruskidom3', 'bookmarks', 'UNIQUE');
INSERT INTO `TABLE_CONSTRAINTS` VALUES (NULL, 'ruskidom3', 'PRIMARY', 'ruskidom3', 'bulletin_message', 'PRIMARY KEY');
INSERT INTO `TABLE_CONSTRAINTS` VALUES (NULL, 'ruskidom3', 'city_id', 'ruskidom3', 'cities', 'UNIQUE');
INSERT INTO `TABLE_CONSTRAINTS` VALUES (NULL, 'ruskidom3', 'PRIMARY', 'ruskidom3', 'classified_cat', 'PRIMARY KEY');
INSERT INTO `TABLE_CONSTRAINTS` VALUES (NULL, 'ruskidom3', 'PRIMARY', 'ruskidom3', 'classified_listing', 'PRIMARY KEY');
INSERT INTO `TABLE_CONSTRAINTS` VALUES (NULL, 'ruskidom3', 'PRIMARY', 'ruskidom3', 'classified_sub_cat', 'PRIMARY KEY');
INSERT INTO `TABLE_CONSTRAINTS` VALUES (NULL, 'ruskidom3', 'college_id', 'ruskidom3', 'colleges', 'UNIQUE');
INSERT INTO `TABLE_CONSTRAINTS` VALUES (NULL, 'ruskidom3', 'PRIMARY', 'ruskidom3', 'events', 'PRIMARY KEY');
INSERT INTO `TABLE_CONSTRAINTS` VALUES (NULL, 'ruskidom3', 'PRIMARY', 'ruskidom3', 'events_cat', 'PRIMARY KEY');
INSERT INTO `TABLE_CONSTRAINTS` VALUES (NULL, 'ruskidom3', 'PRIMARY', 'ruskidom3', 'events_comments', 'PRIMARY KEY');
INSERT INTO `TABLE_CONSTRAINTS` VALUES (NULL, 'ruskidom3', 'PRIMARY', 'ruskidom3', 'events_rsvp', 'PRIMARY KEY');
INSERT INTO `TABLE_CONSTRAINTS` VALUES (NULL, 'ruskidom3', 'PRIMARY', 'ruskidom3', 'forum_main_cat', 'PRIMARY KEY');
INSERT INTO `TABLE_CONSTRAINTS` VALUES (NULL, 'ruskidom3', 'PRIMARY', 'ruskidom3', 'forum_posts', 'PRIMARY KEY');
INSERT INTO `TABLE_CONSTRAINTS` VALUES (NULL, 'ruskidom3', 'PRIMARY', 'ruskidom3', 'forum_sub_cat', 'PRIMARY KEY');
INSERT INTO `TABLE_CONSTRAINTS` VALUES (NULL, 'ruskidom3', 'PRIMARY', 'ruskidom3', 'forum_topics', 'PRIMARY KEY');
INSERT INTO `TABLE_CONSTRAINTS` VALUES (NULL, 'ruskidom3', 'book_id', 'ruskidom3', 'g_bookmarks', 'UNIQUE');
INSERT INTO `TABLE_CONSTRAINTS` VALUES (NULL, 'ruskidom3', 'journal_id', 'ruskidom3', 'g_journal', 'UNIQUE');
INSERT INTO `TABLE_CONSTRAINTS` VALUES (NULL, 'ruskidom3', 'mess_id', 'ruskidom3', 'g_messages', 'UNIQUE');
INSERT INTO `TABLE_CONSTRAINTS` VALUES (NULL, 'ruskidom3', 'test_id', 'ruskidom3', 'g_testimonials', 'UNIQUE');
INSERT INTO `TABLE_CONSTRAINTS` VALUES (NULL, 'ruskidom3', 'PRIMARY', 'ruskidom3', 'group_bulletin', 'PRIMARY KEY');
INSERT INTO `TABLE_CONSTRAINTS` VALUES (NULL, 'ruskidom3', 'PRIMARY', 'ruskidom3', 'group_bulletin_reply', 'PRIMARY KEY');
INSERT INTO `TABLE_CONSTRAINTS` VALUES (NULL, 'ruskidom3', 'PRIMARY', 'ruskidom3', 'group_cat', 'PRIMARY KEY');
INSERT INTO `TABLE_CONSTRAINTS` VALUES (NULL, 'ruskidom3', 'id', 'ruskidom3', 'group_friends', 'UNIQUE');
INSERT INTO `TABLE_CONSTRAINTS` VALUES (NULL, 'ruskidom3', 'invite_id', 'ruskidom3', 'group_invites', 'UNIQUE');
INSERT INTO `TABLE_CONSTRAINTS` VALUES (NULL, 'ruskidom3', 'photo_id', 'ruskidom3', 'group_photos', 'UNIQUE');
INSERT INTO `TABLE_CONSTRAINTS` VALUES (NULL, 'ruskidom3', 'PRIMARY', 'ruskidom3', 'group_topic_reply', 'PRIMARY KEY');
INSERT INTO `TABLE_CONSTRAINTS` VALUES (NULL, 'ruskidom3', 'PRIMARY', 'ruskidom3', 'group_topics', 'PRIMARY KEY');
INSERT INTO `TABLE_CONSTRAINTS` VALUES (NULL, 'ruskidom3', 'PRIMARY', 'ruskidom3', 'groups', 'PRIMARY KEY');
INSERT INTO `TABLE_CONSTRAINTS` VALUES (NULL, 'ruskidom3', 'group_id', 'ruskidom3', 'groups_creator', 'UNIQUE');
INSERT INTO `TABLE_CONSTRAINTS` VALUES (NULL, 'ruskidom3', 'PRIMARY', 'ruskidom3', 'hotornot_rating', 'PRIMARY KEY');
INSERT INTO `TABLE_CONSTRAINTS` VALUES (NULL, 'ruskidom3', 'PRIMARY', 'ruskidom3', 'invitations', 'PRIMARY KEY');
INSERT INTO `TABLE_CONSTRAINTS` VALUES (NULL, 'ruskidom3', 'id', 'ruskidom3', 'invitations', 'UNIQUE');
INSERT INTO `TABLE_CONSTRAINTS` VALUES (NULL, 'ruskidom3', 'invite_id', 'ruskidom3', 'invite_temp_emails', 'UNIQUE');
INSERT INTO `TABLE_CONSTRAINTS` VALUES (NULL, 'ruskidom3', 'invite_id', 'ruskidom3', 'invite_temp_group_emails', 'UNIQUE');
INSERT INTO `TABLE_CONSTRAINTS` VALUES (NULL, 'ruskidom3', 'invite_id', 'ruskidom3', 'invites', 'UNIQUE');
INSERT INTO `TABLE_CONSTRAINTS` VALUES (NULL, 'ruskidom3', 'journal_id', 'ruskidom3', 'journal', 'UNIQUE');
INSERT INTO `TABLE_CONSTRAINTS` VALUES (NULL, 'ruskidom3', 'comment_id', 'ruskidom3', 'journal_comment', 'UNIQUE');
INSERT INTO `TABLE_CONSTRAINTS` VALUES (NULL, 'ruskidom3', 'login_id', 'ruskidom3', 'login_page', 'UNIQUE');
INSERT INTO `TABLE_CONSTRAINTS` VALUES (NULL, 'ruskidom3', 'main_id', 'ruskidom3', 'main_page', 'UNIQUE');
INSERT INTO `TABLE_CONSTRAINTS` VALUES (NULL, 'ruskidom3', 'id', 'ruskidom3', 'member_friends', 'UNIQUE');
INSERT INTO `TABLE_CONSTRAINTS` VALUES (NULL, 'ruskidom3', 'PRIMARY', 'ruskidom3', 'member_networking', 'PRIMARY KEY');
INSERT INTO `TABLE_CONSTRAINTS` VALUES (NULL, 'ruskidom3', 'member_id', 'ruskidom3', 'members', 'UNIQUE');
INSERT INTO `TABLE_CONSTRAINTS` VALUES (NULL, 'ruskidom3', 'mess_id', 'ruskidom3', 'messages', 'UNIQUE');
INSERT INTO `TABLE_CONSTRAINTS` VALUES (NULL, 'ruskidom3', 'mess_id', 'ruskidom3', 'messages_sent', 'UNIQUE');
INSERT INTO `TABLE_CONSTRAINTS` VALUES (NULL, 'ruskidom3', 'PRIMARY', 'ruskidom3', 'misc', 'PRIMARY KEY');
INSERT INTO `TABLE_CONSTRAINTS` VALUES (NULL, 'ruskidom3', 'PRIMARY', 'ruskidom3', 'moderators_classified', 'PRIMARY KEY');
INSERT INTO `TABLE_CONSTRAINTS` VALUES (NULL, 'ruskidom3', 'PRIMARY', 'ruskidom3', 'moderators_events', 'PRIMARY KEY');
INSERT INTO `TABLE_CONSTRAINTS` VALUES (NULL, 'ruskidom3', 'PRIMARY', 'ruskidom3', 'moderators_groups', 'PRIMARY KEY');
INSERT INTO `TABLE_CONSTRAINTS` VALUES (NULL, 'ruskidom3', 'PRIMARY', 'ruskidom3', 'moderators_music', 'PRIMARY KEY');
INSERT INTO `TABLE_CONSTRAINTS` VALUES (NULL, 'ruskidom3', 'PRIMARY', 'ruskidom3', 'moderators_pics', 'PRIMARY KEY');
INSERT INTO `TABLE_CONSTRAINTS` VALUES (NULL, 'ruskidom3', 'PRIMARY', 'ruskidom3', 'most_popular', 'PRIMARY KEY');
INSERT INTO `TABLE_CONSTRAINTS` VALUES (NULL, 'ruskidom3', 'PRIMARY', 'ruskidom3', 'music_genre', 'PRIMARY KEY');
INSERT INTO `TABLE_CONSTRAINTS` VALUES (NULL, 'ruskidom3', 'PRIMARY', 'ruskidom3', 'music_member_profile', 'PRIMARY KEY');
INSERT INTO `TABLE_CONSTRAINTS` VALUES (NULL, 'ruskidom3', 'PRIMARY', 'ruskidom3', 'music_members', 'PRIMARY KEY');
INSERT INTO `TABLE_CONSTRAINTS` VALUES (NULL, 'ruskidom3', 'PRIMARY', 'ruskidom3', 'music_profile', 'PRIMARY KEY');
INSERT INTO `TABLE_CONSTRAINTS` VALUES (NULL, 'ruskidom3', 'PRIMARY', 'ruskidom3', 'music_shows', 'PRIMARY KEY');
INSERT INTO `TABLE_CONSTRAINTS` VALUES (NULL, 'ruskidom3', 'PRIMARY', 'ruskidom3', 'music_songs', 'PRIMARY KEY');
INSERT INTO `TABLE_CONSTRAINTS` VALUES (NULL, 'ruskidom3', 'PRIMARY', 'ruskidom3', 'news', 'PRIMARY KEY');
INSERT INTO `TABLE_CONSTRAINTS` VALUES (NULL, 'ruskidom3', 'PRIMARY', 'ruskidom3', 'online_now', 'PRIMARY KEY');
INSERT INTO `TABLE_CONSTRAINTS` VALUES (NULL, 'ruskidom3', 'PRIMARY', 'ruskidom3', 'packages', 'PRIMARY KEY');
INSERT INTO `TABLE_CONSTRAINTS` VALUES (NULL, 'ruskidom3', 'page_id', 'ruskidom3', 'pages', 'UNIQUE');
INSERT INTO `TABLE_CONSTRAINTS` VALUES (NULL, 'ruskidom3', 'PRIMARY', 'ruskidom3', 'photo_rating', 'PRIMARY KEY');
INSERT INTO `TABLE_CONSTRAINTS` VALUES (NULL, 'ruskidom3', 'photo_id', 'ruskidom3', 'photos', 'UNIQUE');
INSERT INTO `TABLE_CONSTRAINTS` VALUES (NULL, 'ruskidom3', 'PRIMARY', 'ruskidom3', 'polls', 'PRIMARY KEY');
INSERT INTO `TABLE_CONSTRAINTS` VALUES (NULL, 'ruskidom3', 'PRIMARY', 'ruskidom3', 'polls_answers', 'PRIMARY KEY');
INSERT INTO `TABLE_CONSTRAINTS` VALUES (NULL, 'ruskidom3', 'PRIMARY', 'ruskidom3', 'polls_categories', 'PRIMARY KEY');
INSERT INTO `TABLE_CONSTRAINTS` VALUES (NULL, 'ruskidom3', 'PRIMARY', 'ruskidom3', 'polls_log', 'PRIMARY KEY');
INSERT INTO `TABLE_CONSTRAINTS` VALUES (NULL, 'ruskidom3', 'privacy_id', 'ruskidom3', 'privacy', 'UNIQUE');
INSERT INTO `TABLE_CONSTRAINTS` VALUES (NULL, 'ruskidom3', 'PRIMARY', 'ruskidom3', 'profile_back', 'PRIMARY KEY');
INSERT INTO `TABLE_CONSTRAINTS` VALUES (NULL, 'ruskidom3', 'PRIMARY', 'ruskidom3', 'profile_company', 'PRIMARY KEY');
INSERT INTO `TABLE_CONSTRAINTS` VALUES (NULL, 'ruskidom3', 'flag_id', 'ruskidom3', 'profile_flag', 'UNIQUE');
INSERT INTO `TABLE_CONSTRAINTS` VALUES (NULL, 'ruskidom3', 'PRIMARY', 'ruskidom3', 'profile_interests', 'PRIMARY KEY');
INSERT INTO `TABLE_CONSTRAINTS` VALUES (NULL, 'ruskidom3', 'PRIMARY', 'ruskidom3', 'profile_school', 'PRIMARY KEY');
INSERT INTO `TABLE_CONSTRAINTS` VALUES (NULL, 'ruskidom3', 'PRIMARY', 'ruskidom3', 'profile_spam', 'PRIMARY KEY');
INSERT INTO `TABLE_CONSTRAINTS` VALUES (NULL, 'ruskidom3', 'school_id', 'ruskidom3', 'school_name', 'UNIQUE');
INSERT INTO `TABLE_CONSTRAINTS` VALUES (NULL, 'ruskidom3', 'school_id', 'ruskidom3', 'schools', 'UNIQUE');
INSERT INTO `TABLE_CONSTRAINTS` VALUES (NULL, 'ruskidom3', 'PRIMARY', 'ruskidom3', 'shown_images', 'PRIMARY KEY');
INSERT INTO `TABLE_CONSTRAINTS` VALUES (NULL, 'ruskidom3', 'PRIMARY', 'ruskidom3', 'song_critisize', 'PRIMARY KEY');
INSERT INTO `TABLE_CONSTRAINTS` VALUES (NULL, 'ruskidom3', 'PRIMARY', 'ruskidom3', 'song_rating', 'PRIMARY KEY');
INSERT INTO `TABLE_CONSTRAINTS` VALUES (NULL, 'ruskidom3', 'state_id', 'ruskidom3', 'states', 'UNIQUE');
INSERT INTO `TABLE_CONSTRAINTS` VALUES (NULL, 'ruskidom3', 'state_id', 'ruskidom3', 'states_1', 'UNIQUE');
INSERT INTO `TABLE_CONSTRAINTS` VALUES (NULL, 'ruskidom3', 'term_id', 'ruskidom3', 'terms', 'UNIQUE');
INSERT INTO `TABLE_CONSTRAINTS` VALUES (NULL, 'ruskidom3', 'test_id', 'ruskidom3', 'testimonials', 'UNIQUE');
INSERT INTO `TABLE_CONSTRAINTS` VALUES (NULL, 'ruskidom3', 'PRIMARY', 'ruskidom3', 'top_8_friends', 'PRIMARY KEY');
INSERT INTO `TABLE_CONSTRAINTS` VALUES (NULL, 'ruskidom3', 'PRIMARY', 'ruskidom3', 'video_albums', 'PRIMARY KEY');
INSERT INTO `TABLE_CONSTRAINTS` VALUES (NULL, 'ruskidom3', 'PRIMARY', 'ruskidom3', 'video_category', 'PRIMARY KEY');
INSERT INTO `TABLE_CONSTRAINTS` VALUES (NULL, 'ruskidom3', 'PRIMARY', 'ruskidom3', 'video_comments', 'PRIMARY KEY');
INSERT INTO `TABLE_CONSTRAINTS` VALUES (NULL, 'ruskidom3', 'PRIMARY', 'ruskidom3', 'video_favorite', 'PRIMARY KEY');
INSERT INTO `TABLE_CONSTRAINTS` VALUES (NULL, 'ruskidom3', 'PRIMARY', 'ruskidom3', 'video_members', 'PRIMARY KEY');
INSERT INTO `TABLE_CONSTRAINTS` VALUES (NULL, 'ruskidom3', 'PRIMARY', 'ruskidom3', 'video_playlist', 'PRIMARY KEY');

-- --------------------------------------------------------

-- 
-- Table structure for table `TABLE_PRIVILEGES`
-- 

CREATE TEMPORARY TABLE `TABLE_PRIVILEGES` (
  `GRANTEE` varchar(81) NOT NULL default '',
  `TABLE_CATALOG` varchar(512) default NULL,
  `TABLE_SCHEMA` varchar(64) NOT NULL default '',
  `TABLE_NAME` varchar(64) NOT NULL default '',
  `PRIVILEGE_TYPE` varchar(64) NOT NULL default '',
  `IS_GRANTABLE` varchar(3) NOT NULL default ''
) TYPE=MEMORY ;

-- 
-- Dumping data for table `TABLE_PRIVILEGES`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `TRIGGERS`
-- 

CREATE TEMPORARY TABLE `TRIGGERS` (
  `TRIGGER_CATALOG` varchar(512) default NULL,
  `TRIGGER_SCHEMA` varchar(64) NOT NULL default '',
  `TRIGGER_NAME` varchar(64) NOT NULL default '',
  `EVENT_MANIPULATION` varchar(6) NOT NULL default '',
  `EVENT_OBJECT_CATALOG` varchar(512) default NULL,
  `EVENT_OBJECT_SCHEMA` varchar(64) NOT NULL default '',
  `EVENT_OBJECT_TABLE` varchar(64) NOT NULL default '',
  `ACTION_ORDER` bigint(4) NOT NULL default '0',
  `ACTION_CONDITION` longtext,
  `ACTION_STATEMENT` longtext NOT NULL,
  `ACTION_ORIENTATION` varchar(9) NOT NULL default '',
  `ACTION_TIMING` varchar(6) NOT NULL default '',
  `ACTION_REFERENCE_OLD_TABLE` varchar(64) default NULL,
  `ACTION_REFERENCE_NEW_TABLE` varchar(64) default NULL,
  `ACTION_REFERENCE_OLD_ROW` varchar(3) NOT NULL default '',
  `ACTION_REFERENCE_NEW_ROW` varchar(3) NOT NULL default '',
  `CREATED` datetime default NULL,
  `SQL_MODE` longtext NOT NULL,
  `DEFINER` longtext NOT NULL
) TYPE=MyISAM ;

-- 
-- Dumping data for table `TRIGGERS`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `USER_PRIVILEGES`
-- 

CREATE TEMPORARY TABLE `USER_PRIVILEGES` (
  `GRANTEE` varchar(81) NOT NULL default '',
  `TABLE_CATALOG` varchar(512) default NULL,
  `PRIVILEGE_TYPE` varchar(64) NOT NULL default '',
  `IS_GRANTABLE` varchar(3) NOT NULL default ''
) TYPE=MEMORY ;

-- 
-- Dumping data for table `USER_PRIVILEGES`
-- 

INSERT INTO `USER_PRIVILEGES` VALUES ('''ruskidom3''@''%''', NULL, 'USAGE', 'NO');

-- --------------------------------------------------------

-- 
-- Table structure for table `VIEWS`
-- 

CREATE TEMPORARY TABLE `VIEWS` (
  `TABLE_CATALOG` varchar(512) default NULL,
  `TABLE_SCHEMA` varchar(64) NOT NULL default '',
  `TABLE_NAME` varchar(64) NOT NULL default '',
  `VIEW_DEFINITION` longtext NOT NULL,
  `CHECK_OPTION` varchar(8) NOT NULL default '',
  `IS_UPDATABLE` varchar(3) NOT NULL default '',
  `DEFINER` varchar(77) NOT NULL default '',
  `SECURITY_TYPE` varchar(7) NOT NULL default ''
) TYPE=MyISAM ;

-- 
-- Dumping data for table `VIEWS`
-- 
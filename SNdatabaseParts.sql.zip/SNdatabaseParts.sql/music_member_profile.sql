-- --------------------------------------------------------

-- 
-- Table structure for table `music_member_profile`
-- 

CREATE TABLE `music_member_profile` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `user_id` int(10) NOT NULL default '0',
  `user_name` varchar(255) NOT NULL default '',
  `genre1` int(10) NOT NULL default '0',
  `genre2` int(10) NOT NULL default '0',
  `genre3` int(10) NOT NULL default '0',
  `website` varchar(255) NOT NULL default '',
  `label` varchar(255) NOT NULL default '',
  `label_type` varchar(255) NOT NULL default '',
  `here_for` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`id`)
) TYPE=MyISAM  AUTO_INCREMENT=41 ;

-- 
-- Dumping data for table `music_member_profile`
-- 

INSERT INTO `music_member_profile` VALUES (21, 1036, 'Just A Mix', 8, 16, 19, '', 'unsigned', 'None', '');
INSERT INTO `music_member_profile` VALUES (22, 1045, 'Philip Kirkorov', 14, 15, 11, '', 'unsigned', 'None', 'Fan Community');
INSERT INTO `music_member_profile` VALUES (5, 55, 'Band 5', 1, 1, 2, 'http://www.vastal.com', 'None', 'None', 'Networking with Fans,Networking with Bands,Fan Community,Distribution,Promotion,Online Marketing,Record Deal,Concert Gigs,Constructive Reviews,Recording,Licensing,Manager,Producer,Attorney');
INSERT INTO `music_member_profile` VALUES (17, 758, 'skyliquors', 19, 7, 15, '', 'unsigned', '', 'Networking with Fans,Fan Community,Promotion,Record Deal,Concert Gigs,Constructive Reviews');
INSERT INTO `music_member_profile` VALUES (15, 172, 'affa', 2, 0, 0, '', '', 'Self-Produced', 'Networking with Fans,Networking with Bands,Fan Community,Distribution,Promotion,Online Marketing,Record Deal,Constructive Reviews,Recording,Licensing,Manager,Producer,Attorney');
INSERT INTO `music_member_profile` VALUES (20, 907, 'Anna''s Mix', 12, 14, 19, '', 'unsigned', '', '');
INSERT INTO `music_member_profile` VALUES (18, 856, 'russian dance floor', 14, 8, 7, 'http://www.myspace.com/russianmixx', '', 'None', 'Networking with Bands');
INSERT INTO `music_member_profile` VALUES (19, 895, 'Alla''s Mix', 15, 0, 0, '', 'unsigned', 'None', '');
INSERT INTO `music_member_profile` VALUES (12, 141, 'taylorstreet', 0, 0, 0, 'www.taylor-street.com', 'unsigned', 'None', 'Networking with Fans,Networking with Bands,Promotion,Online Marketing,Constructive Reviews,Manager,Producer');
INSERT INTO `music_member_profile` VALUES (23, 1109, 'Bratva', 15, 0, 0, '', 'unsigned', '', '');
INSERT INTO `music_member_profile` VALUES (24, 1136, 'Rouri''s music', 15, 0, 0, 'www.myspace.com/rockerroyalty', 'unsigned', 'None', '');
INSERT INTO `music_member_profile` VALUES (25, 1163, 'Evanescence', 13, 18, 4, 'www.evanescence.com', 'unsigned', '', '');
INSERT INTO `music_member_profile` VALUES (26, 1198, 'Jim', 18, 0, 0, '', 'unsigned', '', '');
INSERT INTO `music_member_profile` VALUES (27, 1252, 'Adema', 13, 0, 0, 'www.christalley.com', 'None', 'None', 'Networking with Fans,Networking with Bands,Fan Community');
INSERT INTO `music_member_profile` VALUES (28, 1253, 'Insane Clown Posse', 4, 17, 0, 'www.insaneclownposse.com', 'Psychopathic Records', 'Major', 'Networking with Fans,Networking with Bands,Fan Community,Distribution,Promotion,Online Marketing,Record Deal,Concert Gigs,Constructive Reviews,Recording,Producer');
INSERT INTO `music_member_profile` VALUES (29, 1254, 'Twiztid', 17, 13, 18, 'Twiztid.com', 'Psychopathic Records', 'Major', 'Networking with Fans,Promotion');
INSERT INTO `music_member_profile` VALUES (30, 1256, 'Linkin Park', 13, 17, 0, 'www.linkinpark.com', 'Warner Bros.', 'Major', 'Networking with Fans,Networking with Bands,Fan Community,Distribution,Promotion,Online Marketing,Record Deal,Concert Gigs,Recording,Licensing,Manager,Producer');
INSERT INTO `music_member_profile` VALUES (31, 1257, 'HiTz The rOcK', 18, 13, 4, 'www.myspace.com/rockthehitz100', 'unsigned', 'None', 'Networking with Fans,Networking with Bands,Fan Community');
INSERT INTO `music_member_profile` VALUES (32, 1258, 'Kottonmouth Kings', 4, 17, 0, 'www.kottonmouthkings.com', 'Suburban Noize', 'Major', 'Networking with Fans,Networking with Bands,Fan Community,Promotion,Concert Gigs');
INSERT INTO `music_member_profile` VALUES (33, 1261, 'Limp Bizkit', 17, 13, 0, 'www.limp-bizkit.com', 'Major', '', 'Networking with Fans,Networking with Bands,Fan Community');
INSERT INTO `music_member_profile` VALUES (34, 1273, 'Smile Empty Soul', 18, 0, 0, '', 'unsigned', '', 'Networking with Fans,Networking with Bands,Fan Community');
INSERT INTO `music_member_profile` VALUES (35, 1279, 'Dark Lotus', 17, 13, 0, '', 'Psychopathic Records', 'Major', 'Networking with Fans,Fan Community,Promotion');
INSERT INTO `music_member_profile` VALUES (36, 1280, 'Three Days Grace', 18, 18, 0, 'www.threedaysgrace.com', 'RCA', 'Major', 'Networking with Fans,Networking with Bands,Fan Community,Promotion');
INSERT INTO `music_member_profile` VALUES (37, 1284, 'Allele', 4, 13, 0, 'www.allele.com', 'Major', 'Major', 'Networking with Fans,Networking with Bands,Fan Community');
INSERT INTO `music_member_profile` VALUES (38, 1296, 'Chain Smokers United', 17, 13, 0, '', 'Palooza', 'Self-Produced', 'Networking with Fans,Fan Community,Promotion,Record Deal,Concert Gigs,Recording');
INSERT INTO `music_member_profile` VALUES (39, 1357, 'Testergbg', 15, 5, 5, 'http://testerswt.com', 'unsigned', 'Major', 'Attorney');
INSERT INTO `music_member_profile` VALUES (40, 1378, 'httpwwwnonecom', 1, 0, 0, 'http://www.none.com', 'unsigned', 'None', 'Networking with Fans');

-- --------------------------------------------------------

-- 
-- Table structure for table `music_members`
-- 

CREATE TABLE `music_members` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `member_id` int(10) NOT NULL default '0',
  `member_name` varchar(255) NOT NULL default '',
  `biography` blob NOT NULL,
  `instrument` blob NOT NULL,
  `influences` blob NOT NULL,
  `sounds_like` blob NOT NULL,
  `member_talent` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`id`)
) TYPE=MyISAM  AUTO_INCREMENT=3 ;

-- 
-- Dumping data for table `music_members`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `music_profile`
-- 

CREATE TABLE `music_profile` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `member_id` int(10) NOT NULL default '0',
  `headline` varchar(255) NOT NULL default '',
  `bio` mediumtext NOT NULL,
  `members` mediumtext NOT NULL,
  `influences` mediumtext NOT NULL,
  `sounds_like` mediumtext NOT NULL,
  `website` varchar(255) NOT NULL default '',
  `record_label` mediumtext NOT NULL,
  `label_type` mediumtext NOT NULL,
  PRIMARY KEY  (`id`)
) TYPE=MyISAM  AUTO_INCREMENT=58 ;

-- 
-- Dumping data for table `music_profile`
-- 

INSERT INTO `music_profile` VALUES (6, 55, '', '', '', '', '', '', '', '');
INSERT INTO `music_profile` VALUES (18, 172, 'MUSIC 4EVERY1, ENJOY', 'COOL MUSIC FOR COOL RUSKI DOM PEOPLE', 'ALL WELCOME', 'INFLUENCED BY MUSIC ALL DAY ALL NIGHT LONG', 'EVERYTHING NICE YOU EVER HEARD', '', 'DEEZ NUTS PRODUCTION', '');
INSERT INTO `music_profile` VALUES (19, 270, '', '', '', '', '', '', '', '');
INSERT INTO `music_profile` VALUES (15, 141, '', '', '', '', '', '', '', '');
INSERT INTO `music_profile` VALUES (21, 0, '', '', '', '', '', '', '', '');
INSERT INTO `music_profile` VALUES (22, 758, '', '', '', '', '', '', '', '');
INSERT INTO `music_profile` VALUES (23, 856, 'love for russian music !! [&#9829;]', '', '', '', '', '', '', '<font size="2"><font face="Calligraph421 BT">i like to read but i dont have any specific book in mind right now  !!!</font>\r\n\r\n\r\n\r\n\r\n<a href="http://www.myglitterspace.com"target=_blank><img src="http://www.myspacenow.com/myspace/myspace-candybardolls13.gif" border=0 alt="Glitter Graphics, Myspace Graphics, MySpace Glitter Graphics, MySpace Glitters, MySpace Goodies, Myspace Codes at www.MyGlitterSpace.com"></a>\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n<style type="text/css">\r\ntable table table td.text div img {visibility:hidden;}\r\ntable table table td.text div {\r\nbackground-image:url("http://c.myspace.com/Groups/00008/62/97/8647926_m.gif");\r\nbackground-repeat:no-repeat;}\r\ntable table table td.text table table div img {visibility:visible;}\r\ntable table td.text table div, table table table td.text table div {\r\nbackground-image:none;}\r\n.MCT:active { content: "Online Now! by MCT @ http://myspace.com/contacttables"; }\r\n</style>\r\n<a href="http://www.myspace.com/contacttables" class="test" style="z-index:9; width:100px; height:16px; position:absolute; top:8px; left:50%; margin-left:180px;background-image:url(''http://c.myspace.com/Groups/00007/21/21/7841212_m.gif'');"></a>\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n<style type="text/css">\r\n.mygen { Created using MyGen 2.5 - www.mygen.co.uk }\r\n\r\n.mygen { Background Properties }\r\ntable, tr, td { background-color:transparent; border:none; border-width:0;}\r\nbody {\r\n	background-image:url(''http://img509.imageshack.us/img509/6614/loveisintheairbycimoetz1kr.jpg'');\r\n	background-attachment: fixed;\r\n	background-position:center right;\r\n	background-repeat:no-repeat;\r\n	scrollbar-face-color:FFDDFF;\r\n	scrollbar-highlight-color:EE2288;\r\n	scrollbar-3dlight-color:AA22AA;\r\n	scrollbar-shadow-color:999999;\r\n	scrollbar-darkshadow-color:222222;\r\n	scrollbar-arrow-color:AA2288;\r\n	scrollbar-track-color:FFFFFF;\r\n	 }\r\n\r\n.mygen { Table Properties }\r\ntable table { border: 0px }\r\ntable table table table{border:0px}\r\ntable table table {\r\n	border-style:double;\r\n	border-width:3px;\r\n	border-color:FFFFFF;\r\n	   		}\r\n\r\n.mygen { Text Properties }\r\ntable, tr, td, li, p, div { font-family:comic sans ms; color:2244AA;   font-style:italic;   } \r\n.btext { font-family:comic sans ms; color:228866;   font-style:italic;   } \r\n.blacktext10 { font-family:comic sans ms; color:2266AA;      } \r\n.blacktext12 { font-family:comic sans ms; color:8822AA;      } \r\n.lightbluetext8 { font-family:comic sans ms; color:EE2266;      } \r\n.orangetext15 { font-family:comic sans ms; color:228888;      } \r\n.redtext { font-family:comic sans ms; color:333333;      } \r\n.redbtext { font-family:comic sans ms; color:BB99DD;      } \r\n.text { font-family:comic sans ms; color:EE2266;  font-weight:bold;    } \r\n.whitetext12 { font-family:comic sans ms; color:224488;      } \r\na:active, a:visited, a:link {  color:8822AA;      } \r\na:hover {  color:FFFFFF;      } \r\na.navbar:active, a.navbar:visited, a.navbar:link {  color:22AAAA;      } \r\na.navbar:hover {  color:AA22AA;      } \r\na.redlink:active, a.redlink:visited, a.redlink:link {  color:EE2288;      } \r\na.redlink:hover {  color:2222CC;      } \r\n.nametext {  color:226666;  font-weight:bold; font-style:italic;  text-decoration:underline; } \r\n\r\n.mygen { Miscellaneous Properties }\r\nimg { filter:Alpha(Opacity=100,  FinishOpacity=0,  Style=2,  StartX=20,  StartY=40,  FinishX=0,  FinishY=0);}\r\na:link img { filter:Alpha(Opacity=100,  FinishOpacity=0,  Style=2,  StartX=20,  StartY=40,  FinishX=0,  FinishY=0);}\r\na:hover img { filter:none;}\r\n.blacktext12 { visibility:hidden; display:none; }\r\n</style>\r\n\r\n<div style="width: 88px; height: 31px; position: absolute; top:0px;left:0px; background-color: DEE6EB; border-width:1px;border-style:solid;border-color: 9CB3C3; font-family: Arial Black;">\r\n<a href="http://www.mygen.co.uk" style="color: 9CB3C3; font-size: 18px; position: absolute; left: 10px; top: -5px">MyGen</a>\r\n<a href="http://www.mygen.co.uk" style="color: 9CB3C3; font-size: 8px; position: absolute; left: 1px; top: 18px">Profile Generator</a>\r\n</div>\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n<style type="text/css">\r\n.mygen { Created using MyGen 2.5 - www.mygen.co.uk }\r\n\r\n.mygen { Background Properties }\r\ntable, tr, td { background-color:transparent; border:none; border-width:0;}\r\nbody {\r\n	background-color:FFFFFF;\r\n	background-image:url(''http://www.imgdump.net/images/s2_a4bdf497658b4.jpg'');\r\n	background-attachment: fixed;\r\n	background-position:center center;\r\n	background-repeat:no-repeat;\r\n	border-color:22FF66;\r\n	border-width:4px ;\r\n	border-style: solid;\r\n	scrollbar-face-color:FF22FF;\r\n	scrollbar-highlight-color:FFCC22;\r\n	scrollbar-3dlight-color:2244FF;\r\n	scrollbar-shadow-color:FF2222;\r\n	scrollbar-darkshadow-color:EEFF22;\r\n	scrollbar-arrow-color:000000;\r\n	scrollbar-track-color:22FF22;\r\n	 }\r\n\r\n.mygen { Text Properties }\r\ntable, tr, td, li, p, div { font-family:georgia; color:000000; font-size:12px;  font-style:italic;   } \r\n.btext { font-family:comic sans ms; color:22FF66; font-size:14px; font-weight:bold;    } \r\n.blacktext10 { font-family:comic sans ms; color:EEFF22; font-size:14px; font-weight:bold;    } \r\n.blacktext12 { font-family:tahoma; color:22EEFF; font-size:16px; font-weight:bold;    } \r\n.lightbluetext8 { font-family:courier new; color:FF22FF; font-size:14px;    text-decoration:underline; } \r\n.orangetext15 { font-family:courier new; color:FF22FF; font-size:14px;    text-decoration:underline; } \r\n.redtext { font-family:arial; color:22FF22; font-size:16px; font-weight:bold;    } \r\n.redbtext { font-family:arial; color:FFCC22; font-size:16px; font-weight:bold;    } \r\n.text { font-family:georgia; color:44FF22; font-size:16px;     } \r\n.whitetext12 { font-family:courier new; color:2222FF; font-size:16px; font-weight:bold;    } \r\na:active, a:visited, a:link { font-family:impact; color:22CCFF; font-size:14px; font-weight:bold;    } \r\na:hover { font-family:arial black; color:BBDDFF; font-size:16px;     } \r\na.navbar:active, a.navbar:visited, a.navbar:link { font-family:impact; color:FF22FF; font-size:14px;     } \r\na.navbar:hover { font-family:arial black; color:FF2222; font-size:16px;     } \r\na.redlink:active, a.redlink:visited, a.redlink:link { font-family:impact; color:FFCC22; font-size:14px;     } \r\na.redlink:hover { font-family:tahoma; color:2244EE; font-size:16px;     } \r\n.nametext { font-family:courier new; color:EEFF22; font-size:16px; font-weight:bold; font-style:italic;  text-decoration:underline; } \r\n\r\n.mygen { Miscellaneous Properties }\r\nimg { filter:none;}\r\na:link img { filter:none;}\r\na:hover img { filter:xray;}\r\n</style>\r\n\r\n<div style="width: 88px; height: 31px; position: absolute; top:0px;left:0px; background-color: DEE6EB; border-width:1px;border-style:solid;border-color: 9CB3C3; font-family: Arial Black;">\r\n<a href="http://www.mygen.co.uk" style="color: 9CB3C3; font-size: 18px; position: absolute; left: 10px; top: -5px">MyGen</a>\r\n<a href="http://www.mygen.co.uk" style="color: 9CB3C3; font-size: 8px; position: absolute; left: 1px; top: 18px">Profile Generator</a>\r\n</div>');
INSERT INTO `music_profile` VALUES (24, 895, '', 'Only on here when I''m at school basically.\r\nFind me on myspace\r\n\r\nhttp://www.myspace.com/allasmix', '', '', '', '', '', '');
INSERT INTO `music_profile` VALUES (25, 907, 'We rock you with style', '<style type="text/css">\r\nbody {background-color:; background-image:url(http://www.myspaceclipart.com/bg/hearts.jpg); background-position:Top Center; background-attachment:fixed; background-repeat:repeat-y;}\r\n\r\ntable table table td.text table table div img {visibility:visible;} \r\ntable table table td.text table table div { background-image:none;}\r\ndiv table tbody tr td a, div table tbody tr td input, div table tbody tr td font {visibility: hidden} \r\n\r\ndiv table tbody, div table tbody td {background-color: !important;}\r\n\r\ndiv div table table tr td {background-color:transparent !important;}\r\n\r\ndiv div table {postion: absolute; top: 1px; text-align: center;}\r\n\r\ndiv table tbody tr td a.navbar, div table tbody tr td form input, \r\ndiv table tbody tr td a img, div table tbody tr td div a {visibility: visible !important; display: inline !important;} \r\n\r\ntable tbody td table tbody tr td.text table table, table tbody td table tbody tr td.text table \r\ntable tbody td.text {visibility: visible;} \r\ntable, td {padding: none !important;} \r\nbody {background-color:transparent} \r\nbody table {background-color:transparent} \r\nbody table td {background-color: transparent;} \r\nbody table table {background-color: !imporant} \r\ntable tbody table tbody td, table tbody table tbody table {border: none;} \r\ntable tbody table tbody table table {background-color: !important; border: none; padding: none;} \r\ntable tbody table tbody table table td {background-color:; padding: 2px;} \r\ntable tbody table tbody table table td.text {background-color: transparent !important;} \r\ntable tbody td table tbody tr td.text table td.text table {border: none;} \r\ntable tbody td table tbody tr td.text table td.text {background-color: !important; border: none;} \r\ntable tbody td table tbody tr td.text table table {border: none;} \r\ntable table table table table {background-color: transparent;} \r\nbody {text-align: center !important;} .blacktext12 {visibility: hidden} \r\n\r\n.orangetext15, .lightbluetext8, .whitetext12, .nametext, .btext, .redtext, .redbtext{color:B115A8;font-size:16px;font-weight:bold;text-decoration:none;font-style:normal;font-family:trebuchet ms,Verdana,arial,verdana,sans-serif;}\r\n.redbtext.shadowed { filter: shadow( color=blue, direction=135 ); }\r\nbody, div, p, strong, td, .text, .blacktext10, .blacktext12, a.searchlinkSmall, a.searchlinkSmall:link, a.searchlinkSmall:visited{color:93108B;font-size:8pt;font-weight:normal;text-decoration:none;font-weight:normal;font-style:normal;font-family:trebuchet ms,Verdana,arial,verdana,sans-serif;}\r\na, a:link, a:visited, a.navbar, a.navbar:link, a.navbar:visited, a.man, a.man:link, a.man:visited{color:B115A8;font-size:8pt;font-weight:bold;text-decoration:none;font-style:normal;font-family:trebuchet ms,Verdana,arial,verdana,sans-serif;}\r\na:hover, a:active, a.navbar:hover, a.navbar:active, a.man:hover, a.man:active, a.searchlinkSmall:hover, a.searchlinkSmall:active{color:93108B;font-size:8pt;font-weight:bold;text-decoration:underline ;font-style:normal;font-family:trebuchet ms,Verdana,arial,verdana,sans-serif;} \r\n\r\ntd.text td.text table table td img {width:260px; max-width:260px; width:auto;}\r\ntd.text td.text table table td a img {width:90px; max-width:260px; width:auto;}\r\ntd.text td.text table table td div img {width:80px;}\r\nhtml td.text td.text table table td img {width:260px;}\r\nhtml td.text td.text table table td a img {width:90px;}\r\nhtml td.text td.text table table td div img {width:80px;}\r\n\r\ntable table table td {vertical-align:top ! important;}\r\nspan.blacktext12 {\r\nvisibility:visible !important;\r\nbackground-color:transparent;\r\nbackground-image:url("");\r\nbackground-repeat:no-repeat;\r\nbackground-position:center center;\r\nfont-size:0px; letter-spacing:-0.5px;\r\nwidth:435px; height:75px; display:block !important;\r\nborder:1px;\r\nborder-color:ffffff; }\r\nspan.blacktext12 img {display:none;\r\nborder-width:1;\r\nborder-color:ffffff;\r\n}\r\n.img    {\r\nborder-width:1;\r\nborder-color:ffffff;\r\n}\r\n.contactTable {width:300px !important; height:150px !important; padding:0px !important;background-image:url(http://myspaceclipart.com/bg/heartscon.jpg);background-attachment:scroll; background-position:center center;background-repeat:no-repeat; background-color:transparent;}.contactTable table, table.contactTable td { padding:0px !important;border:0px; background-color:transparent; background-image:none;}.contactTable a img {visibility:hidden; border:0px !important;}.contactTable a {display:block; height:28px; width:115px;}.contactTable .text {font-size:1px !important;}.contactTable .text, .contactTable a, .contactTable img {filter:none !important;}\r\n</style><br /><br />Get your own free cool template at <A href="http://www.myspaceclipart.com/" target="_blank">MySpace Layouts</A><br> \r\n\r\n\r\n\r\n</style>\r\n<div style="position:absolute;top:0;left:0;">\r\n<a href="http://www.blinkyou.com/codes/generator/" target="_blank">\r\n<img src="http://www.blinkyou.com/images/layoutgenerator.gif" border="0">\r\n</a></div>\r\n   <br>LAYOUTS AND MORE AT <a href="http://www.blinkyou.com" target="_blank">BLINKYOU.COM</a><br><br>\r\n\r\nI''m Anya, I had some mp3''s on file, so I decided to take the best ones and make them available for your entertainment', 'ruki vverh- 18 mne yzhe\r\n<object width="425" height="350"><param name="movie" value="http://www.youtube.com/v/I9_VezvXkvg"></param><embed src="http://www.youtube.com/v/I9_VezvXkvg" type="application/x-shockwave-flash" width="425" height="350"></embed></object>\r\nRuki Vverh - On tebya tseluyet\r\n<object width="425" height="350"><param name="movie" value="http://www.youtube.com/v/J3OWxLYCsbI"></param><embed src="http://www.youtube.com/v/J3OWxLYCsbI" type="application/x-shockwave-flash" width="425" height="350"></embed></object>\r\nGlukoza-Yura\r\n<object width="425" height="350"><param name="movie" value="http://www.youtube.com/v/8QF3HtNWT-U"></param><embed src="http://www.youtube.com/v/8QF3HtNWT-U" type="application/x-shockwave-flash" width="425" height="350"></embed></object>\r\nGlukoza-Sneg Idyot\r\n<object width="425" height="350"><param name="movie" value="http://www.youtube.com/v/fnH0onosaL4"></param><embed src="http://www.youtube.com/v/fnH0onosaL4" type="application/x-shockwave-flash" width="425" height="350"></embed></object>\r\nKatya Lel-Doletay\r\n<object width="425" height="350"><param name="movie" value="http://www.youtube.com/v/mRukRq4FOiQ"></param><embed src="http://www.youtube.com/v/mRukRq4FOiQ" type="application/x-shockwave-flash" width="425" height="350"></embed></object>\r\nKatya Lel - Moy Marmeladniy\r\n<object width="425" height="350"><param name="movie" value="http://www.youtube.com/v/FVMeiUjyu6w"></param><embed src="http://www.youtube.com/v/FVMeiUjyu6w" type="application/x-shockwave-flash" width="425" height="350"></embed></object>\r\nKate Ryan - Libertine\r\n<object width="425" height="350"><param name="movie" value="http://www.youtube.com/v/b0NoBeMe8q0"></param><embed src="http://www.youtube.com/v/b0NoBeMe8q0" type="application/x-shockwave-flash" width="425" height="350"></embed></object>\r\nKate Ryan - Je t''adore\r\n<object width="425" height="350"><param name="movie" value="http://www.youtube.com/v/L_cxZqR1pxo"></param><embed src="http://www.youtube.com/v/L_cxZqR1pxo" type="application/x-shockwave-flash" width="425" height="350"></embed></object>\r\nCeline Dion - Because you loved me\r\n<object width="425" height="350"><param name="movie" value="http://www.youtube.com/v/-EVFxGeaHag"></param><embed src="http://www.youtube.com/v/-EVFxGeaHag" type="application/x-shockwave-flash" width="425" height="350"></embed></object>\r\nYou and I - Celine Dion\r\n<object width="425" height="350"><param name="movie" value="http://www.youtube.com/v/R2B8K-qanmw"></param><embed src="http://www.youtube.com/v/R2B8K-qanmw" type="application/x-shockwave-flash" width="425" height="350"></embed></object>\r\ntanya Bulanova-Oseni v glaza\r\n<object width="425" height="350"><param name="movie" value="http://www.youtube.com/v/bbXXDSNQXo4"></param><embed src="http://www.youtube.com/v/bbXXDSNQXo4" type="application/x-shockwave-flash" width="425" height="350"></embed></object>\r\ntanya bulanova-vot takiye dela\r\n<object width="425" height="350"><param name="movie" value="http://www.youtube.com/v/WCD4CgcN7Hk"></param><embed src="http://www.youtube.com/v/WCD4CgcN7Hk" type="application/x-shockwave-flash" width="425" height="350"></embed></object>\r\n', '', '', '', '', '');
INSERT INTO `music_profile` VALUES (26, 947, '', '', '', '', '', 'www.myspace.com/listen2expo', 'Nekstep Records', '');
INSERT INTO `music_profile` VALUES (27, 1036, 'Music Is Life', '', '', '', '', '', '', '');
INSERT INTO `music_profile` VALUES (28, 1045, '', '', '', '', '', '', '', '');
INSERT INTO `music_profile` VALUES (29, 1109, '', '', '', '', '', '', '', '');
INSERT INTO `music_profile` VALUES (30, 1136, '', '<style type="text/css">  table table table td.text div { background-image: url(''http://dl3.glitter-graphics.net/pub/15/15916mr8rcas0em.gif''); background-repeat: no-repeat; } table table table td.text div img { visibility: hidden; } table table table td.text table table div { background-image: none; } table table table td.text table table div img { visibility: visible; } .contactTable { width: 300px !important; height: 150px !important; padding: 0px !important; background-image: url(''http://dl3.glitter-graphics.net/pub/18/18057qzwpd42k73.jpg''); background-attachment: scroll; background-position: center center; background-repeat: no-repeat; background-color: transparent; } .contactTable table, table.contactTable td { padding: 0px !important; border: 0px; background-color: transparent; background-image: none; } .contactTable a img { visibility: hidden; border: 0px !important; } .contactTable a { display: block; height: 28px; width: 115px; } .contactTable .text { font-size: 1px !important; } .contactTable .text, .contactTable a, .contactTable img { filter: none !important; } .glitter { Background Properties } table, tr, td { background-color:transparent; border:none; border-width:0;} body { background-color:AAAAAA; background-image:url(''http://img.photobucket.com/albums/v315/MUHAHAHAHAHA/Stuff%20me%20make/ghfghfgh.jpg''); border-color:FFFFDD; border-width:10px ; border-style: solid; scrollbar-face-color:BBBBBB; scrollbar-highlight-color:DDDDDD; scrollbar-3dlight-color:999999; scrollbar-shadow-color:777777; scrollbar-darkshadow-color:444444; scrollbar-arrow-color:000000; scrollbar-track-color:EEEEEE; } .glitter { Table Properties } table table { border: 0px } table table table table{border:0px} table table table { border-style:solid; border-width:1px; border-color:DDDDDD; background-color:999999; } .glitter { Text Properties } table, tr, td, li, p, div { color:FFFFFF; } .btext { color:FFFFFF; } .blacktext10 { color:FFFFFF; } .blacktext12 { color:FFFFFF; } .lightbluetext8 { color:FFFFFF; } .orangetext15 { color:111111; } .redtext { color:FFFFFF; } .redbtext { color:DDDDDD; } .text { color:000000; } .whitetext12 { color:000000; } a:active, a:visited, a:link { color:FFFFFF; } a:hover { color:555555; } a.navbar:active, a.navbar:visited, a.navbar:link { color:FFFFFF; } a.navbar:hover { color:222222; } a.redlink:active, a.redlink:visited, a.redlink:link { color:FFFFFF; } a.redlink:hover { color:444444; } .nametext { color:000000; } .glitter { Miscellaneous Properties } img { filter:Gray;} a:link img { filter:Gray;} a:hover img { filter:none;} table {direction:rtl;} table table table {direction:ltr;} table table table td {vertical-align:top ! important;} span.blacktext12 { visibility:visible !important; background-color:transparent; background-image:url("http://img.photobucket.com/albums/v315/MUHAHAHAHAHA/Stuff%20me%20make/volietmanygray.jpg"); background-repeat:no-repeat; background-position:center center; font-size:0px; letter-spacing:-0.5px; width:573px; height:759px; display:block !important; } span.blacktext12 img {display:none;} a .text  { font-weight: bold; font-family: Arial, Helvetica, sans-serif; } body, html {visibility:visible !important; display:block !important} body, a:hover{cursor: url(http://www.boomspeed.com/dorischu/cursor/0104.ani);} .Layout (made by: emoannie; url: http://www.skem9.com/~17181) .sk {position:absolute; top:0px; right:0px; z-index:9;}</style><a href="http://www.skem9.com/layouts/index.php?action=users&user=17181" class="sk"><img alt="Skem9.com!" title="Get your own free Myspace Layout!" src="http://c.myspace.com/Groups/00011/26/79/11539762_l.gif" /></a>Layout made by <a href="http://www.skem9.com/~17181">emoannie</a>', '', '', '', '', '', '');
INSERT INTO `music_profile` VALUES (31, 1163, 'JUST A FANPAGE, NOT THE REAL BAND', 'Following the multi-platinum, worldwide success of their major-label debut, Fallen, Evanescence is poised to build upon their respected position in the rock community with their sophomore effort, The Open Door, from Wind-up Records in stores October 3, 2006. \r\n\r\nWith what some call a meteoric rise to the top, Fallen brought the Little Rock, Arkansas band to global success with 14 million records in the hands of fans worldwide, two Top 10 singles, "My Immortal" and "Bring Me To Life," two Grammy', 'Amy Lee       - vocals\r\nRocky Gray    - drums\r\nJohn LeCompt  - guitar\r\nTerry Balsamo - guitar\r\n', '', '', 'www.evanescence.com', 'Wind- Up Records', 'Indie');
INSERT INTO `music_profile` VALUES (32, 1172, '', '', '', '', '', '', '', '');
INSERT INTO `music_profile` VALUES (33, 1173, '', '', '', '', '', '', '', '');
INSERT INTO `music_profile` VALUES (34, 1174, '', '', '', '', '', '', '', '');
INSERT INTO `music_profile` VALUES (35, 1198, '', '', '', '', '', '', '', '');
INSERT INTO `music_profile` VALUES (36, 1252, 'ADEMA is BACK', '<style type="text/css">\r\n.mygen { Created using MyGen 2.5 - www.mygen.co.uk }\r\n\r\n.mygen { Background Properties }\r\ntable, tr, td { background-color:transparent; border:none; border-width:0;}\r\nbody {\r\n	background-color:000000;\r\n	background-attachment:fixed;\r\n	background-repeat:repeat;\r\n	border-color:FFFFFF;\r\n	border-width:12px ;\r\n	border-style: solid;\r\n	scrollbar-face-color:000000;\r\n	scrollbar-highlight-color:000000;\r\n	scrollbar-3dlight-color:FFFFFF;\r\n	scrollbar-shadow-color:FFFFFF;\r\n	scrollbar-darkshadow-color:FFFFFF;\r\n	scrollbar-arrow-color:FFFFFF;\r\n	scrollbar-track-color:000000;\r\n	 }\r\n\r\n.mygen { Table Properties }\r\ntable table { border: 0px }\r\ntable table table table{border:0px}\r\ntable table table {\r\n	border-style:dashed;\r\n	border-width:3px;\r\n	border-color:FFFFFF;\r\n	background-color:transparent;\r\n	   		}\r\n\r\n.mygen { Text Properties }\r\ntable, tr, td, li, p, div { font-family:arial; color:FFFFFF; font-size:12px; font-weight:bold;  text-decoration:line-through;  } \r\n.btext { font-family:arial; color:FFFFFF; font-size:12px; font-weight:bold;  text-decoration:line-through;  } \r\n.blacktext10 { font-family:arial; color:FFFFFF; font-size:10px; font-weight:bold;  text-decoration:line-through;  } \r\n.blacktext12 { font-family:arial; color:FFFFFF; font-size:14px; font-weight:bold;  text-decoration:line-through;  } \r\n.lightbluetext8 { font-family:arial; color:FFFFFF; font-size:9px; font-weight:bold;  text-decoration:line-through;  } \r\n.orangetext15 { font-family:arial; color:FFFFFF; font-size:9px; font-weight:bold;  text-decoration:line-through;  } \r\n.redtext { font-family:arial; color:FFFFFF; font-size:12px; font-weight:bold;  text-decoration:line-through;  } \r\n.redbtext { font-family:arial; color:FFFFFF; font-size:12px; font-weight:bold;  text-decoration:line-through;  } \r\n.text { font-family:arial; color:FFFFFF; font-size:12px; font-weight:bold;  text-decoration:line-through;  } \r\n.whitetext12 { font-family:arial; color:FFFFFF; font-size:9px; font-weight:bold;  text-decoration:line-through;  } \r\na:active, a:visited, a:link { font-family:arial; color:FFFFFF; font-size:12px; font-weight:bold;  text-decoration:line-through;  } \r\na:hover { font-family:arial;  font-size:12px;     } \r\na.navbar:active, a.navbar:visited, a.navbar:link { font-family:arial; color:FFFFFF; font-size:12px; font-weight:bold;  text-decoration:line-through;  } \r\na.navbar:hover { font-family:arial; color:FFFFFF; font-size:12px;     } \r\na.redlink:active, a.redlink:visited, a.redlink:link { font-family:arial; color:FFFFFF; font-size:14px; font-weight:bold;  text-decoration:line-through;  } \r\na.redlink:hover { font-family:arial; color:FFFFFF; font-size:14px;     } \r\n.nametext { font-family:arial; color:FFFFFF; font-size:12px; font-weight:bold;  text-decoration:line-through;  } \r\n\r\n.mygen { Miscellaneous Properties }\r\nbody { cursor:crosshair;}\r\na:hover { cursor:e-resize;}\r\n</style>\r\n\r\n<div style="width: 88px; height: 31px; position: absolute; top:0px;left:0px; background-color: DEE6EB; border-width:1px;border-style:solid;border-color: 9CB3C3; font-family: Arial Black;">\r\n<a href="http://www.mygen.co.uk" style="color: 9CB3C3; font-size: 18px; position: absolute; left: 10px; top: -5px">MyGen</a>\r\n<a href="http://www.mygen.co.uk" style="color: 9CB3C3; font-size: 8px; position: absolute; left: 1px; top: 18px">Profile Generator</a>\r\n</div>', 'tim fluckey ed faris bobby reeves and chris kohls', 'korn metal rock linkin park and others', 'play the songs!', 'dont have one', 'looking for one right now', '');
INSERT INTO `music_profile` VALUES (37, 1253, 'Down With The Clown', 'icp...the story the legend...everything unfolds in this case. its shaggy 2 dope and violent j. both from the great town of \r\n\r\n\r\n<style type="text/css">\r\n.mygen { Created using MyGen 2.5 - www.mygen.co.uk }\r\n\r\n.mygen { Background Properties }\r\ntable, tr, td { background-color:transparent; border:none; border-width:0;}\r\nbody {\r\n	background-color:000000;\r\n	background-image:url(''http://www.fantasyva.com/images/icp.jpg'');\r\n	background-attachment: fixed;\r\n	background-position:center center;\r\n	background-repeat:no-repeat;\r\n	scrollbar-face-color:000000;\r\n	scrollbar-highlight-color:FF2222;\r\n	scrollbar-3dlight-color:000000;\r\n	scrollbar-shadow-color:FF2222;\r\n	scrollbar-darkshadow-color:000000;\r\n	scrollbar-arrow-color:FF2222;\r\n	scrollbar-track-color:000000;\r\n	 }\r\n\r\n.mygen { Text Properties }\r\ntable, tr, td, li, p, div {  color:FF2222;      } \r\n.btext {  color:FF2222;      } \r\n.blacktext10 {  color:FF2222;      } \r\n.blacktext12 {  color:FF2222;      } \r\n.lightbluetext8 {  color:FF2222;      } \r\n.orangetext15 {  color:FF2222;      } \r\n.redtext {  color:FF2222;      } \r\n.redbtext {  color:FF2222;      } \r\n.text {  color:FF2222;      } \r\n.whitetext12 {  color:FF2222;      } \r\na:active, a:visited, a:link {  color:FF2222;      } \r\na:hover {  color:FF2222;      } \r\na.navbar:active, a.navbar:visited, a.navbar:link {  color:FF2222;      } \r\na.navbar:hover {  color:FF2222;      } \r\na.redlink:active, a.redlink:visited, a.redlink:link {  color:FF2222;      } \r\na.redlink:hover {  color:FF4422;      } \r\n.nametext {  color:FF2222;      } \r\n\r\n</style>\r\n\r\n<div style="width: 88px; height: 31px; position: absolute; top:0px;left:0px; background-color: DEE6EB; border-width:1px;border-style:solid;border-color: 9CB3C3; font-family: Arial Black;">\r\n<a href="http://www.mygen.co.uk" style="color: 9CB3C3; font-size: 18px; position: absolute; left: 10px; top: -5px">MyGen</a>\r\n<a href="http://www.mygen.co.uk" style="color: 9CB3C3; font-size: 8px; position: absolute; left: 1px; top: 18px"></a>\r\n</div>\r\n\r\n\r\n\r\n\r\ndetroit michigan. thru all the face paint, the clowns, the music, and the love, so much more lies ahead for these wicked ninjas.\r\n\r\nMCL <333333333333333333333333333', 'Shaggy 2 Dope and Violent J', 'Dark Carnival Fackos', 'Clowns with deadly hatchets swinging mics and loud ass music.', 'www.insaneclownposse.com', 'Psychopathic Records', 'Major');
INSERT INTO `music_profile` VALUES (38, 1254, 'We Dont Die We Get High', 'previously House of Krazees. Twiztid was formed in 1997. They are also a part of Dark Lotus(A Artist in Psychopathic Records made up of Twiztid & ICP)', 'Jamie Madrox(James Spanilo) & Monoxide(Paul Methric)', '', 'Insane Axe Murders,& Twiztid Ass Maw Fackoz', 'Twiztid.com', 'Psychopathic Records\r\nPsychopathicRecords.com', 'Major');
INSERT INTO `music_profile` VALUES (39, 1256, 'LP!!!', '<style type="text/css">\r\n.mygen { Created using MyGen 2.5 - www.mygen.co.uk }\r\n\r\n.mygen { Background Properties }\r\ntable, tr, td { background-color:transparent; border:none; border-width:0;}\r\nbody {\r\n	background-color:000000;\r\n	background-image:url(''http://www.beepworld.de/memberdateien/members54/jrm/enter5.jpg'');\r\n	background-attachment: fixed;\r\n	background-position:center center;\r\n	background-repeat:no-repeat;\r\n	scrollbar-face-color:000000;\r\n	scrollbar-highlight-color:000000;\r\n	scrollbar-3dlight-color:000000;\r\n	scrollbar-shadow-color:000000;\r\n	scrollbar-darkshadow-color:000000;\r\n	scrollbar-arrow-color:AA2222;\r\n	scrollbar-track-color:777777;\r\n	 }\r\n\r\n.mygen { Table Properties }\r\ntable table { border: 0px }\r\ntable table table table{border:0px}\r\ntable table table {\r\n	border-style:dashed;\r\n	border-width:3px;\r\n	border-color:BBBBBB;\r\n	background-color:transparent;\r\n	   		}\r\n\r\ntable table table td {\r\n	background-color:transparent;\r\n	filter:alpha(opacity=80); -moz-opacity:0.80; opacity:0.80; -khtml-opacity:0.80; }\r\ntable table table table td {filter:none;}\r\n\r\n.mygen { Text Properties }\r\ntable, tr, td, li, p, div { font-family:verdana; color:DDDDDD; font-size:12px;     } \r\n.btext {  color:CC2222;      } \r\n.blacktext10 {  color:CC2222;      } \r\n.blacktext12 {  color:CC2222;      } \r\n.lightbluetext8 {  color:CC2222;      } \r\n.orangetext15 {  color:CC2222;      } \r\n.redtext {  color:CC2222;      } \r\n.redbtext {  color:CCCCCC;      } \r\n.text { font-family:comic sans ms; color:DDDDDD;    text-decoration:;  } \r\n.whitetext12 {  color:CCCCCC;      } \r\na:active, a:visited, a:link {  color:CCCCCC;      } \r\na:hover {  color:CCCCCC;      } \r\na.navbar:active, a.navbar:visited, a.navbar:link {  color:CC2222;      } \r\na.navbar:hover {  color:CCCCCC;      } \r\na.redlink:active, a.redlink:visited, a.redlink:link {  color:DDDDDD;      } \r\na.redlink:hover {  color:CCCCCC;      } \r\n.nametext { font-family:impact; color:CC2222; font-size:16px;     } \r\n\r\n.mygen { Miscellaneous Properties }\r\nimg { filter:none;}\r\na:link img { filter:Gray;}\r\na:hover img { filter:none;}\r\nbody { cursor:crosshair;}\r\na:hover { cursor:ne-resize;}\r\ntr {background:transparent;}\r\nbody table div font a, body table div div {visbility:hidden;}\r\nbody table table div font a, body table table div div {visibility:visible;}\r\ntable {direction:rtl;}\r\ntable table table {direction:ltr;}\r\n</style>\r\n\r\n<div style="width: 88px; height: 31px; position: absolute; top:0px;left:0px; background-color: DEE6EB; border-width:1px;border-style:solid;border-color: 9CB3C3; font-family: Arial Black;">\r\n<a href="http://www.mygen.co.uk" style="color: 9CB3C3; font-size: 18px; position: absolute; left: 10px; top: -5px">MyGen</a>\r\n<a href="http://www.mygen.co.uk" style="color: 9CB3C3; font-size: 8px; position: absolute; left: 1px; top: 18px">Profile Generator</a>\r\n</div>', 'Chester Bennington Mike Shinoda Phoenix Hahn Rob', 'Rap Metal Piano Hip Hop Grunge', 'Metal and Rap into one system', 'www.linkinpark.com', '', '');
INSERT INTO `music_profile` VALUES (40, 1257, 'rock on or shut up!!! at least for right now!!!', '<style type="text/css">\r\n.mygen { Created using MyGen 2.5 - www.mygen.co.uk }\r\n\r\n.mygen { Background Properties }\r\ntable, tr, td { background-color:transparent; border:none; border-width:0;}\r\nbody {\r\n	background-color:000000;\r\n	background-image:url(http://palmer.grumpster.com/uploaded_images/rock_hand-782646.jpg);\r\n	background-attachment: fixed;\r\n	background-position:bottom center;\r\n	background-repeat:no-repeat;\r\n	border-color:EEEEEE;\r\n	border-width:5px ;\r\n	border-style: solid;\r\n	scrollbar-face-color:000000;\r\n	scrollbar-highlight-color:AAAAAA;\r\n	scrollbar-3dlight-color:CCCCCC;\r\n	scrollbar-shadow-color:EEEEEE;\r\n	scrollbar-darkshadow-color:FFFFFF;\r\n	scrollbar-arrow-color:DDDDDD;\r\n	scrollbar-track-color:000000;\r\n	 }\r\n\r\n.mygen { Table Properties }\r\ntable table { border: 0px }\r\ntable table table table{border:0px}\r\ntable table table {\r\n	border-style:double;\r\n	border-width:3px;\r\n	border-color:DDDDDD;\r\n	background-color:000000;\r\n	   		}\r\n\r\n.mygen { Text Properties }\r\ntable, tr, td, li, p, div { font-family:tahoma; color:FFFFFF; font-size:10px;     } \r\n.btext { font-family:times new roman; color:000000; font-size:12px;    text-decoration:underline; } \r\n.blacktext10 { font-family:arial; color:000000; font-size:10px; font-weight:bold;    } \r\n.blacktext12 { font-family:times new roman; color:EEEEEE; font-size:16px;    text-decoration:underline; } \r\n.lightbluetext8 { font-family:times new roman; color:DDDDDD; font-size:14px; font-weight:bold;    } \r\n.orangetext15 { font-family:times new roman; color:DDDDDD; font-size:14px; font-weight:bold;    } \r\n.redtext { font-family:arial; color:FFFFFF; font-size:10px; font-weight:bold;    } \r\n.redbtext { font-family:arial; color:CCCCCC; font-size:10px; font-weight:bold;    } \r\n.text { font-family:tahoma; color:EEEEEE; font-size:10px; font-weight:bold;    } \r\n.whitetext12 { font-family:times new roman; color:CCCCCC; font-size:14px;    text-decoration:underline; } \r\na:active, a:visited, a:link { font-family:tahoma; color:FFFFFF; font-size:12px; font-weight:bold;   text-decoration:underline; } \r\na:hover { font-family:tahoma; color:DDDDDD; font-size:10px;     } \r\na.navbar:active, a.navbar:visited, a.navbar:link { font-family:times new roman; color:CCCCCC; font-size:8px; font-weight:bold;   text-decoration:underline; } \r\na.navbar:hover { font-family:times new roman; color:DDDDDD; font-size:10px;     } \r\na.redlink:active, a.redlink:visited, a.redlink:link { font-family:times new roman; color:CCCCCC; font-size:14px; font-weight:bold;    } \r\na.redlink:hover { font-family:times new roman; color:FFFFFF; font-size:12px;     } \r\n.nametext { font-family:times new roman; color:EEEEEE; font-size:16px; font-weight:bold;   text-decoration:underline; } \r\n\r\n.mygen { Miscellaneous Properties }\r\nimg { filter:none;}\r\na:link img { filter:none;}\r\na:hover img { filter:Alpha(Opacity=50);}\r\nbody { cursor:crosshair;}\r\na:hover { cursor:crosshair;}\r\ndiv table tr td font {visibility:hidden;}\r\ndiv table table tr td font {visibility:visible;}\r\ntr {background:transparent;}\r\nbody table div font a, body table div div {visbility:hidden;}\r\nbody table table div font a, body table table div div {visibility:visible;}\r\n</style>\r\n\r\n<div style="width: 88px; height: 31px; forbidden: forbidden; top:0px;left:0px; background-color: DEE6EB; border-width:1px;border-style:solid;border-color: 9CB3C3; font-family: Arial Black;">\r\n<a href="http://www.mygen.co.uk" style="color: 9CB3C3; font-size: 18px; forbidden: forbidden; left: 10px; top: -5px">MyGen</a>\r\n<a href="http://www.mygen.co.uk" style="color: 9CB3C3; font-size: 8px; forbidden: forbidden; left: 1px; top: 18px">Profile Generator</a>\r\n</div>\r\n\r\n\r\n\r\n\r\n\r\nyo this is phil and alex and this is hitz the rock 100.1 and we are an up and com ing radio station starting gig...whutever anyways we are here to provide u with hard rock metal alternative loud speaker system shit...so rock on or get out...this is what rock is all about fuckerz!!!', 'philip and alex', 'rock and metal', 'rock and metal and alternative indie', 'www.myspace.com/rockthe hitz100', 'none', 'none');
INSERT INTO `music_profile` VALUES (41, 1258, 'Koast II Koast In Stores Now!!!', '<style type="text/css">\r\n.mygen { Created using MyGen 2.5 - www.mygen.co.uk }\r\n\r\n.mygen { Background Properties }\r\ntable, tr, td { background-color:transparent; border:none; border-width:0;}\r\nbody {\r\n	background-image:url(http://kottonmouthkings.com/images/downloads/KMKDesktop1024x768.jpg);\r\n	background-attachment:fixed;\r\n	background-repeat:repeat;\r\n	scrollbar-face-color:000000;\r\n	scrollbar-highlight-color:444444;\r\n	scrollbar-3dlight-color:333333;\r\n	scrollbar-shadow-color:000000;\r\n	scrollbar-darkshadow-color:000000;\r\n	scrollbar-arrow-color:444444;\r\n	scrollbar-track-color:000000;\r\n	 }\r\n\r\n.mygen { Table Properties }\r\ntable table { border: 0px }\r\ntable table table table{border:0px}\r\ntable table table {\r\n	border-style:inset;\r\n	border-width:3px;\r\n	border-color:666666;\r\n	background-color:transparent;\r\n	   		}\r\n\r\ntable table table td {\r\n	background-color:000000;\r\n	filter:alpha(opacity=80); -moz-opacity:0.80; opacity:0.80; -khtml-opacity:0.80; }\r\ntable table table table td {filter:none;}\r\n\r\n.mygen { Text Properties }\r\ntable, tr, td, li, p, div {  color:666666;      } \r\n.btext {  color:555555;      } \r\n.blacktext10 {  color:555555;      } \r\n.blacktext12 {  color:555555;      } \r\n.lightbluetext8 {  color:555555;      } \r\n.orangetext15 {  color:444444;      } \r\n.redtext {  color:555555;      } \r\n.redbtext {  color:444444;      } \r\n.text {  color:666666;      } \r\n.whitetext12 {  color:555555;      } \r\na:active, a:visited, a:link {  color:555555;      } \r\na:hover {  color:FFFFFF;      } \r\na.navbar:active, a.navbar:visited, a.navbar:link {  color:444444;      } \r\na.navbar:hover {  color:FFFFFF;      } \r\na.redlink:active, a.redlink:visited, a.redlink:link {  color:444444;      } \r\na.redlink:hover {  color:444444;      } \r\n.nametext {  color:444444;      } \r\n\r\n.mygen { Miscellaneous Properties }\r\nimg { filter:Gray;}\r\na:link img { filter:Gray;}\r\na:hover img { filter:Alpha(Opacity=50);}\r\n.blacktext12 { visibility:hidden; display:none; }\r\ntr {background:transparent;}\r\nbody table div font a, body table div div {visbility:hidden;}\r\nbody table table div font a, body table table div div {visibility:visible;}\r\n</style>\r\n\r\n<div style="width: 88px; height: 31px; position: absolute; top:0px;left:0px; background-color: DEE6EB; border-width:1px;border-style:solid;border-color: 9CB3C3; font-family: Arial Black;">\r\n<a href="http://www.mygen.co.uk" style="color: 9CB3C3; font-size: 18px; position: absolute; left: 10px; top: -5px">MyGen</a>\r\n<a href="http://www.mygen.co.uk" style="color: 9CB3C3; font-size: 8px; position: absolute; left: 1px; top: 18px">Profile Generator</a>\r\n</div>', 'KMK', 'ICP Twiztid rap rock', 'a bunch of weed filled homies', 'www.kottonmouthkings.com', '', '');
INSERT INTO `music_profile` VALUES (42, 1261, 'In The Studio Yall', 'LB!!!\r\n\r\n<style type="text/css">\r\n.mygen { Created using MyGen 2.5 - www.mygen.co.uk }\r\n\r\n.mygen { Background Properties }\r\ntable, tr, td { background-color:transparent; border:none; border-width:0;}\r\nbody {\r\n	background-color:000000;\r\n	background-image:url(''http://i92.photobucket.com/albums/l27/PeekAaBoo206/170077.jpg'');\r\n	background-attachment:fixed;\r\n	background-repeat:repeat;\r\n	border-color:000000;\r\n	border-width:20px ;\r\n	border-style: solid;\r\n	scrollbar-face-color:CC2222;\r\n	scrollbar-highlight-color:000000;\r\n	scrollbar-3dlight-color:888888;\r\n	scrollbar-shadow-color:FFFFFF;\r\n	scrollbar-darkshadow-color:CCCCCC;\r\n	scrollbar-arrow-color:888888;\r\n	scrollbar-track-color:000000;\r\n	 }\r\n\r\n.mygen { Table Properties }\r\ntable table { border: 0px }\r\ntable table table table{border:0px}\r\ntable table table {\r\n	border-style:dashed;\r\n	border-width:2px;\r\n	border-color:000000;\r\n	background-color:999999;\r\n	   		}\r\n\r\n.mygen { Text Properties }\r\ntable, tr, td, li, p, div { font-family:arial; color:CC2222; font-size:10px; font-weight:bold;    } \r\n.btext {  color:000000; font-size:8px;  font-style:italic;   } \r\n.blacktext10 {  color:000000; font-size:8px;    text-decoration:underline; } \r\n.blacktext12 { font-family:arial; color:FF2222; font-size:12px; font-weight:bold; font-style:italic; text-decoration:line-through;  } \r\n.lightbluetext8 { font-family:comic sans ms; color:000000; font-size:8px;    text-decoration:underline; } \r\n.orangetext15 { font-family:comic sans ms; color:882222; font-size:8px;    text-decoration:underline; } \r\n.redtext {  color:000000; font-size:8px; font-weight:bold;   text-decoration:underline; } \r\n.redbtext {  color:882222; font-size:9px; font-weight:bold; font-style:italic; text-decoration:line-through;  } \r\n.text { font-family:arial; color:EE2244; font-size:9px; font-weight:bold; font-style:italic;   } \r\n.whitetext12 {  color:000000; font-size:8px;  font-style:italic;  text-decoration:underline; } \r\na:active, a:visited, a:link {  color:CC4422; font-size:12px;    text-decoration:underline; } \r\na:hover {  color:999999; font-size:10px;     } \r\na.navbar:active, a.navbar:visited, a.navbar:link { font-family:arial; color:111111; font-size:12px;    text-decoration:underline; } \r\na.navbar:hover {  color:CCCCCC; font-size:10px;     } \r\na.redlink:active, a.redlink:visited, a.redlink:link {  color:CC2222; font-size:10px;  font-style:italic;  text-decoration:underline; } \r\na.redlink:hover {  color:CC2222; font-size:9px;     } \r\n.nametext {  color:FF2222; font-size:12px; font-weight:bold; font-style:italic; text-decoration:line-through;  } \r\n\r\n.mygen { Miscellaneous Properties }\r\nimg { filter:Alpha(Opacity=100,  FinishOpacity=0,  Style=2,  StartX=20,  StartY=40,  FinishX=0,  FinishY=0);}\r\na:link img { filter:Alpha(Opacity=100,  FinishOpacity=0,  Style=2,  StartX=20,  StartY=40,  FinishX=0,  FinishY=0);}\r\ndiv table tr td font {visibility:hidden;}\r\ndiv table table tr td font {visibility:visible;}\r\ntr {background:transparent;}\r\nbody table div font a, body table div div {visbility:hidden;}\r\nbody table table div font a, body table table div div {visibility:visible;}\r\n</style>\r\n\r\n<div style="width: 88px; height: 31px; position: absolute; top:0px;left:0px; background-color: DEE6EB; border-width:1px;border-style:solid;border-color: 9CB3C3; font-family: Arial Black;">\r\n<a href="http://www.mygen.co.uk" style="color: 9CB3C3; font-size: 18px; position: absolute; left: 10px; top: -5px">MyGen</a>\r\n<a href="http://www.mygen.co.uk" style="color: 9CB3C3; font-size: 8px; position: absolute; left: 1px; top: 18px">Profile Generator</a>\r\n</div>', 'fred and co.', 'rap metal rock hip hop crunk', 'limp bizkit', '', '', '');
INSERT INTO `music_profile` VALUES (43, 1273, 'Vultures In Stores Now!!!', '<style type="text/css">\r\n.mygen { Created using MyGen 2.5 - www.mygen.co.uk }\r\n\r\n.mygen { Background Properties }\r\ntable, tr, td { background-color:transparent; border:none; border-width:0;}\r\nbody {\r\n	background-image:url(http://www.markforrester.co.za/article-images/vultures%20by%20night.jpg'');\r\n	background-attachment: fixed;\r\n	background-position:center center;\r\n	background-repeat:no-repeat;\r\n	border-color:888888;\r\n	border-width:21px ;\r\n	border-style: solid;\r\n	scrollbar-face-color:555555;\r\n	scrollbar-highlight-color:666666;\r\n	scrollbar-3dlight-color:777777;\r\n	scrollbar-shadow-color:888888;\r\n	scrollbar-darkshadow-color:999999;\r\n	scrollbar-arrow-color:BBBBBB;\r\n	scrollbar-track-color:FFFFFF;\r\n	 }\r\n\r\n.mygen { Table Properties }\r\ntable table { border: 0px }\r\ntable table table table{border:0px}\r\ntable table table {\r\n	border-style:solid;\r\n	border-width:2px;\r\n	border-color:777777;\r\n	   		}\r\n\r\n.mygen { Text Properties }\r\ntable, tr, td, li, p, div { font-family:comic sans ms; color:777777; font-size:9px;     } \r\n.btext { font-family:comic sans ms; color:444444; font-size:9px;     } \r\n.blacktext10 { font-family:comic sans ms; color:888888; font-size:9px;     } \r\n.blacktext12 { font-family:comic sans ms; color:333333; font-size:9px;     } \r\n.lightbluetext8 { font-family:comic sans ms; color:333333; font-size:9px;     } \r\n.orangetext15 { font-family:comic sans ms; color:888888; font-size:9px;     } \r\n.redtext { font-family:comic sans ms; color:000000; font-size:10px;     } \r\n.redbtext { font-family:comic sans ms; color:000000; font-size:9px;     } \r\n.text { font-family:comic sans ms; color:333333; font-size:9px;     } \r\n.whitetext12 { font-family:comic sans ms; color:000000; font-size:9px;     } \r\na:active, a:visited, a:link { font-family:comic sans ms; color:888888; font-size:9px;     } \r\na:hover { font-family:georgia; color:555555; font-size:10px;     } \r\na.navbar:active, a.navbar:visited, a.navbar:link { font-family:comic sans ms; color:888888; font-size:9px;     } \r\na.navbar:hover { font-family:georgia; color:444444; font-size:10px;     } \r\na.redlink:active, a.redlink:visited, a.redlink:link { font-family:comic sans ms; color:888888; font-size:9px; font-weight:bold;    } \r\na.redlink:hover { font-family:georgia; color:444444; font-size:12px;     } \r\n.nametext { font-family:comic sans ms; color:000000; font-size:9px;     } \r\n\r\n.mygen { Miscellaneous Properties }\r\nimg { filter:Alpha(Opacity=50);}\r\na:link img { filter:none;}\r\na:hover img { filter:Alpha(Opacity=50);}\r\nbody { cursor:crosshair;}\r\na:hover { cursor:ne-resize;}\r\n</style>\r\n\r\n<div style="width: 88px; height: 31px; position: absolute; top:0px;left:0px; background-color: DEE6EB; border-width:1px;border-style:solid;border-color: 9CB3C3; font-family: Arial Black;">\r\n<a href="http://www.mygen.co.uk" style="color: 9CB3C3; font-size: 18px; position: absolute; left: 10px; top: -5px">MyGen</a>\r\n<a href="http://www.mygen.co.uk" style="color: 9CB3C3; font-size: 8px; position: absolute; left: 1px; top: 18px">Profile Generator</a>\r\n</div>\r\n<br><CENTER><A HREF="http://profile.myspace.com/index.cfm?fuseaction=user.viewprofile&friendid=51230095"><img src="http://myspace-723.vo.llnwd.net/01323/32/73/1323143723_l.jpg" height=125 width =250"/><BR></A><br>', '', 'rock metal grunge acoustic', 'Smile empty Soul', '', 'beiler bros. records', 'major');
INSERT INTO `music_profile` VALUES (44, 1279, 'Pass Me Something Sharp and Wicked', 'Made up of ICP & Twiztid(in 2000 blaze was added, then left psychopathic & ESHAM replaced him. then blaze came back to they kicked ESHAM off Dark Lotus. then Marz was added(the 6th member now),in 2002 ABK was finally added(to replace Marz).', 'Shaggy 2 Dope, Violent J, Monoxide, & Jamie Madrox', '', 'ICP & Twiztid(cuz it is)', '', 'Psychopathic Records', 'Major');
INSERT INTO `music_profile` VALUES (45, 1280, 'ANIMAL I HAVE BECOME', '<style type="text/css">\r\n.mygen { Created using MyGen 2.5 - www.mygen.co.uk }\r\n\r\n.mygen { Background Properties }\r\ntable, tr, td { background-color:transparent; border:none; border-width:0;}\r\nbody {\r\n	background-color:000000;\r\n	background-image:url(''http://images-eu.amazon.com/images/P/B000FBGBPC.01.LZZZZZZZ.jpg'');\r\n	background-attachment: fixed;\r\n	background-position:center center;\r\n	background-repeat:no-repeat;\r\n	border-color:FF2222;\r\n	border-width:6px ;\r\n	border-style: solid;\r\n	scrollbar-face-color:FFFFFF;\r\n	scrollbar-highlight-color:BBBBBB;\r\n	scrollbar-3dlight-color:888888;\r\n	scrollbar-shadow-color:CCCCCC;\r\n	scrollbar-arrow-color:FF2222;\r\n	scrollbar-track-color:000000;\r\n	 }\r\n\r\n.mygen { Table Properties }\r\ntable table { border: 0px }\r\ntable table table table{border:0px}\r\ntable table table {\r\n	border-style:outset;\r\n	border-width:3px;\r\n	border-color:FF2222;\r\n	background-color:transparent;\r\n	   		}\r\n\r\ntable table table td {\r\n	background-color:FFFFFF;\r\n	filter:alpha(opacity=50); -moz-opacity:0.10; opacity:0.50; -khtml-opacity:0.50; }\r\ntable table table table td {filter:none;}\r\n\r\n.mygen { Text Properties }\r\ntable, tr, td, li, p, div { font-family:comic sans ms; color:FF2222;      } \r\n.btext { font-family:comic sans ms; color:FF2222;      } \r\n.blacktext10 { font-family:comic sans ms; color:000000;      } \r\n.blacktext12 { font-family:comic sans ms; color:FF2222;      } \r\n.lightbluetext8 { font-family:comic sans ms; color:000000;      } \r\n.orangetext15 { font-family:comic sans ms; color:000000;      } \r\n.redtext { font-family:comic sans ms; color:FF2222;      } \r\n.redbtext { font-family:comic sans ms; color:000000;      } \r\n.text { font-family:comic sans ms; color:FF2222;      } \r\n.whitetext12 { font-family:comic sans ms; color:000000;      } \r\na:active, a:visited, a:link { font-family:comic sans ms; color:FF2222;      } \r\na:hover { font-family:comic sans ms; color:666666;      } \r\na.navbar:active, a.navbar:visited, a.navbar:link { font-family:comic sans ms; color:FF2222;      } \r\na.navbar:hover { font-family:comic sans ms; color:666666;      } \r\na.redlink:active, a.redlink:visited, a.redlink:link { font-family:comic sans ms; color:FF2222;      } \r\na.redlink:hover { font-family:comic sans ms; color:555555;      } \r\n.nametext { font-family:comic sans ms; color:FF2222; font-size:16px; font-weight:bold;    } \r\n\r\n.mygen { Miscellaneous Properties }\r\nimg { filter:Alpha(Opacity=100,  FinishOpacity=0,  Style=2,  StartX=20,  StartY=40,  FinishX=0,  FinishY=0);}\r\na:link img { filter:Gray;}\r\na:hover img { filter:Invert;}\r\ntable {direction:rtl;}\r\ntable table table {direction:ltr;}\r\n</style>\r\n\r\n<div style="width: 88px; height: 31px; position: absolute; top:0px;left:0px; background-color: DEE6EB; border-width:1px;border-style:solid;border-color: 9CB3C3; font-family: Arial Black;">\r\n<a href="http://www.mygen.co.uk" style="color: 9CB3C3; font-size: 18px; position: absolute; left: 10px; top: -5px">MyGen</a>\r\n<a href="http://www.mygen.co.uk" style="color: 9CB3C3; font-size: 8px; position: absolute; left: 1px; top: 18px">Profile Generator</a>\r\n</div>\r\n\r\n\r\n\r\n\r\n\r\n<style type="text/css">\r\n.contactTable {width:300px!important; height:150px!important; padding:0px!important; background-image:url("http://resources.mygen.co.uk/myimages/contacttables/379135.jpg"); background-attachment:scroll; background-position:center center; background-repeat:no-repeat; background-color:transparent;}\r\n.contactTable table, table.contactTable td {padding:0px !important; border:0px; background-color:transparent; background-image:none;}\r\n.contactTable a img {visibility:hidden; border:0px!important;}\r\n.contactTable a {display:block; height:28px; width:115px;}\r\n.contactTable .text {font-size:0px!important;}\r\n.contactTable .text, .contactTable a, .contactTable img {filter:none!important;}\r\n</style>', 'brad, adam and the rest of the crew.', 'canada, music, rock, metal, life etc.', '', 'www.threedaysgrace.com', '', '');
INSERT INTO `music_profile` VALUES (46, 1284, 'Point of Origin In Stores!!!', '<style type="text/css">\r\n.mygen { Created using MyGen 2.5 - www.mygen.co.uk }\r\n\r\n.mygen { Background Properties }\r\ntable, tr, td { background-color:transparent; border:none; border-width:0;}\r\nbody {\r\n	background-color:FFFFFF;\r\n	background-image:url(''http://i18.photobucket.com/albums/b113/foezz/yellow.jpg'');\r\n	background-attachment: fixed;\r\n	background-position:center right;\r\n	background-repeat:no-repeat;\r\n	scrollbar-face-color:FFCC22;\r\n	scrollbar-highlight-color:FFEE22;\r\n	scrollbar-3dlight-color:FFFFFF;\r\n	scrollbar-shadow-color:FFFFFF;\r\n	scrollbar-darkshadow-color:FFFFFF;\r\n	scrollbar-arrow-color:FFFF22;\r\n	scrollbar-track-color:EEAA22;\r\n	 }\r\n\r\n.mygen { Table Properties }\r\ntable table { border: 0px }\r\ntable table table table{border:0px}\r\ntable table table {\r\n	border-style:ridge;\r\n	border-width:3px;\r\n	border-color:EEAA22;\r\n	background-color:transparent;\r\n	   		}\r\n\r\ntable table table td {\r\n	background-color:FFCC22;\r\n	filter:alpha(opacity=80); -moz-opacity:0.80; opacity:0.80; -khtml-opacity:0.80; }\r\ntable table table table td {filter:none;}\r\n\r\n.mygen { Text Properties }\r\ntable, tr, td, li, p, div { font-family:papyrus; color:FFFF22; font-size:12px; font-weight:bold;    } \r\n.btext { font-family:papyrus; color:FFAA22; font-size:12px; font-weight:bold;    } \r\n.blacktext10 { font-family:papyrus; color:FFAA22; font-size:12px; font-weight:bold;    } \r\n.blacktext12 { font-family:papyrus; color:FFAA22; font-size:12px; font-weight:bold;    } \r\n.lightbluetext8 { font-family:papyrus; color:FFAA22; font-size:12px; font-weight:bold;    } \r\n.orangetext15 { font-family:papyrus; color:FFAA22; font-size:12px; font-weight:bold;    } \r\n.redtext { font-family:papyrus; color:FFAA22; font-size:12px; font-weight:bold;    } \r\n.redbtext { font-family:papyrus; color:FFAA22; font-size:12px; font-weight:bold;    } \r\n.text { font-family:papyrus; color:FFAA22; font-size:12px; font-weight:bold;    } \r\n.whitetext12 { font-family:papyrus; color:FF8822; font-size:12px; font-weight:bold;    } \r\na:active, a:visited, a:link { font-family:papyrus; color:EE8822; font-size:12px;     } \r\na:hover { font-family:papyrus; color:FF6622; font-size:12px;     } \r\na.navbar:active, a.navbar:visited, a.navbar:link { font-family:papyrus; color:FFFF22; font-size:12px;     } \r\na.navbar:hover { font-family:papyrus; color:FF6622; font-size:12px;     } \r\na.redlink:active, a.redlink:visited, a.redlink:link { font-family:papyrus; color:EE8822; font-size:12px;     } \r\na.redlink:hover { font-family:papyrus; color:FF6622; font-size:12px;     } \r\n.nametext { font-family:papyrus; color:FF8822; font-size:12px; font-weight:bold;    } \r\n\r\n.mygen { Miscellaneous Properties }\r\nimg { filter:none;}\r\na:link img { filter:none;}\r\na:hover img { filter:none;}\r\nbody { cursor:crosshair;}\r\na:hover { cursor:crosshair;}\r\n</style>\r\n\r\n<div style="width: 88px; height: 31px; position: absolute; top:0px;left:0px; background-color: DEE6EB; border-width:1px;border-style:solid;border-color: 9CB3C3; font-family: Arial Black;">\r\n<a href="http://www.mygen.co.uk" style="color: 9CB3C3; font-size: 18px; position: absolute; left: 10px; top: -5px">MyGen</a>\r\n<a href="http://www.mygen.co.uk" style="color: 9CB3C3; font-size: 8px; position: absolute; left: 1px; top: 18px">Profile Generator</a>\r\n</div>', '', 'Music family and friends.', 'allele', 'www.allele.com', '', '');
INSERT INTO `music_profile` VALUES (47, 1296, 'CHAIN SMOKERZ UNITED', 'A Highland Springs Local Underground Band', 'SK, FSK, AK, & DC', 'ICP, Twiztid, kmk, korn, dope', 'Wikid underground shit', 'www.soundclick.com/Chainsmokerzunited', 'palooza', 'self-owned');
INSERT INTO `music_profile` VALUES (48, 1336, '', '', '', '', '', '', '', '');
INSERT INTO `music_profile` VALUES (49, 1337, '', '', '', '', '', '', '', '');
INSERT INTO `music_profile` VALUES (50, 1357, '', '', '', '', '', '', '', '');
INSERT INTO `music_profile` VALUES (51, 1360, '', '', '', '', '', '', '', '');
INSERT INTO `music_profile` VALUES (52, 1361, '', '', '', '', '', '', '', '');
INSERT INTO `music_profile` VALUES (53, 1362, '', '', '', '', '', '', '', '');
INSERT INTO `music_profile` VALUES (54, 1378, '', '', '', '', '', '', '', '');
INSERT INTO `music_profile` VALUES (55, 1381, '', '', '', '', '', '', '', '');
INSERT INTO `music_profile` VALUES (56, 1382, '', '', '', '', '', '', '', '');
INSERT INTO `music_profile` VALUES (57, 1383, '', '', '', '', '', '', '', '');

-- --------------------------------------------------------

-- 
-- Table structure for table `music_shows`
-- 

CREATE TABLE `music_shows` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `member_id` int(10) NOT NULL default '0',
  `show_month` varchar(10) NOT NULL default '',
  `show_day` varchar(10) NOT NULL default '',
  `show_year` varchar(15) NOT NULL default '',
  `show_hour` varchar(10) NOT NULL default '',
  `show_min` varchar(10) NOT NULL default '',
  `show_marker` varchar(10) NOT NULL default '',
  `venue` varchar(255) NOT NULL default '',
  `cost` varchar(30) NOT NULL default '',
  `address` varchar(255) NOT NULL default '',
  `city` varchar(50) NOT NULL default '',
  `zip_code` varchar(10) NOT NULL default '',
  `state` varchar(50) NOT NULL default '',
  `region` varchar(10) NOT NULL default '',
  `country` varchar(50) NOT NULL default '',
  `description` blob NOT NULL,
  PRIMARY KEY  (`id`)
) TYPE=MyISAM  AUTO_INCREMENT=7 ;

-- 
-- Dumping data for table `music_shows`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `music_songs`
-- 

CREATE TABLE `music_songs` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `owner_id` int(10) unsigned default NULL,
  `member_id` int(10) NOT NULL default '0',
  `song_name` varchar(255) NOT NULL default '',
  `song_file` varchar(255) NOT NULL default '',
  `lyrics` blob NOT NULL,
  `date` int(10) unsigned default NULL,
  `def` tinyint(3) unsigned default '0',
  PRIMARY KEY  (`id`)
) TYPE=MyISAM  AUTO_INCREMENT=553 ;

-- 
-- Dumping data for table `music_songs`
-- 

INSERT INTO `music_songs` VALUES (11, 172, 172, 'Biggy  U No Body', 'songs/172Nyou_re_nobody_(til_somebody_kills_you).mp3', '', NULL, 0);
INSERT INTO `music_songs` VALUES (12, 172, 172, 'Tiesto Love Comes Again', 'songs/17202-love_comes_again-tiesto.mp3', '', NULL, 0);
INSERT INTO `music_songs` VALUES (13, 172, 172, 'Armin Empty Sate', 'songs/17202-empty_state_armin.mp3', '', NULL, 0);
INSERT INTO `music_songs` VALUES (14, 172, 172, 'MADONA LIKE IT OR NOT', 'songs/172Madona05.12_LIKEIT_ORNOT.mp3', '', NULL, 0);
INSERT INTO `music_songs` VALUES (15, 172, 172, 'Vinyl Shakers bangkok', 'songs/172vinylshakerz_one_night_in_bangkok.mp3', '', NULL, 0);
INSERT INTO `music_songs` VALUES (16, 172, 172, 'Modern Talking Ur My Heart', 'songs/17201_-_you_re_my_heart__your_re_my_soul_192_lame_cbr_ex.mp3', '', NULL, 0);
INSERT INTO `music_songs` VALUES (17, 172, 172, 'Biggy Notorious Thugs', 'songs/172Nnotorious_thugs.mp3', '', NULL, 0);
INSERT INTO `music_songs` VALUES (18, 172, 172, 'Tiesto Traffic', 'songs/17203-traffic_tiesto.mp3', '', NULL, 0);
INSERT INTO `music_songs` VALUES (19, 172, 172, 'Tiesto Walking on Clouds', 'songs/17207-walking_on_clouds_tiesto.mp3', '', NULL, 0);
INSERT INTO `music_songs` VALUES (20, 172, 172, 'Armin Buren Shivers', 'songs/17203-shivers-armin.mp3', '', NULL, 0);
INSERT INTO `music_songs` VALUES (41, 85, 85, '', 'songs/85Gulyal_po_stolitse.mp3', '', 1143695036, 0);
INSERT INTO `music_songs` VALUES (22, 342, 342, 'Brigada', 'songs/356Brigada.mp3', '', 0, 1);
INSERT INTO `music_songs` VALUES (23, 172, 342, 'Biggy Notorious Thugs', 'songs/172Nnotorious_thugs.mp3', '', 0, 0);
INSERT INTO `music_songs` VALUES (24, 172, 342, 'Tiesto Love Comes Again', 'songs/17202-love_comes_again-tiesto.mp3', '', 0, 0);
INSERT INTO `music_songs` VALUES (25, 342, 342, 'Crazy in Love', 'songs/34217 - Crazy In Love.mp3', '', 1143475665, 0);
INSERT INTO `music_songs` VALUES (26, 342, 342, 'Godfather', 'songs/342GodfatherA.mp3', '', 1143478738, 0);
INSERT INTO `music_songs` VALUES (27, 172, 172, 'Saldat  5nizza', 'songs/172Soldat.mp3', '', 1143514910, 0);
INSERT INTO `music_songs` VALUES (37, 91, 91, 'Anticipation', 'songs/91Anticipation.mp3', '', 1143555604, 1);
INSERT INTO `music_songs` VALUES (30, 85, 85, 'test', 'songs/85Esli Drug - ne drug.mp3', '', 1143516922, 0);
INSERT INTO `music_songs` VALUES (31, 85, 85, 'Drug', 'songs/85vv33_01.mp3', '', 1143517983, 0);
INSERT INTO `music_songs` VALUES (50, 588, 588, 'Nightmares', 'songs/588nightmare.mp3', '', 1144118548, 0);
INSERT INTO `music_songs` VALUES (49, 588, 588, 'Dance', 'songs/588dance.mp3', '', 1144118479, 0);
INSERT INTO `music_songs` VALUES (53, 91, 85, 'Anticipation', 'songs/91Anticipation.mp3', '', 1143555604, 0);
INSERT INTO `music_songs` VALUES (52, 106, 106, '', 'songs/10623_05.mp3', '', 1144278383, 1);
INSERT INTO `music_songs` VALUES (54, 172, 618, 'Biggy Notorious Thugs', 'songs/172Nnotorious_thugs.mp3', '', 0, 0);
INSERT INTO `music_songs` VALUES (39, 85, 85, 'Pravda', 'songs/85protiwostojanie_-prawda_kotoruju_wse_bojatsja_slyshatx-2.mp3', '', 1143680633, 0);
INSERT INTO `music_songs` VALUES (40, 85, 85, '', 'songs/85Kto_konchil_rano_zhizn.mp3', '', 1143681211, 0);
INSERT INTO `music_songs` VALUES (55, 206, 206, '', 'songs/206', '', 1144412814, 0);
INSERT INTO `music_songs` VALUES (44, 85, 85, 'saldat', 'songs/85Soldat.mp3', '', 1143956478, 0);
INSERT INTO `music_songs` VALUES (45, 85, 85, '', 'songs/85street_ban_sam-bej_perwym-2.mp3', '', 1143957290, 0);
INSERT INTO `music_songs` VALUES (46, 85, 342, '', 'songs/85street_ban_sam-bej_perwym-2.mp3', '', 1143957290, 0);
INSERT INTO `music_songs` VALUES (47, 91, 342, 'Anticipation', 'songs/91Anticipation.mp3', '', 1143555604, 0);
INSERT INTO `music_songs` VALUES (56, 630, 630, 'BEEP', 'songs/630Beep.mp3', '', 1144433594, 1);
INSERT INTO `music_songs` VALUES (57, 206, 206, '', 'songs/206Limp Bizkit - Underneath The Gun.mp3', '', 1144503461, 0);
INSERT INTO `music_songs` VALUES (58, 630, 630, 'Drowning', 'songs/630_cut_Cleveland_Lounge___Drowning__AK1200_remix_.mp3', '', 1144508962, 0);
INSERT INTO `music_songs` VALUES (59, 206, 206, '', 'songs/206Limp Bizkit - Nookie.mp3', '', 1144526868, 0);
INSERT INTO `music_songs` VALUES (60, 206, 206, '', 'songs/206mnogotochiye.mp3', '', 1144528631, 0);
INSERT INTO `music_songs` VALUES (99, 848, 848, 'BuSt A nUt', 'songs/848Biggie - The Notorious B_I_G_-Duets_ The Final Chapter-04 - Bust A Nut (Ft_ Webbie and Too Short) (ShadyBlock_com).mp3', '', 1151550172, 1);
INSERT INTO `music_songs` VALUES (61, 206, 85, '', 'songs/206mnogotochiye.mp3', '', 1144528631, 0);
INSERT INTO `music_songs` VALUES (62, 662, 662, '', 'songs/66207 _____ ____ ____.wma', '', 1144624806, 0);
INSERT INTO `music_songs` VALUES (73, 172, 172, 'AnticipationaffaProfileSong', 'songs/172Anticipation.mp3', '', 1145378040, 0);
INSERT INTO `music_songs` VALUES (65, 492, 492, 'Lambada', 'songs/492Track06.cda', '', 1144778277, 1);
INSERT INTO `music_songs` VALUES (66, 206, 177, '', 'songs/206Limp Bizkit - Nookie.mp3', '', 1144526868, 0);
INSERT INTO `music_songs` VALUES (67, 700, 700, 'Bumer 2', 'songs/700bumer2.mp3', '', 1144878918, 1);
INSERT INTO `music_songs` VALUES (68, 700, 700, 'Svaboda', 'songs/70001-', '', 1144879099, 0);
INSERT INTO `music_songs` VALUES (69, 85, 85, 'druzyam', 'songs/85dw_rep-bratstwo_swobody_-_nashim_druzxjam-2.mp3', '', 1144983833, 0);
INSERT INTO `music_songs` VALUES (70, 712, 712, 'DJ Skydreamer  Russian Gir', 'songs/71210DJ Skydreamer - Russian Girl.mp3', '', 1145123041, 1);
INSERT INTO `music_songs` VALUES (71, 712, 712, 'Cyanescens  Ousk', 'songs/71211Cyanescens - Ousk.mp3', '', 1145123413, 0);
INSERT INTO `music_songs` VALUES (72, 172, 395, 'Armin Empty Sate', 'songs/17202-empty_state_armin.mp3', '', 0, 0);
INSERT INTO `music_songs` VALUES (74, 172, 172, 'ATB RussianSTYLE', 'songs/172ATBTsvetko.mp3', '', 1145378797, 0);
INSERT INTO `music_songs` VALUES (75, 206, 206, '', 'songs/206LL Cool J - Preserve The Sexy ft Teairra Mari.mp3', '', 1145617644, 0);
INSERT INTO `music_songs` VALUES (76, 758, 758, 'Nightmares', 'songs/758nightmare.mp3', '', 1145638456, 1);
INSERT INTO `music_songs` VALUES (77, 758, 758, 'Dance', 'songs/758dance.mp3', '', 1145638513, 0);
INSERT INTO `music_songs` VALUES (84, 206, 206, '', 'songs/206Batishta Riva - ya_hochu_bit_s_toboy.mp3', '', 1146797060, 0);
INSERT INTO `music_songs` VALUES (78, 206, 206, '', 'songs/206yorap-young_buck_-_shorty_wanna_ride-2.mp3', '', 1145929520, 0);
INSERT INTO `music_songs` VALUES (83, 738, 738, 'Away From Me Evanescence', 'songs/738Away From Me.mp3', '', 1146405716, 0);
INSERT INTO `music_songs` VALUES (82, 738, 738, 'You Evanescence', 'songs/738You.mp3', '', 1146405476, 0);
INSERT INTO `music_songs` VALUES (85, 206, 206, '', 'songs/2062Pac - Thugz Mansion.mp3', '', 1147227926, 0);
INSERT INTO `music_songs` VALUES (89, 812, 812, 'Anubi  Kai Pilnaties Akis', 'songs/81204 kai pilnaties akis uzmerks mirtis ii.mp3', '', 1147986472, 1);
INSERT INTO `music_songs` VALUES (86, 795, 795, '', 'songs/795scooter - maria (i like it loud).mp3', '', 1147390133, 1);
INSERT INTO `music_songs` VALUES (98, 172, 848, 'Tiesto Traffic', 'songs/17203-traffic_tiesto.mp3', '', 0, 0);
INSERT INTO `music_songs` VALUES (94, 795, 795, '', 'songs/795dance trance - kevin and perry go large - Sparkles.mp3', '', 1148704356, 0);
INSERT INTO `music_songs` VALUES (91, 206, 206, '', 'songs/206&#1084;&#1072;&#1083;&#1100;&#1095;&#1080;&#1096;&#1085;&#1080;&#1082; - medlyak.mp3', '', 1148007020, 0);
INSERT INTO `music_songs` VALUES (93, 206, 206, '', 'songs/206sveta-doroga v aeroport.mp3', '', 1148350910, 0);
INSERT INTO `music_songs` VALUES (95, 172, 172, 'livin legend', 'songs/172LivinLegend.mp3', '', 1150045658, 0);
INSERT INTO `music_songs` VALUES (96, 172, 172, 'i belong 2 u  lenny kreavitz', 'songs/172LKravits.Belong2U.mp3', '', 1150045872, 0);
INSERT INTO `music_songs` VALUES (97, 172, 172, 'angel eyes', 'songs/17222-mario_lopez_-_angel_eyes.mp3', '', 1150045921, 0);
INSERT INTO `music_songs` VALUES (100, 856, 856, 'Ne Svyatay', 'songs/856Ne Svyatay.mp3', '', 1152301946, 1);
INSERT INTO `music_songs` VALUES (101, 870, 870, 'Ukrainian techno', 'songs/870Ukrainian Techno - Track 08.mp3', '', 1152315097, 1);
INSERT INTO `music_songs` VALUES (292, 860, 872, 'svoboda', 'songs/860svoboda.mp3', '', 1152370814, 1);
INSERT INTO `music_songs` VALUES (293, 1036, 1036, 'Kak Tvoi Dela', 'songs/1036Kak Tvoi Dela..mov', '', 1153343827, 1);
INSERT INTO `music_songs` VALUES (104, 172, 877, 'angel eyes', 'songs/17222-mario_lopez_-_angel_eyes.mp3', '', 1150045921, 0);
INSERT INTO `music_songs` VALUES (552, 856, 1352, 'Daje Yesli ti uydosh', 'songs/856Daje Yesli ti uydosh.mp3', '', 1152327137, 1);
INSERT INTO `music_songs` VALUES (106, 856, 856, 'Sexual Revolution', 'songs/856Sexual Revolution.mp3', '', 1152326542, 0);
INSERT INTO `music_songs` VALUES (107, 856, 856, 'Tanzuy sommnoy', 'songs/856Tanzuy sommnoy.mp3', '', 1152326952, 0);
INSERT INTO `music_songs` VALUES (108, 856, 856, 'Daje Yesli ti uydosh', 'songs/856Daje Yesli ti uydosh.mp3', '', 1152327137, 0);
INSERT INTO `music_songs` VALUES (109, 856, 856, 'Veter C Moory dul', 'songs/856Veter C Moory dul.mp3', '', 1152327246, 0);
INSERT INTO `music_songs` VALUES (272, 856, 856, 'BaBy GiRl', 'songs/856BaBy GiRl.mp3', '', 1153098872, 0);
INSERT INTO `music_songs` VALUES (111, 856, 860, 'Ne Svyatay', 'songs/856Ne Svyatay.mp3', '', 1152301946, 0);
INSERT INTO `music_songs` VALUES (115, 856, 888, 'Daje Yesli ti uydosh', 'songs/856Daje Yesli ti uydosh.mp3', '', 1152327137, 0);
INSERT INTO `music_songs` VALUES (112, 856, 885, 'Ne Svyatay', 'songs/856Ne Svyatay.mp3', '', 1152301946, 0);
INSERT INTO `music_songs` VALUES (126, 895, 895, 'Don''t worry be happy', 'songs/895Track01.mp3', '', 1152361067, 1);
INSERT INTO `music_songs` VALUES (114, 856, 860, 'Tanzuy sommnoy', 'songs/856Tanzuy sommnoy.mp3', '', 1152326952, 0);
INSERT INTO `music_songs` VALUES (117, 860, 886, 'Ya Nemagu Bez Tebia', 'songs/860ya ne mogu bez tebya.mpga', '', 1152336202, 0);
INSERT INTO `music_songs` VALUES (116, 860, 860, 'Ya Nemagu Bez Tebia', 'songs/860ya ne mogu bez tebya.mpga', '', 1152336202, 0);
INSERT INTO `music_songs` VALUES (288, 1020, 1020, 'Pomeha Sprawa', 'songs/1020Pomeha_sprawa_-_Simnaja_resina_(DJ_Jeff)_www.RuCenter.de.mp3', '', 1153194917, 0);
INSERT INTO `music_songs` VALUES (245, 885, 885, 'free me', 'songs/885Emma Bunton - Free Me (Dr.Octavo Seduction Club Mix).mp3', '', 1152866640, 0);
INSERT INTO `music_songs` VALUES (140, 885, 885, 'techno mix', 'songs/885Russian - Techno - DJ Kosmonova - Take Me Away (Club Mix).mp3', '', 1152412600, 0);
INSERT INTO `music_songs` VALUES (246, 885, 885, 'dreams', 'songs/885Tatu - Krik [Fly Dream Remix].mp3', '', 1152868096, 0);
INSERT INTO `music_songs` VALUES (127, 895, 895, 'Borka Babnik', 'songs/895Track03.mp3', '', 1152361202, 0);
INSERT INTO `music_songs` VALUES (130, 860, 860, 'svoboda', 'songs/860svoboda.mp3', '', 1152370814, 0);
INSERT INTO `music_songs` VALUES (129, 172, 896, 'ATB RussianSTYLE', 'songs/172ATBTsvetko.mp3', '', 1145378797, 0);
INSERT INTO `music_songs` VALUES (219, 856, 969, 'Ne Svyatay', 'songs/856Ne Svyatay.mp3', '', 1152301946, 1);
INSERT INTO `music_songs` VALUES (134, 894, 894, 'Veter C Morya Dul', 'songs/894Veter C Morya Dul.mp3', '', 1152371796, 0);
INSERT INTO `music_songs` VALUES (135, 896, 896, 'Opera', 'songs/896Maria Callas - Carmen (opera trance club mix).mp3', '', 1152387645, 0);
INSERT INTO `music_songs` VALUES (137, 894, 894, 'Slatkaya Devochka', 'songs/894Slatkaya Devochka.mp3', '', 1152408301, 0);
INSERT INTO `music_songs` VALUES (138, 894, 894, 'Na Volne', 'songs/894Na Volne.mp3', '', 1152410827, 1);
INSERT INTO `music_songs` VALUES (139, 886, 886, 'Davai Davai', 'songs/886dj aligator-DAVAYDAVAY.mp3', '', 1152411003, 1);
INSERT INTO `music_songs` VALUES (141, 907, 907, 'One hand in my pocket', 'songs/907Alanis Morrisette - One Hand In My Pocket.mp3', '', 1152462828, 1);
INSERT INTO `music_songs` VALUES (142, 907, 907, 'Arabic belly dance', 'songs/907Shakira - Arabic Belly Dance Music.mp3', '', 1152462894, 0);
INSERT INTO `music_songs` VALUES (143, 907, 907, 'its all for U', 'songs/907Janet Jackson - ALL 4 U (1).mp3', '', 1152463024, 0);
INSERT INTO `music_songs` VALUES (144, 907, 907, 'The Lucky OneAllison Krauss', 'songs/907Krauss, Alison-The Lucky One.mp3', '', 1152463156, 0);
INSERT INTO `music_songs` VALUES (145, 907, 907, 'Linger Cranberries', 'songs/907Cranberries - Linger.mp3', '', 1152463229, 0);
INSERT INTO `music_songs` VALUES (146, 907, 907, 'You and Me', 'songs/907It''s You and me.mp3', '', 1152463289, 0);
INSERT INTO `music_songs` VALUES (147, 907, 907, 'One Word  Kelly Osbourne', 'songs/907Kelly Osbourne - One Word.mp3', '', 1152463397, 0);
INSERT INTO `music_songs` VALUES (148, 907, 907, 'I''m a bitch i''m a lover', 'songs/907Alaniss Morrisete - Im a Bitch Im a Lover.mp3', '', 1152463542, 0);
INSERT INTO `music_songs` VALUES (149, 907, 907, 'Mein Heir Liza Minelli', 'songs/907Liza Minelli - Mein Heir.mp3', '', 1152463638, 0);
INSERT INTO `music_songs` VALUES (150, 907, 907, 'kiska lubov', 'songs/907ruki vverh - kiska lubov.mp3', '', 1152463820, 0);
INSERT INTO `music_songs` VALUES (151, 907, 907, 'I''m the only one', 'songs/907Melissa Etheridge - I''m The Only One.mp3', '', 1152463974, 0);
INSERT INTO `music_songs` VALUES (152, 907, 907, 'Telescope eyes', 'songs/907Eisley - Telescope Eyes.mp3', '', 1152464061, 0);
INSERT INTO `music_songs` VALUES (153, 907, 907, 'probably wouldnt be this way', 'songs/907Leanne Rimes - Probably wouldnt be this way.mp3', '', 1152464167, 0);
INSERT INTO `music_songs` VALUES (154, 907, 907, 'murder on the dance floor', 'songs/907Sophie Ellis-Baxter - Murder on the dance floor.mp3', '', 1152464299, 0);
INSERT INTO `music_songs` VALUES (157, 907, 896, 'kiska lubov', 'songs/907ruki vverh - kiska lubov.mp3', '', 1152463820, 1);
INSERT INTO `music_songs` VALUES (158, 903, 903, 'Kapali Slezi', 'songs/903S . Schukov - Kapali slezi.mp3', '', 1152482650, 0);
INSERT INTO `music_songs` VALUES (159, 206, 206, '', 'songs/206Fort_Minor-Remember_The_Name.mp3', '', 1152495934, 0);
INSERT INTO `music_songs` VALUES (160, 903, 903, 'Burned with Desire', 'songs/903BURNED.mp3', '', 1152498061, 1);
INSERT INTO `music_songs` VALUES (161, 903, 903, 'omut', 'songs/903Sergej Zhukov - Omut.mp3', '', 1152498888, 0);
INSERT INTO `music_songs` VALUES (162, 903, 903, 'Dj Prada G   summer solstice', 'songs/903DJ Prada G - Ntrance - Part 1 - 03 Summer Solstice.mp3', '', 1152499634, 0);
INSERT INTO `music_songs` VALUES (163, 903, 903, 'Dj Prada G   Do you know', 'songs/903DJ Prada G - Ntrance - Part 1 - 02 Do You know.mp3', '', 1152500056, 0);
INSERT INTO `music_songs` VALUES (164, 856, 890, 'Ne Svyatay', 'songs/856Ne Svyatay.mp3', '', 1152301946, 1);
INSERT INTO `music_songs` VALUES (165, 860, 916, 'svoboda', 'songs/860svoboda.mp3', '', 1152370814, 1);
INSERT INTO `music_songs` VALUES (166, 856, 916, 'Ne Svyatay', 'songs/856Ne Svyatay.mp3', '', 1152301946, 0);
INSERT INTO `music_songs` VALUES (228, 942, 942, 'track 14 in mp3', 'songs/942Track 14 in mp3.mp3', '', 1152739126, 0);
INSERT INTO `music_songs` VALUES (174, 923, 923, 'Letala Da Pela', 'songs/923Letala da .mp3', '', 1152594218, 0);
INSERT INTO `music_songs` VALUES (169, 857, 857, '', 'songs/857russianplaylist.wpl', '', 1152557532, 0);
INSERT INTO `music_songs` VALUES (170, 758, 758, 'Child''s Play', 'songs/758Scotty&Sky.mp3', '', 1152557751, 0);
INSERT INTO `music_songs` VALUES (171, 856, 926, 'Veter C Moory dul', 'songs/856Veter C Moory dul.mp3', '', 1152327246, 1);
INSERT INTO `music_songs` VALUES (172, 856, 857, 'Daje Yesli ti uydosh', 'songs/856Daje Yesli ti uydosh.mp3', '', 1152327137, 0);
INSERT INTO `music_songs` VALUES (173, 856, 918, 'Ne Svyatay', 'songs/856Ne Svyatay.mp3', '', 1152301946, 1);
INSERT INTO `music_songs` VALUES (300, 885, 885, 'poputchia', 'songs/885Slava - Poputchica.mp3', '', 1153457270, 0);
INSERT INTO `music_songs` VALUES (176, 856, 936, 'Ne Svyatay', 'songs/856Ne Svyatay.mp3', '', 1152301946, 1);
INSERT INTO `music_songs` VALUES (177, 856, 936, 'Ashes to Ashes', 'songs/856Ashes to Ashes.mp3', '', 1152327708, 0);
INSERT INTO `music_songs` VALUES (178, 923, 923, 'Dozhdis Menya', 'songs/923spiony - dozhdis menya.mp3', '', 1152597359, 1);
INSERT INTO `music_songs` VALUES (179, 923, 923, 'Nagou Na Nemisheh', 'songs/923andy - nagou na nemisheh.mp3', '', 1152597693, 0);
INSERT INTO `music_songs` VALUES (301, 885, 885, 'brilanti', 'songs/885Via Gra- Brilianti.mp3', '', 1153458097, 0);
INSERT INTO `music_songs` VALUES (180, 894, 938, 'Na Volne', 'songs/894Na Volne.mp3', '', 1152410827, 0);
INSERT INTO `music_songs` VALUES (181, 856, 938, 'Sexual Revolution', 'songs/856Sexual Revolution.mp3', '', 1152326542, 0);
INSERT INTO `music_songs` VALUES (182, 930, 930, 'Welcome to my life', 'songs/930Welcome To My Life.mp3', '', 1152599962, 0);
INSERT INTO `music_songs` VALUES (251, 856, 989, 'Tanzuy sommnoy', 'songs/856Tanzuy sommnoy.mp3', '', 1152326952, 0);
INSERT INTO `music_songs` VALUES (184, 945, 945, 'Kak Tvoi Dela', 'songs/945Kak Tvoi Dela..mov', '', 1152632167, 1);
INSERT INTO `music_songs` VALUES (383, 1171, 1171, '', 'songs/1171Alsou -Always Of My Mind.mp3', '', 1159038853, 1);
INSERT INTO `music_songs` VALUES (189, 923, 916, 'Letala Da Pela', 'songs/923Letala da .mp3', '', 1152594218, 0);
INSERT INTO `music_songs` VALUES (190, 895, 895, 'jash tebe pidmanula', 'songs/895Track04.mp3', '', 1152656650, 0);
INSERT INTO `music_songs` VALUES (191, 895, 895, 'tablitka da lyubvie', 'songs/895Track05.mp3', '', 1152657023, 0);
INSERT INTO `music_songs` VALUES (192, 895, 895, 'Alice', 'songs/895Track02.mp3', '', 1152657222, 0);
INSERT INTO `music_songs` VALUES (193, 895, 895, 'golanka', 'songs/895rynrhka.mp3', '', 1152657667, 0);
INSERT INTO `music_songs` VALUES (194, 895, 895, 'HeBecTa', 'songs/895HeBecTa.mp3', '', 1152658199, 0);
INSERT INTO `music_songs` VALUES (195, 895, 895, 'clova ya teba lyublu', 'songs/895Track05.mp3', '', 1152658423, 0);
INSERT INTO `music_songs` VALUES (282, 856, 975, 'Sexual Revolution', 'songs/856Sexual Revolution.mp3', '', 1152326542, 1);
INSERT INTO `music_songs` VALUES (281, 856, 966, 'Tanzuy sommnoy', 'songs/856Tanzuy sommnoy.mp3', '', 1152326952, 0);
INSERT INTO `music_songs` VALUES (290, 964, 964, 'Aria Alien', 'songs/964Alien.mp3', '', 1153202285, 1);
INSERT INTO `music_songs` VALUES (204, 974, 974, 'Breathe Me', 'songs/974Sia - Breathe Me.mp3', '', 1152673413, 1);
INSERT INTO `music_songs` VALUES (205, 856, 924, 'Ne Svyatay', 'songs/856Ne Svyatay.mp3', '', 1152301946, 0);
INSERT INTO `music_songs` VALUES (207, 943, 943, 'Beautiful Love', 'songs/943The Afters - I Wish We All Could Win - 01 - Beautiful Love.mp3', '', 1152678612, 0);
INSERT INTO `music_songs` VALUES (310, 958, 958, 'Esli', 'songs/958esli.mp3', '', 1153890480, 1);
INSERT INTO `music_songs` VALUES (217, 982, 982, '', 'songs/982Greenjolly, Ascetoholix, Duze Pe, Mezo, Owal, 52 Debiec - Jest Nas Wielu.avi', '', 1152691999, 1);
INSERT INTO `music_songs` VALUES (209, 978, 978, 'mallish', 'songs/978DIMA BILAN MALISH.m3u', '', 1152679291, 0);
INSERT INTO `music_songs` VALUES (210, 978, 978, 'Ti U menya Odna', 'songs/978faktor 2 ti u menja odna.m3u', '', 1152679327, 1);
INSERT INTO `music_songs` VALUES (211, 978, 978, 'MNE BOLNO OCHEN', 'songs/978prozess mne bolno ochen.m3u', '', 1152679350, 0);
INSERT INTO `music_songs` VALUES (212, 978, 978, 'SOLNISHKO', 'songs/978ruki vverh  solnishko.m3u', '', 1152679371, 0);
INSERT INTO `music_songs` VALUES (213, 978, 978, 'LUBLU', 'songs/978reflex lublu.m3u', '', 1152679407, 0);
INSERT INTO `music_songs` VALUES (218, 856, 942, 'Ne Svyatay', 'songs/856Ne Svyatay.mp3', '', 1152301946, 1);
INSERT INTO `music_songs` VALUES (220, 945, 916, 'Kak Tvoi Dela', 'songs/945Kak Tvoi Dela..mov', '', 1152632167, 0);
INSERT INTO `music_songs` VALUES (226, 942, 942, 'track 10 mp3', 'songs/942track 10 in mp3.mp3', '', 1152738812, 0);
INSERT INTO `music_songs` VALUES (231, 999, 999, 'In the cold cold night', 'songs/999White Stripes - In The Cold Cold Night.mp3', '', 1152767096, 1);
INSERT INTO `music_songs` VALUES (230, 991, 991, 'Starz', 'songs/9914thestars.mp3', '', 1152740157, 1);
INSERT INTO `music_songs` VALUES (229, 991, 991, 'NRG', 'songs/991002 Day Time _remix_.mp3', '', 1152739597, 0);
INSERT INTO `music_songs` VALUES (232, 901, 901, 'RUSSIA', 'songs/901You Were Born Inside My Heart.wma', '', 1152768526, 1);
INSERT INTO `music_songs` VALUES (233, 150, 916, 'Breathe Me', 'songs/150Sia - Breathe Me (Mylo Remix).mp3', '', 1152642007, 0);
INSERT INTO `music_songs` VALUES (235, 1004, 1004, 'Zack', 'songs/1004001 See U Again.mp3', '', 1152822052, 1);
INSERT INTO `music_songs` VALUES (234, 945, 857, 'Kak Tvoi Dela', 'songs/945Kak Tvoi Dela..mov', '', 1152632167, 1);
INSERT INTO `music_songs` VALUES (236, 856, 1008, 'Ne Svyatay', 'songs/856Ne Svyatay.mp3', '', 1152301946, 1);
INSERT INTO `music_songs` VALUES (237, 206, 813, '', 'songs/206Fort_Minor-Remember_The_Name.mp3', '', 1152495934, 0);
INSERT INTO `music_songs` VALUES (238, 916, 916, 'Lube', 'songs/916&#1051;&#1102;&#1073;&#1101; - &#1044;&#1072;&#1074;&#1072;&#1081; &#1079;&#1072;....mp3', '', 1152828149, 0);
INSERT INTO `music_songs` VALUES (287, 856, 883, 'BaBy GiRl', 'songs/856BaBy GiRl.mp3', '', 1153098872, 1);
INSERT INTO `music_songs` VALUES (243, 860, 860, 'Kukla', 'songs/860Kukla.mp3', '', 1152854277, 0);
INSERT INTO `music_songs` VALUES (244, 860, 860, 'Mercedes 600', 'songs/860Mercedes 600.mpga', '', 1152855165, 0);
INSERT INTO `music_songs` VALUES (249, 856, 936, 'Sexual Revolution', 'songs/856Sexual Revolution.mp3', '', 1152326542, 0);
INSERT INTO `music_songs` VALUES (250, 856, 984, 'Ashes to Ashes', 'songs/856Ashes to Ashes.mp3', '', 1152327708, 0);
INSERT INTO `music_songs` VALUES (252, 989, 989, 'russian play list', 'songs/989russian love.wpl', '', 1152903290, 0);
INSERT INTO `music_songs` VALUES (254, 885, 885, 'son moi', 'songs/885Akula - Son moj (Original Mix).mp3', '', 1152919554, 0);
INSERT INTO `music_songs` VALUES (255, 907, 907, 'love to see you cry', 'songs/907Enrique Iglesias - 03 - Love to see you cry - 21century.mp3', '', 1152930601, 0);
INSERT INTO `music_songs` VALUES (256, 930, 930, 'Ya tak Lublu tebya', 'songs/930ya tak lublu tebya.mp3', '', 1152950877, 1);
INSERT INTO `music_songs` VALUES (257, 930, 930, 'Ya tak Lublu tebya', 'songs/930ya tak lublu tebya.mp3', '', 1152950988, 0);
INSERT INTO `music_songs` VALUES (258, 930, 930, 'Ya tak Lublu tebya', 'songs/930ya tak lublu tebya.mp3', '', 1152951108, 0);
INSERT INTO `music_songs` VALUES (259, 930, 930, 'Ya tak Lublu tebya', 'songs/930ya tak lublu tebya.mp3', '', 1152951114, 0);
INSERT INTO `music_songs` VALUES (260, 930, 930, 'Ya tak Lublu tebya', 'songs/930ya tak lublu tebya.mp3', '', 1152951238, 0);
INSERT INTO `music_songs` VALUES (261, 930, 930, 'Ya tak Lublu tebya', 'songs/930ya tak lublu tebya.mp3', '', 1152951239, 0);
INSERT INTO `music_songs` VALUES (262, 930, 930, 'Dima Bilan', 'songs/930ya tak lublu tebya.mp3', '', 1152951253, 0);
INSERT INTO `music_songs` VALUES (263, 930, 930, 'Dima Bilan', 'songs/930ya tak lublu tebya.mp3', '', 1152951294, 0);
INSERT INTO `music_songs` VALUES (264, 930, 930, 'Dima Bilan', 'songs/930ya tak lublu tebya.mp3', '', 1152951304, 0);
INSERT INTO `music_songs` VALUES (265, 930, 930, 'Dima Bilan', 'songs/930ya tak lublu tebya.mp3', '', 1152951308, 0);
INSERT INTO `music_songs` VALUES (266, 1020, 1020, 'BelyeTeni', 'songs/1020Belye_Teni_-_Moj_geroj.mp3', '', 1153005901, 0);
INSERT INTO `music_songs` VALUES (267, 1020, 1020, 'Nolimit', 'songs/1020Nolimit - VIP.mp3', '', 1153006073, 0);
INSERT INTO `music_songs` VALUES (268, 1020, 1020, 'Seryoga', 'songs/1020Serega - Mel sudbi.mp3', '', 1153006256, 0);
INSERT INTO `music_songs` VALUES (271, 947, 947, 'EkspoRukiVVerh  Aleshka RmX', 'songs/947EXPO - Aleshka RMX ft Ruki V Verh.mp3', '', 1153058450, 1);
INSERT INTO `music_songs` VALUES (274, 885, 885, 'the show', 'songs/885Girls Aloud - The Show.mp3', '', 1153111100, 0);
INSERT INTO `music_songs` VALUES (275, 885, 885, 'begi', 'songs/885Monokini - Begi.mp3', '', 1153111451, 0);
INSERT INTO `music_songs` VALUES (276, 1020, 1020, 'Spiony', 'songs/1020Spiony_-_Moi_bratjya.mp3', '', 1153155912, 0);
INSERT INTO `music_songs` VALUES (277, 1020, 1020, 'Spiony', 'songs/1020spiony-dozhdisj menja.mp3', '', 1153156179, 0);
INSERT INTO `music_songs` VALUES (278, 1020, 1020, 'Traktor 2', 'songs/1020Traktor 2 - Ty che vasche krasavica.mp3', '', 1153156424, 1);
INSERT INTO `music_songs` VALUES (279, 1020, 1020, 'Patrool', 'songs/1020ElRicoandPatrool-Exraz.mp3', '', 1153156612, 0);
INSERT INTO `music_songs` VALUES (280, 856, 966, 'BaBy GiRl', 'songs/856BaBy GiRl.mp3', '', 1153098872, 1);
INSERT INTO `music_songs` VALUES (283, 758, 975, 'Dance', 'songs/758dance.mp3', '', 1145638513, 0);
INSERT INTO `music_songs` VALUES (284, 942, 942, '', 'songs/94202 02 Track 2.mp3', '', 1153164107, 0);
INSERT INTO `music_songs` VALUES (285, 930, 916, 'Ya tak Lublu tebya', 'songs/930ya tak lublu tebya.mp3', '', 1152950877, 0);
INSERT INTO `music_songs` VALUES (291, 947, 1032, 'EkspoRukiVVerh  Aleshka RmX', 'songs/947EXPO - Aleshka RMX ft Ruki V Verh.mp3', '', 1153058450, 1);
INSERT INTO `music_songs` VALUES (294, 1036, 1036, 'Slipped Away', 'songs/1036Slipped Away..mp3', '', 1153343998, 0);
INSERT INTO `music_songs` VALUES (295, 943, 943, 'All That I Am', 'songs/943The Afters - I Wish We All Could Win - 05 - All That I Am.mp3', '', 1153361813, 1);
INSERT INTO `music_songs` VALUES (296, 947, 325, 'EkspoRukiVVerh  Aleshka RmX', 'songs/947EXPO - Aleshka RMX ft Ruki V Verh.mp3', '', 1153058450, 0);
INSERT INTO `music_songs` VALUES (297, 991, 1003, 'Starz', 'songs/9914thestars.mp3', '', 1152740157, 0);
INSERT INTO `music_songs` VALUES (298, 856, 961, 'BaBy GiRl', 'songs/856BaBy GiRl.mp3', '', 1153098872, 1);
INSERT INTO `music_songs` VALUES (299, 885, 885, 'Kalinka', 'songs/885TECHNO - Russian - Kalinka (Remix).mp3', '', 1153456852, 0);
INSERT INTO `music_songs` VALUES (302, 885, 885, 'good morning papa', 'songs/885Via Gra - Good Morning Papa.mp3', '', 1153458490, 0);
INSERT INTO `music_songs` VALUES (303, 885, 885, 'via gra', 'songs/885via_gra_&_meladze,_valeriy_-_samie_slivki_radioefira_2_-_prityazhen''ya_bol''she_net.mp3', '', 1153458820, 0);
INSERT INTO `music_songs` VALUES (309, 885, 916, 'dla tebya', 'songs/885Angina - Dlya tebya.mp3', '', 1153761766, 0);
INSERT INTO `music_songs` VALUES (308, 885, 885, 'dla tebya', 'songs/885Angina - Dlya tebya.mp3', '', 1153761766, 1);
INSERT INTO `music_songs` VALUES (305, 758, 902, 'Dance', 'songs/758dance.mp3', '', 1145638513, 0);
INSERT INTO `music_songs` VALUES (306, 860, 860, 'DISHI', 'songs/86005.Mnogotochije - Dishi.mp3', '', 1153630238, 0);
INSERT INTO `music_songs` VALUES (311, 895, 1065, 'clova ya teba lyublu', 'songs/895Track05.mp3', '', 1152658423, 0);
INSERT INTO `music_songs` VALUES (312, 172, 1065, 'angel eyes', 'songs/17222-mario_lopez_-_angel_eyes.mp3', '', 1150045921, 1);
INSERT INTO `music_songs` VALUES (313, 1066, 1066, 'Poison', 'songs/1066ACDC - Thunderstruck.mp3', '', 1154003355, 1);
INSERT INTO `music_songs` VALUES (414, 342, 342, 'The Game', 'songs/342The Game - How We Do (Ft 50 Cent).mp3', '', 1161667467, 0);
INSERT INTO `music_songs` VALUES (316, 1036, 1073, 'Slipped Away', 'songs/1036Slipped Away..mp3', '', 1153343998, 1);
INSERT INTO `music_songs` VALUES (317, 895, 1084, 'clova ya teba lyublu', 'songs/895Track05.mp3', '', 1152658423, 0);
INSERT INTO `music_songs` VALUES (318, 856, 1084, 'Ne Svyatay', 'songs/856Ne Svyatay.mp3', '', 1152301946, 1);
INSERT INTO `music_songs` VALUES (469, 1261, 1261, 'Down Another Day', 'songs/126101 Down Another Day.mp3', '', 1164740553, 0);
INSERT INTO `music_songs` VALUES (321, 914, 914, '', 'songs/914MaxDjTeamJony-GdeSjWashiRuki.mp3', '', 1155266686, 1);
INSERT INTO `music_songs` VALUES (322, 885, 1093, 'begi', 'songs/885Monokini - Begi.mp3', '', 1153111451, 1);
INSERT INTO `music_songs` VALUES (323, 1093, 1093, '', 'songs/1093iTunes Library.itl', '', 1155367415, 0);
INSERT INTO `music_songs` VALUES (324, 1096, 1096, '', 'songs/1096Sveta.mp3', '', 1155426955, 1);
INSERT INTO `music_songs` VALUES (325, 1097, 1097, 'Medlyak', 'songs/1097Mr. Credo - Medlyak (Remix).mp3', '', 1155487608, 1);
INSERT INTO `music_songs` VALUES (328, 161, 161, 'Stacho Move Bounce Shake', 'songs/161promodj.ru_PRT_Stacho_Move_Bounce_Shake_voice_Anane_and_MR_V.mp3', '', 1155672084, 1);
INSERT INTO `music_songs` VALUES (329, 1098, 1098, 'Prohodit detstvo', 'songs/1098prohodit detstvo.wma', '', 1155695429, 0);
INSERT INTO `music_songs` VALUES (330, 860, 1098, 'svoboda', 'songs/860svoboda.mp3', '', 1152370814, 1);
INSERT INTO `music_songs` VALUES (331, 1098, 1098, '25', 'songs/109805 ''25 &#1101;&#1090;&#1072;&#1078;''.wma', '', 1155697634, 0);
INSERT INTO `music_songs` VALUES (332, 885, 1097, 'begi', 'songs/885Monokini - Begi.mp3', '', 1153111451, 0);
INSERT INTO `music_songs` VALUES (333, 1097, 1098, 'Medlyak', 'songs/1097Mr. Credo - Medlyak (Remix).mp3', '', 1155487608, 0);
INSERT INTO `music_songs` VALUES (334, 885, 1103, 'begi', 'songs/885Monokini - Begi.mp3', '', 1153111451, 1);
INSERT INTO `music_songs` VALUES (335, 860, 1103, 'DISHI', 'songs/86005.Mnogotochije - Dishi.mp3', '', 1153630238, 0);
INSERT INTO `music_songs` VALUES (336, 945, 1103, 'Kak Tvoi Dela', 'songs/945Kak Tvoi Dela..mov', '', 1152632167, 0);
INSERT INTO `music_songs` VALUES (337, 856, 1103, 'BaBy GiRl', 'songs/856BaBy GiRl.mp3', '', 1153098872, 0);
INSERT INTO `music_songs` VALUES (338, 945, 945, 'Nasha Jizn''', 'songs/945Nasha Jizn''.wma', '', 1156352134, 0);
INSERT INTO `music_songs` VALUES (339, 945, 945, '', 'songs/945Zaputalos Solntce.wma', '', 1156352394, 0);
INSERT INTO `music_songs` VALUES (340, 856, 1107, 'Ne Svyatay', 'songs/856Ne Svyatay.mp3', '', 1152301946, 1);
INSERT INTO `music_songs` VALUES (341, 1107, 1107, '', 'songs/110704 Track 4.wma', '', 1156371049, 0);
INSERT INTO `music_songs` VALUES (346, 1117, 1117, 'Kak Zvezda', 'songs/1117KakZvezda.mp3', '', 1156652298, 0);
INSERT INTO `music_songs` VALUES (345, 903, 1117, 'Burned with Desire', 'songs/903BURNED.mp3', '', 1152498061, 0);
INSERT INTO `music_songs` VALUES (344, 1108, 1108, 'Nad Gudzonom', 'songs/1108Tokarev - Nad Gudzonom.mp3', '', 1156397673, 1);
INSERT INTO `music_songs` VALUES (348, 1097, 1083, 'Medlyak', 'songs/1097Mr. Credo - Medlyak (Remix).mp3', '', 1155487608, 1);
INSERT INTO `music_songs` VALUES (349, 1136, 1136, 'serega  Diskomalarita', 'songs/113603_barbekyu_-_diskomalyariya_-_serega.mp3', '', 1157212553, 1);
INSERT INTO `music_songs` VALUES (350, 1136, 1136, '10 yrs  Through the iris', 'songs/113610 Years - Through The Iris.MP3', '', 1157212648, 0);
INSERT INTO `music_songs` VALUES (351, 1136, 1136, 'ATB   Ecstasy', 'songs/1136ATB - Ecstasy .mp3', '', 1157212779, 0);
INSERT INTO `music_songs` VALUES (352, 1136, 1136, 'luv this one', 'songs/113607 Track 7.mp3', '', 1157212940, 0);
INSERT INTO `music_songs` VALUES (353, 1136, 1136, 'East Clubbers     russian', 'songs/1136East Clubbers - Russian.mp3', '', 1157213040, 0);
INSERT INTO `music_songs` VALUES (354, 1136, 1136, 'call me when ur sober', 'songs/1136Evanescence - Call Me When Your''re Sober NOT FAKE.mp3', '', 1157213409, 0);
INSERT INTO `music_songs` VALUES (355, 1136, 1136, 'hurt   rapture', 'songs/1136Hurt - Rapture.mp3', '', 1157213671, 0);
INSERT INTO `music_songs` VALUES (356, 1136, 1136, 'jem     24   hott song', 'songs/1136Jem - 24 (Ultraviolet Theme Song).mp3', '', 1157213753, 0);
INSERT INTO `music_songs` VALUES (357, 1136, 1136, 'bed of roses', 'songs/1136Mindless Self Indulgence - Bed Of Roses.mp3', '', 1157214148, 0);
INSERT INTO `music_songs` VALUES (358, 1136, 1136, 'striped', 'songs/1136Ramstien - Stripped.mp3', '', 1157214198, 0);
INSERT INTO `music_songs` VALUES (359, 1136, 1136, 'mr credo  zvesda', 'songs/1136Mr Credo - Zvezda vostoka.mp3', '', 1157214249, 0);
INSERT INTO `music_songs` VALUES (360, 1136, 1136, 'kissa', 'songs/1136Russian Bounce - Kisa (DJ Yan Remix) VA ACID TECHNO HARDCORE TRANCE HARDSTYLE DEEP UNDERGROUND CLUB 2006 2007 2008.mp3', '', 1157214409, 0);
INSERT INTO `music_songs` VALUES (361, 1136, 1136, 'solnyshko', 'songs/1136Solnyshko.mp3', '', 1157214462, 0);
INSERT INTO `music_songs` VALUES (362, 1136, 1136, 'cherniy bumer', 'songs/1136Serega & Busta Rhymes-Chernyj bumer (DJ Romashkin Mix).mp3', '', 1157214512, 0);
INSERT INTO `music_songs` VALUES (363, 1136, 1136, 'gay song 333', 'songs/1136vasya_lesha.mp3_144645.mp3', '', 1157214588, 0);
INSERT INTO `music_songs` VALUES (364, 1136, 1136, 'Guljiaj', 'songs/1136Guljiaj.mp3', '', 1157214665, 0);
INSERT INTO `music_songs` VALUES (365, 1136, 1136, 'bandeeta', 'songs/1136bandeeta.mp3', '', 1157214734, 0);
INSERT INTO `music_songs` VALUES (366, 1136, 1136, 'Aerials', 'songs/1136System Of A Down - Aerials.mp3', '', 1157214847, 0);
INSERT INTO `music_songs` VALUES (367, 1136, 1136, 'tatu', 'songs/1136Tatu - All The Things She Said (Russian Techno Remix).mp3', '', 1157214887, 0);
INSERT INTO `music_songs` VALUES (368, 1136, 1135, 'striped', 'songs/1136Ramstien - Stripped.mp3', '', 1157214198, 1);
INSERT INTO `music_songs` VALUES (369, 1136, 1135, 'solnyshko', 'songs/1136Solnyshko.mp3', '', 1157214462, 0);
INSERT INTO `music_songs` VALUES (370, 856, 1150, 'Sexual Revolution', 'songs/856Sexual Revolution.mp3', '', 1152326542, 0);
INSERT INTO `music_songs` VALUES (415, 1211, 1211, 'Rousiki Rouleta', 'songs/1211Rousiki Ro.mp3', '', 1162259044, 1);
INSERT INTO `music_songs` VALUES (379, 1167, 1164, 'ya ne budu s toboi', 'songs/1167Janebudustoboi.mp3', '', 1158633936, 0);
INSERT INTO `music_songs` VALUES (380, 1163, 1163, 'Sweet Sacrifice', 'songs/1163Sweet Sacrifice.mp3', '', 1158768756, 1);
INSERT INTO `music_songs` VALUES (536, 1167, 1167, '', 'songs/116712 Track 12.wma', '', 1167524224, 1);
INSERT INTO `music_songs` VALUES (385, 856, 934, 'Veter C Moory dul', 'songs/856Veter C Moory dul.mp3', '', 1152327246, 0);
INSERT INTO `music_songs` VALUES (387, 1036, 1073, 'Kak Tvoi Dela', 'songs/1036Kak Tvoi Dela..mov', '', 1153343827, 0);
INSERT INTO `music_songs` VALUES (386, 860, 860, 'i want more', 'songs/860i want more.mpga', '', 1159115443, 1);
INSERT INTO `music_songs` VALUES (388, 1178, 1178, 'ZNaesh Li Ti', 'songs/1178Znaesh li ti.mp3', '', 1159449051, 0);
INSERT INTO `music_songs` VALUES (389, 1178, 1178, 'Kogda Ti Riadom', 'songs/1178Kogda ti riadom.mp3', '', 1159449390, 1);
INSERT INTO `music_songs` VALUES (390, 885, 885, 'Klinit', 'songs/885malahova_zhenya_-_klinit_(remix)_[www_MP3shek_net].mp3', '', 1159565830, 0);
INSERT INTO `music_songs` VALUES (398, 153, 153, 'Dancing Galaxy', 'songs/15303-Astral Projection _ Dancing Galaxy (Dynamic remix.1).mp3', '', 1161104583, 1);
INSERT INTO `music_songs` VALUES (468, 1261, 1261, 'Just Like This', 'songs/126102 Just Like This.mp3', '', 1164740278, 0);
INSERT INTO `music_songs` VALUES (467, 1261, 1261, 'It''ll Be Okay', 'songs/126113 It''ll Be Okay.mp3', '', 1164740078, 1);
INSERT INTO `music_songs` VALUES (393, 206, 206, '', 'songs/206060 Hyper - We control.mp3', '', 1159652341, 0);
INSERT INTO `music_songs` VALUES (396, 885, 1086, 'begi', 'songs/885Monokini - Begi.mp3', '', 1153111451, 0);
INSERT INTO `music_songs` VALUES (413, 856, 1200, 'Sexual Revolution', 'songs/856Sexual Revolution.mp3', '', 1152326542, 1);
INSERT INTO `music_songs` VALUES (416, 1163, 1213, 'Sweet Sacrifice', 'songs/1163Sweet Sacrifice.mp3', '', 1158768756, 0);
INSERT INTO `music_songs` VALUES (418, 1210, 1210, 'Awake', 'songs/1210Disturbed, Static X, Slipknot - Awake.mp3', '', 1162599578, 1);
INSERT INTO `music_songs` VALUES (419, 1210, 1210, 'Cold', 'songs/1210Static-X - Cold.mp3', '', 1162599997, 0);
INSERT INTO `music_songs` VALUES (420, 1222, 1222, 'Ridin', 'songs/1222Chamillionaire feat. Krayzie Bone-Ridin(radio edit).mp3', '', 1162720791, 1);
INSERT INTO `music_songs` VALUES (421, 1222, 1222, 'Roma Izvini', 'songs/1222&#1047;&#1074;&#1077;&#1088;&#1080;-&#1056;&#1086;&#1084;&#1072;,&#1080;&#1079;&#1074;&#1080;&#1085;&#1080;.mp3', '', 1162721102, 0);
INSERT INTO `music_songs` VALUES (422, 1163, 1219, 'Sweet Sacrifice', 'songs/1163Sweet Sacrifice.mp3', '', 1158768756, 0);
INSERT INTO `music_songs` VALUES (423, 1219, 1219, 'The Sharpest Lives', 'songs/121904-my_chemical_romance-the_sharpest_lives.mp3', '', 1162766308, 1);
INSERT INTO `music_songs` VALUES (424, 1219, 1219, 'The Sharpest Lives', 'songs/121904-my_chemical_romance-the_sharpest_lives.mp3', '', 1162766314, 0);
INSERT INTO `music_songs` VALUES (425, 1171, 1226, '', 'songs/1171Alsou -Always Of My Mind.mp3', '', 1159038853, 1);
INSERT INTO `music_songs` VALUES (426, 1097, 1226, 'Medlyak', 'songs/1097Mr. Credo - Medlyak (Remix).mp3', '', 1155487608, 0);
INSERT INTO `music_songs` VALUES (427, 1167, 1226, 'ya ne budu s toboi', 'songs/1167Janebudustoboi.mp3', '', 1158633936, 0);
INSERT INTO `music_songs` VALUES (428, 1178, 1226, 'Kogda Ti Riadom', 'songs/1178Kogda ti riadom.mp3', '', 1159449390, 0);
INSERT INTO `music_songs` VALUES (429, 856, 1226, 'Ne Svyatay', 'songs/856Ne Svyatay.mp3', '', 1152301946, 0);
INSERT INTO `music_songs` VALUES (430, 856, 938, 'Ne Svyatay', 'songs/856Ne Svyatay.mp3', '', 1152301946, 0);
INSERT INTO `music_songs` VALUES (432, 1237, 1237, 'If I Could', 'songs/123710 If I Could.mp3', '', 1164122907, 0);
INSERT INTO `music_songs` VALUES (433, 1233, 1233, 'Lips Of An Angel', 'songs/123308 Lips of an Angel.mp3', '', 1164137852, 0);
INSERT INTO `music_songs` VALUES (434, 1233, 1233, 'Crazy Bitch', 'songs/123307 Crazy Bitch.mp3', '', 1164206476, 0);
INSERT INTO `music_songs` VALUES (435, 1233, 1233, 'We Don''t Die', 'songs/123303 We Don''t Die.mp3', '', 1164206637, 0);
INSERT INTO `music_songs` VALUES (442, 1242, 1242, '', 'songs/1242Taking Back Sunday - MakeDamnSure.mp3', '', 1164215909, 0);
INSERT INTO `music_songs` VALUES (436, 1237, 1237, 'DriveThru', 'songs/1237DriveThru.mp3', '', 1164211594, 0);
INSERT INTO `music_songs` VALUES (437, 1233, 1233, 'Cotton Candy  Popsicles', 'songs/123313 Cotton Candy & Popsicles.mp3', '', 1164214396, 1);
INSERT INTO `music_songs` VALUES (438, 1233, 1233, 'juggalo homies', 'songs/123310 Juggalo Homies.mp3', '', 1164214560, 0);
INSERT INTO `music_songs` VALUES (476, 1254, 1254, 'Spin The Bottle', 'songs/125405 Spin The Bottle.mp3', '', 1164767327, 0);
INSERT INTO `music_songs` VALUES (441, 1242, 1242, '', 'songs/124210 Track 10.wma', '', 1164215631, 0);
INSERT INTO `music_songs` VALUES (440, 1242, 1242, 'face down', 'songs/1242AnRWatch.com-RedJumpsuitApparatus-FaceDown.mp3', '', 1164215536, 0);
INSERT INTO `music_songs` VALUES (525, 1296, 1296, 'FreeStyleStonedRapperpalooza', 'songs/1296FreeStyleStonedRapperpalooza.mp3', '', 1165797450, 1);
INSERT INTO `music_songs` VALUES (443, 895, 1247, 'clova ya teba lyublu', 'songs/895Track05.mp3', '', 1152658423, 0);
INSERT INTO `music_songs` VALUES (444, 1252, 1252, 'Promises', 'songs/125205 Promises.mp3', '', 1164649274, 1);
INSERT INTO `music_songs` VALUES (445, 1252, 1252, 'Remember', 'songs/125201 Remember.mp3', '', 1164649402, 0);
INSERT INTO `music_songs` VALUES (446, 1252, 1252, 'Giving In', 'songs/125210 Giving In.mp3', '', 1164649688, 0);
INSERT INTO `music_songs` VALUES (447, 1252, 1252, 'Freaking Out', 'songs/125204 Freaking Out.mp3', '', 1164649822, 0);
INSERT INTO `music_songs` VALUES (448, 1252, 1251, 'Freaking Out', 'songs/125204 Freaking Out.mp3', '', 1164649822, 0);
INSERT INTO `music_songs` VALUES (461, 1258, 1258, 'Bring It On', 'songs/125805 Bring It On.mp3', '', 1164692595, 1);
INSERT INTO `music_songs` VALUES (449, 1253, 1253, 'Lets Go All The Way', 'songs/1253Lets Go All The Way.mp3', '', 1164677928, 1);
INSERT INTO `music_songs` VALUES (450, 1254, 1254, 'Bury Me Alive', 'songs/125411 Bury Me Alive.mp3', 0x5b4d6f6e6f78696465204368696c645d3c42523e4920646f6e7420676976652061206675636b2c207269676874213c42523e44656164206661636520776974682074686520657965732077686974652e3c42523e496e74696d696461746520796f752077697468206d792065796573696768742e3c42523e496d20747279696e6720746f20686964652066726f6d2074686520617665726167652e3c42523e4576657279646179207765207374617274696e207374617469632e3c42523e4c6976696e207769746820746865206d6167676f74732e3c42523e4d617374657273206f662074686520626c61636b206d616769632e3c42523e4d7920736869747320666f72206b696c6c6173207769746820746865207477697a7469642074617473206f6e2074686579206261636b732e3c42523e4d7920736869747320666f72206b696c6c61732077686f2077616c6b2061726f756e642077697468207468652061782e3c42523e4d7920736869747320666f72206b696c6c61732073637265616d696e204920776f756c6420726174686572206469652e3c42523e5468656e2073656520796f75206d6f746861206675636b617320646f696e204d5456206c6976652e3c42523e596f752063616e206b65657020746865206d61696e73747265616d206c69666520616e6420616c6c2074686520686f27732e3c42523e49276d207374656164792063757373696e20696e20766964656f27732e3c42523e466f72204a756767616c6f732e3c42523e496d20756e64657267726f756e6420776865726520746865206465616420646f6e277420736c6565702e3c42523e4b65657020757320612073656372657420746f2074687720776f726c6420616e642077617463682074686520706f73736520696e6372656173652e3c42523e536f20696620796f75206665656c206d65207468656e2062757279206d6520616c6976652e3c42523e5b43686f7275732032785d3c42523e42757279206d6520416c6976652842757279206d6520416c697665292e3c42523e52756e2077697468207468652050737963686f70617468696320486174636865742e3c42523e5468656e2068696465213c42523e42757279206d6520416c6976652842757279206d6520416c697665292e3c42523e4b65657020697420696e20796f206b6c697120616e64206675636b20746865206f7574736964652e3c42523e5b4a616d6965204d616464726f785d3c42523e53747269636b6c7920666f7220746865206a756767616c6f732c20626974636820492074686f7567687420796f75206b6e65772e3c42523e4361757365207765207365616c696e20757020746865206d61696e73747265616d20656172732077697468206372617a7920676c75653c42523e536f20746865792063616e2068656172206120776f7264207765207361792e3c42523e57652073746179207477697a7469642c20737065616b696e20766f6f646f6f207468656d206269746368657320776f756c646e277420756e6465727374616e642069743c42523e616e797761792e3c42523e57616c6b20776974682061206178207768656e207468652073756e2066616c6c732e3c42523e54616c6b696e20746f20746865206f75696a6120626f61726420666f722070726564696374696f6e73206f662074686520686f6c6f63617573742e3c42523e476976652061206675636b206c6573732061626f757420766964656f206f7220616972706c61792e3c42523e57652073746179203f3f20616e642073637265616d2074696c6c20746865206865616420627265616b2e3c42523e5468697320697320796f7572207368697420697420776173206d61646520666f7220796f752e3c42523e446f6e74206c65742074686520726164696f20696e666c75656e636520796f752e3c42523e416e642074656c6c20796f75207768617420746f206c697374656e20746f2e3c42523e416e64206576657279626f6479206174204d54562063616e207375636b206d79206469636b2e3c42523e54656c6c696e206d6520776527642062652074686520736869742069662074686579206c6162656c656420757320612062757a7a20636c69702e3c42523e4d616e206675636b2074686174213c42523e57652062652062656e65617468207468652067726f756e642e3c42523e576520726f736520776974682074686520686174636865742c20796f752063616e206865617220746865207769636b656420736f756e642e3c42523e496e20796f7572206561726472756d732c20646f6e74206c657420746865206f74686572732067657420612074617374652e3c42523e416e6420696620746865792073746172742062756d702069742c20697420676f6e6e6120736d61636b207468656d20696e2074686520666163652e3c42523e5468656e2062757279206d7920616c6976652e3c42523e5b43686f7275732031785d3c42523e5769746820612066757279206f66206275636b73686f74732e3c42523e476f642044616d6e207468657920727574686c6573732e2032783c42523e5b4d6f6e6f78696465204368696c645d3c42523e546869732061696e74206e6f203f3f3f3f20736f206e6f626f64792064616e63696e2e3c42523e49206f6e6c79206675636b207769746820746865206465616420616e64206d79206d6f746861206675636b696e20616476616e6365732e3c42523e4368616e636573206172652c20796f75206f75747461206c75636b207768656e20796f75206675636b696e207769746820746865206b696c6c61732e3c42523e50737963686f7061746869632c206675636b2069742077652062652074686520696c6c6573742e3c42523e4b65656f20697420746865207265616c6973742e3c42523e4c696b65206576657279626f647920656c7365207468617420626520646f696e20746861742e3c42523e496d20696e20746865206261636b20696e20626c61636b2c206368696c6c696e20776974682074686520626c6f6f64792061782e3c42523e5768656e2077652061747461636b2e3c42523e5765206861766520796f75722077686f6c6520637265772073686f6f6b2e3c42523e596f752066616b6520686f2773206b6e6f772c207477697a7469642077726f74652074686520676f642064616d6e20626f6f6b2e3c42523e5b4a616d6965204d616464726f785d3c42523e416e64204920646f6e7420676976652061206675636b2e3c42523e5065727061747261746f727320796f752063616e207375636b206d79206e7574732e3c42523e53617920796f7520626f756768742074686520616c62756d2c2062757420646f6e74206b6e6f7720612073696e676c65206375742e3c42523e596f75277320612062616e647761676f6e207269646120676976696e206a756767616c6f2773206120626164206e616d652e3c42523e5765276c6c206675636b20796f7520757020666f7220746861742c20626974636820746869732061696e74206e6f206675636b696e2067616d652e3c42523e4675636b20616c6c20746861742073686974207468617420746865207072696e742077726f74652e3c42523e4d6167617a696e657320697320746f696c65742070617065722c20676c6f72696669656420666f722074686520617373686f6c65732e3c42523e4675636b205075626c69636174696f6e2e3c42523e53796e6469636174696f6e2e3c42523e4d75736963205365677261676174696f6e2e3c42523e43617573652077652072756e2062656e6561746820746865206e6174696f6e2e3c42523e536f2062757279206d6520616c6976652e3c42523e5b43686f7275732031785d3c42523e5769746820612066757279206f66206275636b73686f74732e3c42523e476f642044616d6e207468657920727574686c6573732e203278, 1164680856, 1);
INSERT INTO `music_songs` VALUES (451, 1254, 1254, 'Afraid Of Me', 'songs/125404 Afraid of Me.mp3', 0x5b43686f7275732078325d3c42523e49276d20736f203c42523e48696464656e20616e6420796f75277265206e6576657220676f6e6e6120736565203c42523e49276d20636f6c64203c42523e466f72676976656e20616c6c2062656361757365206f66206d792062656c69656673203c42523e49276d206e6f203c42523e426f6479207468617420796f7520657665722077616e6e61206265203c42523e43617573652049206b6e6f7720746861742074686520776f726c6420697320616672616964206f66206d65203c42523e5b4d6f6e6f78696465204368696c645d3c42523e4e6f7720796f752063616e2074727920746f20736564617465206d652c20617373617373696e617465206f72206a7573742068617465206d65203c42523e4275742074686572652773206e6f7468696e67207468617420796f752063616e20646f20746f206d65206c6174656c79203c42523e4e6f772049276d2067726561746c7920616363657074656420696e20746865206d696e6420736f2049276d20636f6e667573656420616e6420696e7465727477696e6564203c42523e46726f6d206265696e672072656a656374656420736f206d616e792074696d65732c20492077616e6e61206c6561766520697420616c6c20626568696e64203c42523e536f206b696e64206f6620796f7520746f207069636b2075702074686520616c62756d20616e64206769766520697420612074727920666f72206f6e6365203c42523e416e642072756e20616e642074656c6c20796f757220686f6d6965732074686174207468657365206d6f746865726675636b6572732077696c6c2064696520666f72207573203c42523e536f206d616e79207175657374696f6e732c2066696e6765727320706f696e74696e6720666f7220616e7377657273203c42523e53756767657374696e6720746861742049276d207468652063616e6365722074686174206c696e6765727320696e73696465207468652070617374757265203c42523e5769746820677265656e20677261737320757020746f206d79206e65636b2c20616e6420736974756174696f6e732074686174277320746f6f2066617374203c42523e546f207468696e6b2061626f757420616e64206d6f73742070656f706c652063616e277420647265616d2061626f7574203c42523e412068756e64726564206d696c6c696f6e206d696c657320616e642065766572792073696e676c65207365636f6e64203c42523e416e642065766572792074696d6520796f7520686561722074686973207265636f726420492077616e7420796f7520746f206665656c206d65206f6e2065766572792073656e74656e6365203c42523e52656d696e697363652066726f6d2064657363656e64616e7473206f66207061737420747265617375726573203c42523e5765276c6c20656d6261726b206f6e2061206a6f75726e65792074686174276c6c207374617920616c69766520666f7265766572203c42523e506c7573204920776f756c64207374616e64206f766572206f6e206d792073696465206f66207468652066656e6365203c42523e5265676172646c657373206f66207468652063697263756d7374616e636573206f722074686520636f6e73657175656e636573203c42523e5b43686f7275732078325d3c42523e49276d20736f203c42523e48696464656e20616e6420796f75277265206e6576657220676f6e6e6120736565203c42523e49276d20636f6c64203c42523e466f72676976656e20616c6c2062656361757365206f66206d792062656c69656673203c42523e49276d206e6f203c42523e426f6479207468617420796f7520657665722077616e6e61206265203c42523e43617573652049206b6e6f7720746861742074686520776f726c6420697320616672616964206f66206d65203c42523e5b4a616d6965204d6164726f785d3c42523e4920616d206d79206f776e20776f72737420656e656d79203c42523e49276d206e6f742074686520736d617274657374206d6f746865726675636b657220616e6420736869742c204920646f6e27742070726574656e6420746f206265203c42523e416e6420776879204920616d2074686520776179204920616d206973206e6f742061206d797374657279203c42523e4d79206d696e642773206e6f7420696e2070726f70657220776f726b696e67206f72646572206f7220696e2074686572617079203c42523e54686520627261696e277320636f6e667573656420616e64206d656e74616c6c7920616275736564203c42523e4c6966652773206265656e2068616e67696e67206f6e206120737472696e6720736f207768617420746865206675636b204920676f7420746f206c6f6f73653f203c42523e416e64207768617420746865206675636b204920676f7420746f2070726f766520746f20796f753f203c42523e496620796f7520646f6e2774206b6e6f77206d65206279206e6f772c20796f75276c6c206e65766572206b6e6f77206d65203c42523e596f752063616e207075742074686174206f6e206d79207265616c20686f6d696573203c42523e4920676f742070726f626c656d7320616e64207468657920737461636b206c696b652062696c6c73203c42523e416e6420492072656c61746520746f207468652062726f6b656e2c20626c656564696e67206865617274206c6f7665206b696c6c6564203c42523e416e642049206177616974656420696e2074686520736861646f77732c206177616b6520696e20746865206461726b203c42523e486f70696e6720746f2074616c6b20746f2074686520706173736564206f6e2c2049276d2066616c6c696e67206170617274203c42523e49276d20737563682061206d65737320616e642064656369736976652c2049276d20666164696e672061776179203c42523e49276d206f7574206f6620746f756368207769746820736f636965747920616e64206c6976696e6720746f646179203c42523e4e657665722072656c79696e67206f6e206d792073616e6974792c2049207468726f7567682069742061776179203c42523e546f206265636f6d6520746865206d616e6961632074686174277320676f7420796f757220617474656e74696f6e20746f646179203c42523e5b43686f7275732078325d3c42523e49276d20736f203c42523e48696464656e20616e6420796f75277265206e6576657220676f6e6e6120736565203c42523e49276d20636f6c64203c42523e466f72676976656e20616c6c2062656361757365206f66206d792062656c69656673203c42523e49276d206e6f203c42523e426f6479207468617420796f7520657665722077616e6e61206265203c42523e43617573652049206b6e6f7720746861742074686520776f726c6420697320616672616964206f66206d65203c42523e5b4d6f6e6f78696465204368696c645d3c42523e43616e20796f75206b6565702061207365637265743f203c42523e57656c6c2049276d2061667261696420776f726c64206265636175736520746865792077616e74206d6520746f206469652c2063616e20796f752062656c696576652069743f203c42523e4275742049276d207374696c6c20616c6976652e2e2e20616e64206265656e20666c6f6174696e672073696e636520273935203c42523e57697468206d79206368696e2068656c642068696768206275742049276d20736f206465616420696e73696465203c42523e4c6574207468652070726f626c656d73206a75737420726f6c6c20616e6420707574207468656d206261636b20696e746f20612070696c65203c42523e426563617573652069742773206a75737420612062756e6368206f662073686974207468617420492063616e2774206465616c2077697468207269676874206e6f77203c42523e416e642049276d207469726564206f6620616c77617973206775657373696e6720616e64206d657373696e6720697420757020616761696e203c42523e416e6420746865206e657874206461792069742773206576656e2064656570657220616e642049276d207374656164792073696e6b696e6720696e203c42523e5b4a616d6965204d6164726f785d3c42523e4920746f6f6b2061206c6f6f6b206174206d7973656c6620616e642063616d6520746f20677269707320776974682077686174204920666f756e64203c42523e497420776173206120766973696f6e206f662061206368696c642c2064697374757262656420616e642062726f6b6520646f776e203c42523e4e6f20736f756c2c206e6f2068656172742062656361757365204920676176652069742061776179203c42523e4e6f2074696d6520666f72206665656c696e6720736f7272792c2049276c6c2067726965766520616e6f7468657220646179203c42523e416e6420616c6c2074686f7365207465617273206172652073746f72656420696e2073746f726d20636c6f756473203c42523e5468617420686f7665722061626f7665206d6520616e6420636f766572207468652075676c79203c42523e436f6e74696e75656420746f206861756e74206d65207768656e204920776173206665656c696e67206c6f77203c42523e546861742773207468652073616d6520726561736f6e204920686f6c64206f6e20616e64206e65766572206c657420676f203c42523e5b43686f7275732078345d3c42523e49276d20736f203c42523e48696464656e20616e6420796f75277265206e6576657220676f6e6e6120736565203c42523e49276d20636f6c64203c42523e466f72676976656e20616c6c2062656361757365206f66206d792062656c69656673203c42523e49276d206e6f203c42523e426f6479207468617420796f7520657665722077616e6e61206265203c42523e43617573652049206b6e6f7720746861742074686520776f726c6420697320616672616964206f66206d653c42523e, 1164681417, 0);
INSERT INTO `music_songs` VALUES (452, 1254, 1254, 'We Don''t Die', 'songs/125403 We Don''t Die.mp3', '', 1164681933, 0);
INSERT INTO `music_songs` VALUES (453, 1254, 1254, 'fuckonthe1stdate', 'songs/125405 fuckonthe1stdate.mp3', 0x5b4d6f6e6f78696465204368696c645d3c42523e4e6f77206c6574206d6520696e74726f64756365206d7973656c6620617320746865206d616e3c42523e4675636b696e6720657665727920626974636820696e2074686520776f726c642c206a7573742063757a20492063616e3c42523e416e64204920776f6e2774206576656e20706c6179207769746820796f752062697463686573207468617420646f6e2774206675636b3c42523e416c6c2049206b6e6f772c20796f7520636f756c64206265206120647564652077697468207961206e757473206375743c42523e4920646f6e2774206e65656420616c6c207468652073747265737320616e6420616c6c207468652067616d65733c42523e416e6420616c6c207468652063616c6c696e27206d65206e616d657320616e6420616c6c207468652066726f6e74696e27206c696b6520796f752772652073616e653c42523e42697463682c20796f752061696e2774207368697420627574206120686f6520616e64206120747269636b3c42523e416e6420616c6c20796f7527726520676f6f6420666f7220697320686f706566756c6c79206675636b696e6720616e64207375636b696e67206469636b3c42523e57616e6e6120626c616d65206974206f6e206d79206d757369633f2057656c6c2074686174276c6c206e657665722068617070656e3c42523e43757a204920776173206675636b696e2720686f6573206c696b6520796f75206265666f7265207468652072617070696e273c42523e476f696e2720676574206d6520746f20736c617070696e27206f6e20746861742061737320616e64206275747420636865656b733c42523e416e6420676574206d79206469636b20746f2073706c617368696e2720616e642063756d6d696e27206f6e20626564207368656574733c42523e49276d2061206c756e617469632c20776861742075702c2049276d206c6f6f6b696e2720746f20676574206c6169643c42523e28414e442054484520484f4f4b455253204845524520544f4e49474854204953204c4f4f4b494e4720544f204745542050414944293c42523e4675636b20746861742c204920776f6e2774207370656e64206e6f206e69636b656c206f6e206e6f206173733c42523e4920646f6e2774206576656e2077616e74206e6f207374696e6b696e272062697463686573207468696e6b696e272061626f7574206d7920636173683c42523e5b486f6f6b5d2028726570656174207477696365293c42523e42697463682c20796f7520636f6d696e27206f75747461207468656d2070616e74733c42523e49276d20747279696e6720746f20666967757265206f75742077686574686572206f72206e6f742049276d2067657474696e27206173733c42523e57652063616c6c696e2720666f722074686520667265616b732c20796f75207468696e6b2049276d206d6f76696e2720746f6f20666173743c42523e42757420696620796f7520646f6e2774206675636b206f6e2074686520666972737420646174652049276d206c656176696e272074686174206173733c42523e5b4a616d6965204d6164726f785d3c42523e426974636820776974272074686520626967206c6970732c2049276d206120796f756e67206e696767613c42523e57697427206372617a79206675636b20696e206d7920686970733c42523e416e6420492063616e206d616b6520796f7520646f207468696e677320796f752772652061667261696420746f20646f3c42523e416e642062792074686520656e64206f6620746865206e696768742c20796f752077616e74206d6520746f206675636b20796f753c42523e4865792062697463682c207468617427732061206e696365206173733c42523e4c656d6d652073656520796f7520737472697020646f776e20746f20666c65736820616e642073686f77206d65206120666c6173682064616e63653c42523e476f74206d6520726973696e2720696e206d792070616e74732c20616e642049276d207069746368696e2720612074656e743c42523e49742773206a757374206120766964656f2063616d6572612c206e6f206e65656420746f206765742075707365743c42523e4865792062697463682c20646f20796f75206c696b65207365783f2057656c6c206d6520746f6f3c42523e49276d20676f696e272070756c6c206d79206469636b206f757420616e642074686973206973207768617420776520676f696e2720646f3c42523e4675636b202774696c207468652073756e20636f6d657320757020616e642066616c6c2061736c6565703c42523e4c656176696e2720707573736965732062617474657265642c206162757365642c20616e64206e756d6220666f72207765656b733c42523e596f752073617920796f75206e65766572207375636b6564206469636b2c2061206d696e6f72206f62737461636c653c42523e4a7573742070726574656e642074686174206d79206469636b206973206120706f707369636c653c42523e416e64206c69636b20697420616c6c206f6e2074686520736964657320616e64207469703c42523e596f7520676f7420637265616d2d7369636c652066696c6c696e67206f6e20796120746f756e676520616e64206c6970733c42523e5b486f6f6b5d3c42523e5b4d6f6e6f78696465204368696c645d3c42523e596f752063616e2074656c6c2069742066726f6d20746865206765742d676f2062697463682c20492061696e277420746865206f6e653c42523e416e64207374726963746c7920666f7220796f757220696e666f2062697463682c20796f752061696e27742074686520626f6d623c42523e4920646f6e65206675636b6564206d617962652032206f72203320686f657320617420612074696d653c42523e416e6420746865206d6f737420686f65732049206675636b656420696e206f6e65206e69676874206973206c696b652066697665202844414d4e21293c42523e596f7520636f756c642073617920746861742049276d20616464696374656420746f207365783c42523e42757420696620796f75206b6e6f77206d79207365656473207468656e20796f75206b6e6f772049276d20616464696374656420746f2064656174683c42523e4d6f6e6f786964652c206675636b696e272062697463686573206c65667420616e642072696768743c42523e4c65742061206b696c6c61206b6e6f772c206966207961206675636b696e2720746f6e696768743c42523e5b4a616d6965204d6164726f785d3c42523e4865792062697463682c20646f20796120736861766520796f75722070656163683f3c42523e492063616e20636865636b2063757a20796f75722062656176657227732077697468696e206d792061726d2072656163683c42523e28534f20535455424c5929204c6561766520612072617368206f6e206d7920636f636b3c42523e3f3f3f20757020637261646c6520616e64206475627320617265204963792d486f743c42523e4865792062697463682c20776f756c6420796f752066696e67657220796f757220626f783c42523e416e64207275622074686520627574742c206f6620746865206e69676761206e616d6564204d6164726f783f3c42523e48616c662d686f7572206b696c6c61207769746820616e20686f757220776f727468206f66206469636b3c42523e536f20646f20796f752077616e6e61206675636b3f2048657920796f752c20686579204249544348213c42523e5b486f6f6b5d3c42523e5b4a616d6965204d6164726f785d3c42523e537475706964206269746368213c42523e5768617420746865206675636b20796f75207468696e6b20746869732069733f3c42523e492074616b6520796f75206f757420746f2064696e6e65723c42523e4d6179626520746f2061206d6f7669652c20616e6420796f7520646f6e27742077616e6e61206675636b3f213f3c42523e57686f20746865206675636b20796f75207468696e6b20796f75206172653f213f3c42523e4d6f746865726675636b696e27204c697a20436c6169626f726e652c2062697463683f3c42523e4920646f6e2774206c696b65207468617420736869742c20616e64204920646f6e2774206c696b6520796f75213c42523e536f20696620796f752061696e2774206675636b696e272c20796f75206e65656420746f20626f756e63652c206269746368213c42523e546861742773206f6e206d79206d6f6d73213c42523e49276d206c6f6f6b696e2720666f72206173732c206d6f6e65792c20616e64206465616420736869743c42523e, 1164682264, 0);
INSERT INTO `music_songs` VALUES (454, 1254, 1254, '85 Bucks An Hour', 'songs/125408 $85 Bucks an Hour.mp3', 0x2856696f6c656e74204a293c42523e4368696c6c696e27206174207468652073747564696f2e2e2e3c42523e4368696c6c696e206174207468652073747564696f2c203835206275636b7320616e20686f757220736f20687572727920757020616e64206c6f6f702061203c42523e62656174204d696b652e20436f6d65206f6e213c42523e284d7573696320737461727473293c42523e55682c2055682c2055683c42523e49276d2056696f6c656e74204a20627574206d7920686f6d6965732063616c6c206d652053686974686561643c42523e42757420746861742773206d7920686f6d6965732c20746f20796f752049276d2056696f6c656e74204a2062697463683c42523e4920707574206d7920626f7973206f6e206120747261636b206576656e2074686f7567682074686579207375636b3c42523e2844617665293c42523e596f20646177672c2049276d204461766520616e64204920646f6e277420676976652061206675636b3c42523e2856696f6c656e74204a293c42523e49206469642061207265636f7264206465616c2c2049207369676e6564206120636f6e74726163743c42523e546563686e6963616c6c792c20666f722049736c616e6420492063616e206f6e6c79207261703c42523e57656c6c206675636b20746861742c2077697468205477697a7469642049276d61207374696c6c20737069743c42523e4576656e2074686f756768204920676f74206120636f6c6420616e64204920736f756e64206c696b6520736869743c42523e5768617420746865206675636b2077617320746861743f204675636b2069742c206c6561766520697420696e2c2074686174207368697420697320706861743c42523e596f7520686561726420746869732062656174206569676874792074696d65732049276d61207374696c6c20667265616b2069743c42523e416e6420696620796f75206e6f746963652c206d79207368697420646f6e2774206576656e207268796d652e2e2e3c42523e4c6f6f6b20617420746861742e20492061696e2774206576656e20676f7420612072617020616e642069742773207374696c6c20706861743c42523e4d7920736869742077656e7420676f6c642c204920676f7420666174206e7574733c42523e416e6420796f75277265207374696c6c20666c79657227696e207061726b696e67206c6f74733c42523e596f75206d6967687420736179206d7920766f63616c732061726520757020746f6f206c6f75643c42523e536f2049276d61207475726e2027656d207570206c6f7564657220746f207069737320796f75206f6666213c42523e507379636f706174686963207265636f726473206172652067656e69757365732c20676574206f6666206f75722070656e697365733c42523e4865726520636f6d6573207468652063686f7275732c20627574204920676f74206e6f20686f6f6b3c42523e496e73746561642049276c6c206a757374206675636b2077697468207468652070686f6e6520626f6f6b3c42523e284d7573696320637574732e2050686f6e652072696e67732c206120677579207069636b73207570293c42523e48656c6c6f3f3c42523e28536c696d20416e7573293c42523e596561682075682c204861727279205361636b7320506c656173653f3c42523e2847757929203c42523e57686f20697320746869733f3c42523e28536c696d20416e7573293c42523e55682048617272792c20686579207468697320697320536c696d20416e757320646f776e206174207468652063616e6e6572792c203c42523e75682c204469636b2053686f6f746572206c65667420612062756c6c6574696e2c20736f6d657468696e672061626f75742c2075682c203c42523e796f752066696c6c696e6720696e2068697320736c6f7420746f6e6967687420646f776e206174207468652c2075682c206761726167652e203c42523e576520676f74206120636173656d656e74206f662066756467652e205765206e656564206173206d616e79207061636b6572732061732077653c42523e63616e206765742c207568207568205361636b732e3c42523e28477579293c42523e2e2e2e48656c6c6f3f3c42523e284d7573696320537461727473293c42523e55682055683c42523e284a616d6965204d616464726f78293c42523e4d79206e616d65206973204a616d6965204d616464726f7820616e64204920676f74206661742062616c6c733c42523e49276d20616c77617973207572696e6174696e6720696e20746865206d6f74656c2068616c6c733c42523e4920676f7420612062696720686561642074686174206e6576657220666974732061206861743c42523e536f20796f752061696e277420736565206d652077656172696e6720612064616d6e207468696e6720677265656e2062697463683c42523e49276d206661722066726f6d20726963682c204920676f74746120686f6f7074793c42523e57697468206120736d61736820696e207468652066656e6465722c20616e6420696e20746865206261636b20746f6f3c42523e4920676f74746120612062726f6b656e207461696c206c6967687420616e642049276c6c20736d61736820796f753c42523e42697463682c20676574206f75747461206d79207761792e20576520676f7420636c6f776e206c6f76653c42523e4661742070726f707320746f20746865206c79726963616c20546f6d204475623c42523e284d6f6e6f78696465204368696c64293c42523e4974277320746865204d2d4f2d4e2d4f2c20616e6420492063616e2774206576656e207370656c6c2074686520726573743c42523e49742074616b657320746f6f206c6f6e6720616e642049206e6565642061206675636b696e27206369676172657474653c42523e492063616e277420686561722c206d79207269676874206561722773206d6164207761636b3c42523e536f207368757420746865206675636b20757020616e64206c697374656e206f722067657420616e20617373206b69636b696e273c42523e4920736c617020686f657320616e642063616c6c207468656d206269746368657320746f20746869657220666163653c42523e416e642073637265616d204e6f77206675636b206f66662062697463682c205477697a74696420696e2074686520706c6163653c42523e536f206261636b2075702c207265636f676e697a6520616e6420636865636b206e7574733c42523e2743617573652073696d706c79206d7920646561722c204920646f6e277420676976652061206675636b213c42523e284d7573696320637574732e2050686f6e652072696e67732c206120677579207069636b73207570293c42523e3f3f3f3f3f3f3f3f3c42523e284d6f27205374796c6573293c42523e596f2c2074686973206973204d6f27205374796c657320696e20746869732070696563652c2077686174277320757020736f6e3f3c42523e28477579293c42523e48656c6c6f3f3c42523e284d6f27205374796c6573293c42523e596561682c2077686174277320757020736f6e3f2049276d206c6f6f6b696e2720666f2074686973206465616c2c203c42523e796f75206b6e6f7720776861742049276d20736179696e273f20493c42523e676f74207261707320746f206275737420666f207927616c6c2e205927616c6c20726561647920666f204d6f27205374796c65733f203c42523e49276d2027626f757420746f206b69636b207468697320666c6f772c207927616c6c20726561647920666f20746869732073686974206f7220776861743f203c42523e28477579293c42523e57686f277320746869733f3c42523e284d6f27205374796c6573293c42523e576f726420757020736f6e2e2049276d204d6f27205374796c65732c2049276d2073747261696768742066726f6d2074686520686f6f642e203c42523e4920676f7420616c6c206d792070656f706c6573206f6e20312d383030204372656e736861772e20576520636f6d696e2720686172642e3c42523e284d7573696320537461727473293c42523e4272696e672069742c206272696e672069742c206272696e672069743c42523e28536861676779203220446f7065293c42523e4d79206e616d6573203220446f70652c20616e6420736f6d6574696d6573205368616767793c42523e536f6d6574696d65732053686167732c20616e6420736f6d6574696d6573204775696428677569646f293c42523e4920676574206d6164207374757069642c20492067657473206d616420696c6c3c42523e4c6f636b656420646f776e20696e20616c6c20666976652c206675636b2069742c204920646f2074686973207374696c6c203c42523e53747265746368206d79206e757473206261636b206c696b65206120736c696e6773686f7420616e6420706c616e742027656d20696e20796f7572206d6f7574683c42523e5368616b65206d792068697073206c696b6520456c7669732c20776967676c696e67206d792070656c7669733c42523e4c617374206b6964207468617420737465707065642c203c42523e49206170706c69656420612043616d656c20436c7574636820616e642073747265746368656420686973206261636b206c696b653c42523e6d6f746865726675636b696e272062756e676565206a756d703c42523e5741414141414148213c42523e284d75736963204375747320746f2056696f6c656e74204a293c42523e49276d2056696f6c656e74204a206261636b20746f206d616b6520796f7520736d696c65206d6f72653c42523e49206c6574206d79206e75747361636b2064726167206f6e207468652074696c6520666c6f6f723c42523e49206b69636b2066726565207374796c65732c20666f72206d696c65733c42523e4d7920676f6c6420636f6d657320696e2070696c65732c204920776f726b6564206f6e2042656c6c2049736c652e2e2e3c42523e49207069636b6564207570206465657220736869742c20616e64206e6f772049207370697420726170732e2e2e3c42523e4920736e617020796f7572206e65636b2e2e2e3c42523e274361757365206d7920667265657374796c6573206172652066726573682e2e2e3c42523e28446f6f72204f70656e732c20636c6f73657329, 1164682597, 0);
INSERT INTO `music_songs` VALUES (455, 1256, 1256, 'Papercut', 'songs/125601 Papercut.mp3', '', 1164689686, 1);
INSERT INTO `music_songs` VALUES (456, 1256, 1256, 'Pushing Me Away', 'songs/125612 Pushing Me Away.mp3', '', 1164689962, 0);
INSERT INTO `music_songs` VALUES (457, 1256, 1256, 'From The Inside', 'songs/125610 From The Inside.mp3', '', 1164690122, 0);
INSERT INTO `music_songs` VALUES (458, 1256, 1256, 'Numb', 'songs/125613 Numb.mp3', '', 1164690273, 0);
INSERT INTO `music_songs` VALUES (459, 1257, 1257, 'Out Of My Way', 'songs/1257Out Of My Way.mp3', '', 1164691336, 1);
INSERT INTO `music_songs` VALUES (460, 1257, 1251, 'Out Of My Way', 'songs/1257Out Of My Way.mp3', '', 1164691336, 0);
INSERT INTO `music_songs` VALUES (462, 1258, 1258, 'Watch Ya Back', 'songs/125814 Watch Ya Back.mp3', '', 1164692791, 0);
INSERT INTO `music_songs` VALUES (463, 1258, 1258, 'Take A Bath', 'songs/125820 Take A Bath.mp3', '', 1164692971, 0);
INSERT INTO `music_songs` VALUES (464, 1258, 1258, 'The Munchies', 'songs/125817 The Munchies.mp3', '', 1164693166, 0);
INSERT INTO `music_songs` VALUES (465, 1257, 1257, 'Another Letter', 'songs/125703 Another Letter.mp3', '', 1164696013, 0);
INSERT INTO `music_songs` VALUES (466, 1259, 1259, '', 'songs/1259diamonds are a girls best friend.ram', '', 1164725915, 1);
INSERT INTO `music_songs` VALUES (475, 1237, 1237, 'sitting waiting wishing', 'songs/1237sitting, waiting, wishing.mp3', '', 1164743700, 1);
INSERT INTO `music_songs` VALUES (471, 1260, 1260, 'everytime the beat drop', 'songs/126001 every time the beat drop.m4a', '', 1164740745, 1);
INSERT INTO `music_songs` VALUES (472, 1261, 1261, 'Rollin''', 'songs/126117 Rollin''.mp3', '', 1164740800, 0);
INSERT INTO `music_songs` VALUES (473, 1253, 1260, 'Lets Go All The Way', 'songs/1253Lets Go All The Way.mp3', '', 1164677928, 0);
INSERT INTO `music_songs` VALUES (474, 1163, 1260, 'Sweet Sacrifice', 'songs/1163Sweet Sacrifice.mp3', '', 1158768756, 0);
INSERT INTO `music_songs` VALUES (499, 1280, 1280, 'Animal I Have Become', 'songs/128003 Animal I Have Become.mp3', '', 1164945065, 1);
INSERT INTO `music_songs` VALUES (477, 1250, 1250, 'cotton candy  popcicles', 'songs/1250112-insane_clown_posse-cotton_candy_and_popsicles_(filthee_immigrants_remix).mp3', '', 1164817424, 1);
INSERT INTO `music_songs` VALUES (479, 1267, 1267, 'You Are', 'songs/1267YouAre.mp3', '', 1164820682, 1);
INSERT INTO `music_songs` VALUES (481, 1268, 1268, 'Home', 'songs/1268Micheal Buble - Home.mp3', '', 1164821005, 1);
INSERT INTO `music_songs` VALUES (490, 1241, 1241, 'Happens All The Time', 'songs/1241Happens All The Time.mp3', '', 1164908904, 1);
INSERT INTO `music_songs` VALUES (484, 1251, 1251, 'For You', 'songs/125106 For You.mp3', '', 1164892466, 0);
INSERT INTO `music_songs` VALUES (485, 1273, 1273, 'Bottom of a Bottle', 'songs/127301 Bottom Of A Bottle.mp3', '', 1164903357, 1);
INSERT INTO `music_songs` VALUES (486, 1273, 1273, 'Silouettes', 'songs/127302 Silhouettes.mp3', '', 1164903541, 0);
INSERT INTO `music_songs` VALUES (487, 1273, 1273, 'The Other Side', 'songs/127308 The Other Side.mp3', '', 1164903730, 0);
INSERT INTO `music_songs` VALUES (488, 1273, 1273, 'I Want My Life', 'songs/127313 I Want My Life.mp3', '', 1164904011, 0);
INSERT INTO `music_songs` VALUES (489, 1273, 1269, 'Bottom of a Bottle', 'songs/127301 Bottom Of A Bottle.mp3', '', 1164903357, 0);
INSERT INTO `music_songs` VALUES (491, 1241, 1241, 'Happens All The Time', 'songs/1241Happens All The Time.mp3', '', 1164908951, 0);
INSERT INTO `music_songs` VALUES (498, 1272, 1272, '', 'songs/127211 TEENAGERS.mp3', '', 1164922110, 1);
INSERT INTO `music_songs` VALUES (493, 1237, 1237, 'deer dance', 'songs/1237systemDeer Dance.mp3', '', 1164916047, 0);
INSERT INTO `music_songs` VALUES (494, 1279, 1279, 'Pass The Axe', 'songs/127914 Pass The Axe.mp3', '', 1164916735, 1);
INSERT INTO `music_songs` VALUES (495, 1279, 1279, 'Juggalo Family', 'songs/1279Juggalo Family.mp3', '', 1164916904, 0);
INSERT INTO `music_songs` VALUES (496, 1279, 1279, 'Headache', 'songs/1279Headache.mp3', '', 1164917048, 0);
INSERT INTO `music_songs` VALUES (497, 1279, 1279, 'Graverobbers', 'songs/127922 Graverobbers.mp3', '', 1164917364, 0);
INSERT INTO `music_songs` VALUES (500, 1280, 1280, 'Never Too Late', 'songs/128004 Never Too Late.mp3', '', 1164945223, 0);
INSERT INTO `music_songs` VALUES (501, 1280, 1280, 'Riot', 'songs/128006 Riot.mp3', '', 1164945397, 0);
INSERT INTO `music_songs` VALUES (502, 1280, 1280, 'Gone Forever', 'songs/128011 Gone Forever.mp3', '', 1164945564, 0);
INSERT INTO `music_songs` VALUES (503, 1280, 1251, 'Never Too Late', 'songs/128004 Never Too Late.mp3', '', 1164945223, 0);
INSERT INTO `music_songs` VALUES (512, 1263, 1263, 'Inward Singing', 'songs/126309 - Tenacious D - Inward Singing.mp3', '', 1165001284, 1);
INSERT INTO `music_songs` VALUES (504, 1258, 1258, '420', 'songs/1258Kotton Mouth Kings - 420.mp3', '', 1164964413, 0);
INSERT INTO `music_songs` VALUES (505, 1258, 1258, 'Where''s The Weed At', 'songs/1258Kottonmouth Kings - Where''s the Weed At.mp3', '', 1164964535, 0);
INSERT INTO `music_songs` VALUES (506, 1279, 1266, 'Pass The Axe', 'songs/127914 Pass The Axe.mp3', '', 1164916735, 0);
INSERT INTO `music_songs` VALUES (509, 1284, 1284, 'Closer To Habit', 'songs/1284Closer To Habit.mp3', '', 1164997446, 1);
INSERT INTO `music_songs` VALUES (508, 1280, 1282, 'Riot', 'songs/128006 Riot.mp3', '', 1164945397, 1);
INSERT INTO `music_songs` VALUES (510, 1276, 1276, '', 'songs/1276seether.mp3', '', 1164997542, 1);
INSERT INTO `music_songs` VALUES (511, 1284, 1251, 'Closer To Habit', 'songs/1284Closer To Habit.mp3', '', 1164997446, 1);
INSERT INTO `music_songs` VALUES (513, 1263, 1263, 'Oxy Cotton  Lil Wyte', 'songs/1263LilWyteOxyCotton.mp3', '', 1165001466, 0);
INSERT INTO `music_songs` VALUES (514, 1284, 1244, 'Closer To Habit', 'songs/1284Closer To Habit.mp3', '', 1164997446, 0);
INSERT INTO `music_songs` VALUES (515, 1263, 1244, 'Inward Singing', 'songs/126309 - Tenacious D - Inward Singing.mp3', '', 1165001284, 0);
INSERT INTO `music_songs` VALUES (516, 1268, 1268, 'Lap dance', 'songs/1268N.E.R.D. - Lapdance.mp3', '', 1165088453, 0);
INSERT INTO `music_songs` VALUES (517, 1288, 1288, 'Lingerie', 'songs/128804 Lingerie.mp3', '', 1165096835, 1);
INSERT INTO `music_songs` VALUES (518, 1163, 1291, 'Sweet Sacrifice', 'songs/1163Sweet Sacrifice.mp3', '', 1158768756, 0);
INSERT INTO `music_songs` VALUES (519, 1284, 1291, 'Closer To Habit', 'songs/1284Closer To Habit.mp3', '', 1164997446, 0);
INSERT INTO `music_songs` VALUES (520, 1233, 1233, 'Magic Ninjas', 'songs/1233ICP & Twiztid - Magic Ninjas.mp3', '', 1165276820, 0);
INSERT INTO `music_songs` VALUES (521, 1272, 1272, '', 'songs/127207 dance with the devil.mp3', '', 1165281650, 0);
INSERT INTO `music_songs` VALUES (522, 1167, 1201, 'ya ne budu s toboi', 'songs/1167Janebudustoboi.mp3', '', 1158633936, 0);
INSERT INTO `music_songs` VALUES (523, 1256, 1292, 'Pushing Me Away', 'songs/125612 Pushing Me Away.mp3', '', 1164689962, 0);
INSERT INTO `music_songs` VALUES (524, 1201, 1201, 'serdce magnit', 'songs/1201sogdiana_serdce_magnit.mp3', '', 1165439625, 1);
INSERT INTO `music_songs` VALUES (526, 1296, 1296, 'Skit pt1', 'songs/1296Skit (pt.1).mp3', '', 1165797517, 0);
INSERT INTO `music_songs` VALUES (527, 1296, 1296, 'I Wouldn''t Even Know', 'songs/1296I Wouldn''t Even Know.mp3', '', 1165797755, 0);
INSERT INTO `music_songs` VALUES (528, 1233, 1233, 'Drive Thru', 'songs/123302-Drive_Thru-PRM.mp3', '', 1165975406, 0);
INSERT INTO `music_songs` VALUES (529, 172, 1017, 'Armin Buren Shivers', 'songs/17203-shivers-armin.mp3', '', 0, 0);
INSERT INTO `music_songs` VALUES (530, 1298, 1298, '', 'songs/129807 Like a Pen.wma', '', 1166165797, 1);
INSERT INTO `music_songs` VALUES (531, 895, 1105, 'clova ya teba lyublu', 'songs/895Track05.mp3', '', 1152658423, 0);
INSERT INTO `music_songs` VALUES (532, 1305, 1305, 'Za Steklom', 'songs/1305Reznik___Za_Steklom.mp3', '', 1166837693, 1);
INSERT INTO `music_songs` VALUES (533, 1305, 1305, 'Monolog', 'songs/1305monolog.mp3', '', 1166838032, 0);
INSERT INTO `music_songs` VALUES (534, 1305, 1305, 'Vyhod', 'songs/1305vyhod.mp3', '', 1166838261, 0);
INSERT INTO `music_songs` VALUES (535, 1305, 1305, 'Muza', 'songs/1305Muza.mp3', '', 1166838455, 0);
INSERT INTO `music_songs` VALUES (537, 1314, 1314, 'ATB  9pm', 'songs/1314ATB - 9PM (Till I Come).mp3', '', 1168090979, 0);
INSERT INTO `music_songs` VALUES (538, 1314, 1314, 'ATC  Around the World', 'songs/1314ATC - Around The World.mp3', '', 1168091157, 0);
INSERT INTO `music_songs` VALUES (539, 1253, 1329, 'Lets Go All The Way', 'songs/1253Lets Go All The Way.mp3', '', 1164677928, 0);
INSERT INTO `music_songs` VALUES (540, 1280, 1329, 'Riot', 'songs/128006 Riot.mp3', '', 1164945397, 0);
INSERT INTO `music_songs` VALUES (546, 907, 1329, 'its all for U', 'songs/907Janet Jackson - ALL 4 U (1).mp3', '', 1152463024, 0);
INSERT INTO `music_songs` VALUES (541, 1252, 1331, 'Freaking Out', 'songs/125204 Freaking Out.mp3', '', 1164649822, 0);
INSERT INTO `music_songs` VALUES (542, 1273, 1328, 'Silouettes', 'songs/127302 Silhouettes.mp3', '', 1164903541, 0);
INSERT INTO `music_songs` VALUES (543, 1280, 1328, 'Animal I Have Become', 'songs/128003 Animal I Have Become.mp3', '', 1164945065, 1);
INSERT INTO `music_songs` VALUES (547, 1136, 1329, 'Aerials', 'songs/1136System Of A Down - Aerials.mp3', '', 1157214847, 1);
INSERT INTO `music_songs` VALUES (548, 1338, 1338, '', 'songs/1338Russian- palets pistolet rmx.mp3', '', 1169801505, 1);
INSERT INTO `music_songs` VALUES (549, 1324, 1324, 'a un minuto de ti', 'songs/1324mikel erentxun - a un minuto de ti(2).mp3', '', 1170041767, 1);
INSERT INTO `music_songs` VALUES (550, 812, 938, 'Anubi  Kai Pilnaties Akis', 'songs/81204 kai pilnaties akis uzmerks mirtis ii.mp3', '', 1147986472, 0);
INSERT INTO `music_songs` VALUES (551, 1026, 1026, 'macksim', 'songs/1026041. MAKSIM - TRUDNII VOZRAST.mp3', '', 1173404245, 1);

-- --------------------------------------------------------

-- 
-- Table structure for table `news`
-- 

CREATE TABLE `news` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `news_heading` varchar(255) NOT NULL default '',
  `posted_on` varchar(255) NOT NULL default '',
  `news_body` blob NOT NULL,
  `news_thumbnail` varchar(255) NOT NULL default '',
  `views` int(10) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) TYPE=MyISAM  AUTO_INCREMENT=2 ;

-- 
-- Dumping data for table `news`
-- 

INSERT INTO `news` VALUES (1, 'Test News', '06-02-2006 9:33:24', 0x54657374206e6577735c2773, 'news/1_news_90998.jpg', 0);

-- --------------------------------------------------------

-- 
-- Table structure for table `online_now`
-- 

CREATE TABLE `online_now` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `start_time` varchar(255) NOT NULL default '',
  `ip_address` varchar(255) NOT NULL default '',
  `member_id` int(10) NOT NULL default '0',
  `status` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`id`)
) TYPE=MyISAM  AUTO_INCREMENT=6449 ;

-- 
-- Dumping data for table `online_now`
-- 

INSERT INTO `online_now` VALUES (6448, '20060830080752', '85.202.196.79', 153, '1');

-- --------------------------------------------------------

-- 
-- Table structure for table `packages`
-- 

CREATE TABLE `packages` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `pack_name` varchar(255) NOT NULL default '',
  `price` double(10,2) NOT NULL default '0.00',
  `allowed_mods` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`id`)
) TYPE=MyISAM  AUTO_INCREMENT=4 ;

-- 
-- Dumping data for table `packages`
-- 

INSERT INTO `packages` VALUES (2, 'Free', 0.00, 'Search,Mails,Browse,Bulletin,Journal,Address Book,Blogs,Classified');

-- --------------------------------------------------------

-- 
-- Table structure for table `pages`
-- 

CREATE TABLE `pages` (
  `page_id` int(10) unsigned NOT NULL auto_increment,
  `about_us` blob,
  `advertising_page` blob,
  `music_features` blob NOT NULL,
  `sponsors` blob NOT NULL,
  `help` blob NOT NULL,
  `admin_message` blob NOT NULL,
  UNIQUE KEY `page_id` (`page_id`)
) TYPE=MyISAM  AUTO_INCREMENT=2 ;

-- 
-- Dumping data for table `pages`
-- 

INSERT INTO `pages` VALUES (1, 0x54686973206973206120746573742e2e2e20617364617364, '', '', '', 0x54657374, '');

-- --------------------------------------------------------

-- 
-- Table structure for table `photo_rating`
-- 

CREATE TABLE `photo_rating` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `photo_id` int(10) NOT NULL default '0',
  `member_id` int(10) NOT NULL default '0',
  `rating` int(10) NOT NULL default '0',
  `comment` blob NOT NULL,
  `posted_by` int(10) NOT NULL default '0',
  `posted_on` varchar(255) NOT NULL default '',
  `approved` tinyint(3) unsigned default '1',
  PRIMARY KEY  (`id`)
) TYPE=MyISAM AUTO_INCREMENT=740 ;

-- 
-- Dumping data for table `photo_rating`
-- 

INSERT INTO `photo_rating` VALUES (3, 103, 93, 5, 0x41524520594f5520464f52525245414c4c4c4c4c4c4c4c4c4c4c21, 89, '01/05/2006', 1);
INSERT INTO `photo_rating` VALUES (24, 109, 96, 5, 0x546861742070696320697320736f2067616e6773746120736f6e21206c6f6c200d0a, 331, '03/19/2006', 1);
INSERT INTO `photo_rating` VALUES (5, 108, 86, 5, 0x4f6d6720752064617420636f6f6c206e696767612066726f6d20436c6f756420392e2e2e2e43616e20776520626520667269656e6473, 90, '01/06/2006', 1);
INSERT INTO `photo_rating` VALUES (6, 126, 85, 1, 0x4f4d47204954532056494e2044494553454c, 90, '01/15/2006', 1);
INSERT INTO `photo_rating` VALUES (7, 125, 106, 1, 0x4f68682064616d6e2e2e7468617473207468652062617274656e6465722066726f6d2053544556454e534f4e2056494c4c4147452e2e2e0d0a0d0a54686973206d616e20697320434f4f4c, 90, '01/16/2006', 1);
INSERT INTO `photo_rating` VALUES (8, 268, 85, 1, 0x44616d6e20686f77206d616e792064756465732066697420696e746f207375636820612074696768742073706f742e2e2e2e696d207375726520752073617369736b6920747269656420697420616c6c72656164792e2e2e0d0a0d0a0d0a486f6c6c6172696e67206174206d6120746875676767, 90, '02/23/2006', 1);
INSERT INTO `photo_rating` VALUES (9, 92, 90, 1, 0x6d756767696e20696e206120646966666572656e7420646972656374696f6e207468616e2065766572796f6e6520656c7365203d2074687567676973680d0a686176696e207961746f7a686527732068616e64206e65787420746f20796f7572206661636520203d206e6f74207468756767697368, 85, '02/25/2006', 1);
INSERT INTO `photo_rating` VALUES (10, 94, 90, 1, 0x6c6574206d652073656520796f7572206964202d206974277320323020646f6c6c61727320746f2067657420696e20616e64206e6f20746f756368696e6720746865206c6164696573, 85, '02/25/2006', 1);
INSERT INTO `photo_rating` VALUES (11, 85, 82, 1, 0x20497320736865207265616c2c206f7220616e20696d6167696e61727920667269656e643f, 196, '03/02/2006', 1);
INSERT INTO `photo_rating` VALUES (12, 109, 96, 1, 0x476172792d2061726520796f752072756e6e696e672077697468207468652027646f677327203b29, 206, '03/03/2006', 1);
INSERT INTO `photo_rating` VALUES (13, 259, 91, 1, 0x686f77206d616e792067616e67737461732063616e20796f752070757420696e206f6e6520706963206265666f7265207468652063616d6572612067657473206172726573746564, 85, '03/09/2006', 1);
INSERT INTO `photo_rating` VALUES (14, 161, 121, 1, 0x576f772e2e2e20696e746572657374696e672070686f746f2121, 280, '03/11/2006', 1);
INSERT INTO `photo_rating` VALUES (15, 351, 296, 1, 0x44617a616161616d6d20706c6179612075206c6f6f6b206c696b652074686973206b69642069206b6e6f772e2e2e486973206e616d6520697320534841594d2e2e2e2e4c656f6e2064617420697373, 90, '03/14/2006', 1);
INSERT INTO `photo_rating` VALUES (16, 327, 253, 1, 0x4f68682073686974206c6f77666174206f6e20737465726f696473, 90, '03/14/2006', 1);
INSERT INTO `photo_rating` VALUES (17, 109, 96, 1, 0x7175696e74657373656e7469616c2050494d5020, 333, '03/16/2006', 1);
INSERT INTO `photo_rating` VALUES (18, 420, 374, 5, 0x79756c6963686b6120796f7520686f742063796b6120796f752772652073686f77696e6720736f206d75636820636c65617661676565656565652075686820686f74746965200d0a0d0a6c6f766520796f752063796b61, 376, '03/18/2006', 1);
INSERT INTO `photo_rating` VALUES (19, 418, 376, 5, 0x646f726f67617961206e656c6c7921212121212121210d0a0d0a6f6d66672075206c6f6f6b20736f20686f747420686572652e0d0a0d0a73657878696920617373206a65616e732e0d0a0d0a6d7761682e, 374, '03/18/2006', 1);
INSERT INTO `photo_rating` VALUES (20, 421, 376, 5, 0x6f6d6720692061646f7265207468652065617272696e67732e206b726173617669747361206e656c6c792d2069206675636b696e67206c6f766520752e0d0a0d0a7e2079756c6963686b61, 374, '03/18/2006', 1);
INSERT INTO `photo_rating` VALUES (21, 103, 93, 1, 0x44616d6e206d616d692e2e2e2e2e2e2e2e2e6d6d6d6d6d2061206c6f74206f662063757276657320616e64204920646f6e27742068617665206272616b657321212121, 382, '03/19/2006', 1);
INSERT INTO `photo_rating` VALUES (22, 102, 92, 1, 0x6d6d6d6d6d6d20796f752061726520746865207065726665637420776f6d656e2e2e2e2e2e233130202e2e204920616d203130302520636f6e76696e6365, 382, '03/19/2006', 1);
INSERT INTO `photo_rating` VALUES (23, 420, 374, 1, 0x796f7520646f6e74206c69766520696e20636c6576656c616e6464206c6d616f6f6f6f6f6f6f6f6f6f6f6f6f6f20, 376, '03/19/2006', 1);
INSERT INTO `photo_rating` VALUES (25, 457, 85, 1, 0x576f772077686f2069732074686174206372617a79206d6f666f20696e206461206261636b2e2e2e2e6f6868207368697420697473206d652e2e2e0d0a0d0a486f6c6c612061742064612062697264206d616e20, 90, '03/19/2006', 1);
INSERT INTO `photo_rating` VALUES (26, 453, 85, 1, 0x776f7720494d2067616e67737461, 90, '03/19/2006', 1);
INSERT INTO `photo_rating` VALUES (27, 443, 85, 1, 0x536b69696969696920536b69696969696920536b6969696969, 90, '03/19/2006', 1);
INSERT INTO `photo_rating` VALUES (28, 443, 85, 1, 0x41726520796f752067757973206f6e20796f757220776179206261636b2066726f6d207468617420736b6920747269702e2e2e2e2e, 90, '03/19/2006', 1);
INSERT INTO `photo_rating` VALUES (29, 415, 370, 1, 0x69206c6f766520796f7572206861697220636f6c6f722e2e206920616c776179732077616e74656420746f20676f20626c6f6e64652069276d206a757374206e6f7420627261766520656e6f756768, 376, '03/20/2006', 1);
INSERT INTO `photo_rating` VALUES (30, 438, 85, 1, 0x7761736e74206d65, 106, '03/20/2006', 1);
INSERT INTO `photo_rating` VALUES (31, 489, 370, 1, 0x7572207368697274206c6f6f6b7320737061726b6c792074686174277320686f74, 376, '03/20/2006', 1);
INSERT INTO `photo_rating` VALUES (32, 407, 342, 1, 0x502049204d2050, 376, '03/21/2006', 1);
INSERT INTO `photo_rating` VALUES (33, 103, 93, 1, 0x74686174206c6f6f6b73206c696b6520612068656c6c206f662061207061696e66756c20776564676965, 376, '03/21/2006', 1);
INSERT INTO `photo_rating` VALUES (34, 218, 97, 1, 0x74686174277320736f6f206375746520, 376, '03/22/2006', 1);
INSERT INTO `photo_rating` VALUES (35, 243, 91, 1, 0x736d6f6b696e672069736e7420676f6f6420666f7220796f7520286f3b, 376, '03/22/2006', 1);
INSERT INTO `photo_rating` VALUES (36, 100, 91, 1, 0x6e6f772074686174277320612070696d7020686174, 376, '03/22/2006', 1);
INSERT INTO `photo_rating` VALUES (37, 143, 113, 1, 0x69742073617973206f6e207572207468696e672075722061206d616c652e2e206275742074686973207069637475726520697320646566696e65746c792061206769726c206861686120286f3b, 376, '03/22/2006', 1);
INSERT INTO `photo_rating` VALUES (38, 531, 428, 1, 0x75206b6e6f20692063616e20736565207572206e6970706c6573, 376, '03/22/2006', 1);
INSERT INTO `photo_rating` VALUES (39, 437, 388, 1, 0x6e6f772074686174277320616e20696e74696d69646174696e6720706963747572650d0a, 376, '03/22/2006', 1);
INSERT INTO `photo_rating` VALUES (40, 420, 374, 1, 0x776520646f6e74206c69766520696e20636c6561766c616e642064756d6279207765206c69766520696e206265656368776f6f64646464646464642072696368206269746368657320726570726573656e7420, 376, '03/23/2006', 1);
INSERT INTO `photo_rating` VALUES (41, 418, 376, 1, 0x69206c696b652075722073756e676c6173736573, 428, '03/23/2006', 1);
INSERT INTO `photo_rating` VALUES (42, 532, 428, 1, 0x796f75206b6e6f772c20796f752062656172206120535452494b494e4720726573656d626c616e636520746f2041647269616e61204c696d612e0d0a0d0a48617320616e796f6e65206576657220746f6c6420796f75207468617420796f75206c6f6f6b206c696b65206865723f, 374, '03/23/2006', 1);
INSERT INTO `photo_rating` VALUES (43, 418, 376, 1, 0x6d6d6d6d6d6d6d6d6d6d6d206261627920796f75206c6f6f6b206c696b652061206d6f7669652073746172742e2e2e2e2e2e2e2e206b6565702069742075702120204920776f756c6420766f746520666f7220796f7521202020202020206a6f65, 382, '03/23/2006', 1);
INSERT INTO `photo_rating` VALUES (44, 418, 376, 1, 0x6d6d6d6d6d6d6d6d6d6d6d206261627920796f75206c6f6f6b206c696b652061206d6f7669652073746172742e2e2e2e2e2e2e2e206b6565702069742075702120204920776f756c6420766f746520666f7220796f7521202020202020206a6f65, 382, '03/23/2006', 1);
INSERT INTO `photo_rating` VALUES (45, 478, 396, 1, 0x4d79206661766f726974652070696374757265206f6620796f75210d0a796f75206c6f6f6b652042656175746966756c0d0a49206c6f766520796f753c33, 395, '03/24/2006', 1);
INSERT INTO `photo_rating` VALUES (46, 574, 370, 1, 0x54686973206973207375636820612063757465207069632120596f7572207265616c6c79207072657474792d20616e6420692061646f7265207468652073686972742e, 374, '03/24/2006', 1);
INSERT INTO `photo_rating` VALUES (47, 264, 118, 5, 0x5768617473207570204e61746173686b6973206b616b2064656c612c2049206a75737420666f756e642074686973207369746520686176656e74206d6164652070726f66696c652079657420, 491, '03/26/2006', 1);
INSERT INTO `photo_rating` VALUES (48, 279, 177, 5, 0x57484154535353535320555020697473206d65204745524b41204c4f4c204920686176656e74206d6164652070726f66696c6520796574203a292929292929292929, 491, '03/26/2006', 1);
INSERT INTO `photo_rating` VALUES (49, 115, 100, 5, 0x594f552041524520534f204f4646204d59204255444459204c495354204c4f4c4c4c4c4c4c4c4c204a4b205748415453205550505050505050, 491, '03/26/2006', 1);
INSERT INTO `photo_rating` VALUES (50, 603, 512, 5, 0x486920686f772061726520753f2075206c6f6f6b2074616e2c207520676f2074616e6e696e3f, 491, '03/28/2006', 1);
INSERT INTO `photo_rating` VALUES (51, 116, 100, 1, 0x4352554e4b20210d0a0d0a6861686168610d0a0d0a6d6d6d6d6d2064616161616161, 118, '03/28/2006', 1);
INSERT INTO `photo_rating` VALUES (52, 582, 482, 1, 0x486d6d20666f7220736f6d6520726561736f6e207468697320706963206c6f6f6b7320736f2066616d696c69617220646f2069206b6e6f7720796f752066726f6d20736f6d6577686572652c206974206d7573742062652074686520636f77626f7920686174203a29, 127, '03/28/2006', 1);
INSERT INTO `photo_rating` VALUES (53, 420, 374, 1, 0x75206c6f6f6b207265616c6c792070726574747921, 395, '03/29/2006', 1);
INSERT INTO `photo_rating` VALUES (54, 550, 395, 5, 0x796f75206b6e6f207572207265616c6c792070726574747920286f3a, 376, '03/30/2006', 1);
INSERT INTO `photo_rating` VALUES (61, 413, 331, 0, 0x4e6963652062696b652e20487920676465207a6865206e6173687565, 656, '04/08/2006', 1);
INSERT INTO `photo_rating` VALUES (56, 654, 588, 5, 0x6177736f6d652069206c6f7665206974207520706c7379206775697461723f207468617473206177736f6d652077656c6c20627965206279657a7a7a206d79206465617220667269656e6420, 572, '04/04/2006', 1);
INSERT INTO `photo_rating` VALUES (57, 664, 82, 0, 0x74657374, 342, '04/05/2006', 1);
INSERT INTO `photo_rating` VALUES (62, 421, 376, 0, 0x596f75206172652073756368206120686f747469652c20627574204920677565737320796f75206b6e6577207468617420616c7265616479203b2920, 206, '04/10/2006', 1);
INSERT INTO `photo_rating` VALUES (60, 656, 206, 0, 0x757220766572792070726574747920286f3a, 376, '04/06/2006', 1);
INSERT INTO `photo_rating` VALUES (63, 327, 253, 0, 0x776f726b6f7574206d7563683f21, 376, '04/10/2006', 1);
INSERT INTO `photo_rating` VALUES (64, 710, 96, 0, 0x6568682074686f7365207368616479205275737369616e732e2e2e, 662, '04/11/2006', 1);
INSERT INTO `photo_rating` VALUES (65, 683, 634, 0, 0x6f68207520677579732121206e69636520706963203a2029, 177, '04/12/2006', 1);
INSERT INTO `photo_rating` VALUES (66, 683, 634, 0, 0x6f68207520677579732121206e69636520706963203a2029, 177, '04/12/2006', 1);
INSERT INTO `photo_rating` VALUES (67, 683, 634, 0, 0x692064756e6e6f2077687920697420706f737465642074776963652e2e2e2e203e3a6f, 177, '04/12/2006', 1);
INSERT INTO `photo_rating` VALUES (68, 712, 96, 0, 0x6841684120226c6f6f6b206f662061207479706963616c207275737369616e20677579223f, 177, '04/12/2006', 1);
INSERT INTO `photo_rating` VALUES (69, 733, 700, 0, 0x796f752073686f756c6420757365207468697320706963747572650d0a687474703a2f2f7075626c69632e666f746b692e636f6d2f6b6163796e6472612f323030362f686f7573657372657374617572616e74732f38626a66662f70333235303033382e68746d6c0d0a68656865203a290d0a796f75204d722e205365787920796f7521, 673, '04/12/2006', 1);
INSERT INTO `photo_rating` VALUES (70, 736, 705, 0, 0x6e696365207069632e20206769726c7320696e2074686520736f757468207265616c6c79206b6e6f7720686f7720746f2064726573732075703a29, 96, '04/13/2006', 1);
INSERT INTO `photo_rating` VALUES (71, 731, 695, 0, 0x6b696473207468657365206461797320617265207665727920616476616e6365642e202073746172742073757266696e67207275737369616e2073697465732061742061207665727920796f756e67206167653a29, 96, '04/13/2006', 1);
INSERT INTO `photo_rating` VALUES (72, 713, 683, 0, 0x746869732070696374757265206a757374206d616b6573206d65206665656c207761726d20616e642066757a7a7920696e736964653a29, 96, '04/13/2006', 1);
INSERT INTO `photo_rating` VALUES (73, 701, 652, 0, 0x616c6c2074686174206d696c6b206973207265616c6c7920776f726b696e6720666f7220796f753a29, 96, '04/13/2006', 1);
INSERT INTO `photo_rating` VALUES (74, 701, 652, 0, 0x616c6c2074686174206d696c6b206973207265616c6c7920776f726b696e6720666f7220796f753a29, 96, '04/13/2006', 1);
INSERT INTO `photo_rating` VALUES (75, 723, 693, 0, 0x596f75206c6f6f6b207265616c6c7920626f726564203d2920, 206, '04/17/2006', 1);
INSERT INTO `photo_rating` VALUES (76, 663, 600, 0, 0x7375706572, 745, '04/19/2006', 1);
INSERT INTO `photo_rating` VALUES (77, 394, 351, 0, 0x6c6f76656c79, 745, '04/19/2006', 1);
INSERT INTO `photo_rating` VALUES (78, 762, 743, 0, 0x61732061207265616c20776f6d656e, 745, '04/19/2006', 1);
INSERT INTO `photo_rating` VALUES (79, 312, 164, 0, 0x596f7520676f74206e69636520706963732e20496c6c206769766520796f7520612063616c6c20696620492064656369646520746f206d6f766520746f20466c6f726964612e20476f6f64204c75636b, 754, '04/20/2006', 1);
INSERT INTO `photo_rating` VALUES (80, 333, 262, 0, 0x57686174732055702c204e696365207069632e204920616d2066726f6d2073656174746c6520746f6f, 754, '04/21/2006', 1);
INSERT INTO `photo_rating` VALUES (81, 767, 748, 0, 0x6772656174207069632e20627261766f20746f2070686f746f6772617068657220616e642068617473206f666620666f722061206d6f64656c3a29, 143, '04/21/2006', 1);
INSERT INTO `photo_rating` VALUES (82, 418, 376, 0, 0x4e6f7420737572652077686174732063757465722c20746865206a65616e73206f722074686520736d696c652e, 91, '04/21/2006', 1);
INSERT INTO `photo_rating` VALUES (83, 92, 90, 0, 0x44696d6120736169643a206d756767696e20696e206120646966666572656e7420646972656374696f6e207468616e2065766572796f6e6520656c7365203d20746875676769736820686176696e207961746f7a686527732068616e64206e65787420746f20796f75722066616365203d206e6f742074687567676973680d0a0d0a416666612061646465643a20486176696e6720426f72697320646f20746865204d616b6572656e61206e65787420746f20796f75207768696c6520796f75277265206c6f6f6b696e6720617420736f6d6520647564652064616e63696e67207769746820796f7572206769726c667269656e642c20414c534f206e6f742054687567676973682e, 91, '04/21/2006', 1);
INSERT INTO `photo_rating` VALUES (84, 94, 90, 0, 0x57617463686f75742050612d5368657965206564796f742e, 91, '04/21/2006', 1);
INSERT INTO `photo_rating` VALUES (85, 95, 90, 0, 0x4e6f2073686f7274616765206f66207361757361676520617420746869732062617262656375652e, 85, '04/23/2006', 1);
INSERT INTO `photo_rating` VALUES (86, 323, 85, 0, 0x594f2c2057484f5320544845204641542044554445204e45585420544f20553f, 88, '04/24/2006', 1);
INSERT INTO `photo_rating` VALUES (87, 797, 85, 0, 0x63616e20796f75207361792033726420776865656c3f, 90, '04/24/2006', 1);
INSERT INTO `photo_rating` VALUES (88, 796, 85, 0, 0x616e7920636c6f73657220616e642069642073656520796f757220627261696e2e0d0a0d0a0d0a502e532e206973207468617420666565206665652066726f6d20414320696e20746865206261636b67726f756e643f, 90, '04/24/2006', 1);
INSERT INTO `photo_rating` VALUES (89, 443, 85, 0, 0x506c65617365206d6f7665206261636b2066726f6d207468652043414d455241212121212121, 90, '04/24/2006', 1);
INSERT INTO `photo_rating` VALUES (90, 803, 630, 0, 0x4f79206d616d6f63686b692c206b616b796120736865207663652074616b752073706f6f6b69207069637475726521, 552, '04/24/2006', 1);
INSERT INTO `photo_rating` VALUES (91, 687, 630, 0, 0x4f6368656e27206d65727a6b6f21, 552, '04/24/2006', 1);
INSERT INTO `photo_rating` VALUES (92, 675, 491, 0, 0x486d6d20476572612120436f6f6c204261636b67726f756e6421, 630, '04/25/2006', 1);
INSERT INTO `photo_rating` VALUES (93, 675, 491, 0, 0x486d6d20476572612120436f6f6c204261636b67726f756e6421, 630, '04/25/2006', 1);
INSERT INTO `photo_rating` VALUES (94, 712, 96, 0, 0x49206c696b6520746861742070696320, 206, '04/26/2006', 1);
INSERT INTO `photo_rating` VALUES (95, 656, 206, 0, 0x616161616161616168206b61616161616b616161617961207a68656565656e7368696e6121212121, 634, '05/06/2006', 1);
INSERT INTO `photo_rating` VALUES (96, 656, 206, 0, 0x616161616161616168206b61616161616b616161617961207a68656565656e7368696e6121212121, 634, '05/06/2006', 1);
INSERT INTO `photo_rating` VALUES (97, 802, 630, 0, 0x6b72757461796120666f746b6121, 673, '05/09/2006', 1);
INSERT INTO `photo_rating` VALUES (98, 708, 673, 0, 0x49206c696b652074686973207069637475726520746f6f2120536f20706f6574696321, 630, '05/09/2006', 1);
INSERT INTO `photo_rating` VALUES (99, 708, 673, 0, 0x49206c696b652074686973207069637475726520746f6f2120536f20706f6574696321, 630, '05/09/2006', 1);
INSERT INTO `photo_rating` VALUES (100, 630, 552, 0, 0x54616b61796120707279616d6f20536c6164656e6b6179612120426c696e206e75206b616b6f69207a686520796120786f726f7368696920666f746f6772617068204d617421, 630, '05/11/2006', 1);
INSERT INTO `photo_rating` VALUES (101, 631, 552, 0, 0x412065746f20796120747974207669706c7961736976617521, 630, '05/11/2006', 1);
INSERT INTO `photo_rating` VALUES (102, 633, 552, 0, 0x4f682074686973206973205374617273636170652121212120526974612063616e2070617274792077697468206d6521212121, 630, '05/11/2006', 1);
INSERT INTO `photo_rating` VALUES (103, 636, 552, 0, 0x546869732070696374757265206973207265746172646564205768792061726520796f752073696465776179733f207065726570696c61206368746f6c69213f0d0a49206276617320706f206d6f656d752076696e6f73796174206e6f67616d6920767065726564210d0a54616b206465727a68617421, 630, '05/11/2006', 1);
INSERT INTO `photo_rating` VALUES (104, 643, 552, 0, 0x536b6f74696e6121204f68206c6f6f6b20616e64207468657265206973206d6520696e2074686520636f726e65722120416c7761797320696e207468652064616d6e20636f726e657221, 630, '05/11/2006', 1);
INSERT INTO `photo_rating` VALUES (105, 660, 552, 0, 0x312e20647572610d0a322e647572610d0a332e20647572610d0a0d0a33206465766963692079206b6c75626521206d616d61, 630, '05/11/2006', 1);
INSERT INTO `photo_rating` VALUES (106, 819, 552, 0, 0x4d792068616972206c6f6f6b7320736f206e69636521205468616e6b732052697461210d0a0d0a502e732e0d0a736865206973206d7920706572736f6e616c2068616972207374796c69737420706c6561736520646f206e6f7420626f746865722068657221, 630, '05/11/2006', 1);
INSERT INTO `photo_rating` VALUES (107, 820, 552, 0, 0x566f207061726f63684b61202e2e2e2e2e2e2e2e2e2e206964696f746f76, 630, '05/11/2006', 1);
INSERT INTO `photo_rating` VALUES (108, 821, 552, 0, 0x4120747574206368746f2063206e696d3f, 630, '05/11/2006', 1);
INSERT INTO `photo_rating` VALUES (109, 822, 552, 0, 0x56737961206f626361726170616e617961206275742069207374696c6c206469646e2774206c6f6f7365206d79207363656e6365206f662068756d6f72210d0a526974612064756920736b6f74696e61206974206875727473, 630, '05/11/2006', 1);
INSERT INTO `photo_rating` VALUES (110, 850, 552, 0, 0x5061726163686b6120616c6b6f676f6c696b6f762c206e6f20646f766f6c6e6f2073696d7061746963686e697821, 630, '05/11/2006', 1);
INSERT INTO `photo_rating` VALUES (111, 849, 552, 0, 0x412065746f206e6520706f20727573736b692120596120766f74206e65207a6170697661752c20786f747961207961206465767573686b61207072696c6963686e6179612c2074616b206368746f20796120696e6f676461207a616b7573697661752e2e2e20736f6c656e656e6b696d6920706f6d69646f726368696b616d6921, 630, '05/11/2006', 1);
INSERT INTO `photo_rating` VALUES (117, 858, 630, 0, 0x41206e6f677520746f2061206e6f677521, 552, '05/11/2006', 1);
INSERT INTO `photo_rating` VALUES (113, 823, 552, 0, 0x476f726920676f7269207961736e6f2c206368746f6269206e6520706f6761736c6f0d0a0d0a4e616d206b7572697420786f6368657473796121206b616b6f6920797a68617321, 630, '05/11/2006', 1);
INSERT INTO `photo_rating` VALUES (114, 852, 552, 0, 0x566f646b61206e612079617a696b20706f70616c61206e617665726e6f65206e657a6e61752e204174207468697320706f696e7420692070726f6261626c7920206469646e2774206361726521, 630, '05/11/2006', 1);
INSERT INTO `photo_rating` VALUES (115, 835, 552, 0, 0x566f742073756b692c2070726f76616c69766169746520732062617261206365696368617a68207a686521, 630, '05/11/2006', 1);
INSERT INTO `photo_rating` VALUES (116, 851, 552, 0, 0x53746f79617420626f6c736865206e65206d6f67752e205a61746f206d6f67752076657a7469206d617368696e7521, 630, '05/11/2006', 1);
INSERT INTO `photo_rating` VALUES (118, 686, 630, 0, 0x4b595a454e4b49206d6f692e, 552, '05/11/2006', 1);
INSERT INTO `photo_rating` VALUES (119, 854, 630, 0, 0x4f6669676574272c207663652062726f6361656d207075742721204365676f646e612e20506f63746176206374616b616e206e61206d6563746f21212121212121212121213131, 552, '05/11/2006', 1);
INSERT INTO `photo_rating` VALUES (120, 857, 630, 0, 0x4120766f74207520416c65782e20506f7a6e616b6f6d756c61206e61206b6f6e657a746f2e20, 552, '05/11/2006', 1);
INSERT INTO `photo_rating` VALUES (121, 689, 630, 0, 0x47657265206e61646f207962726174272063766f7520677279617a6e696520727963686b692e20, 552, '05/11/2006', 1);
INSERT INTO `photo_rating` VALUES (122, 856, 630, 0, 0x54656275206e652074657a656c6f3f, 552, '05/11/2006', 1);
INSERT INTO `photo_rating` VALUES (123, 832, 630, 0, 0x506f6e6f633f20756c75207a61706f723f206d6e65207a766f6e7573682c64613f, 552, '05/11/2006', 1);
INSERT INTO `photo_rating` VALUES (124, 810, 630, 0, 0x4a696e676c654a696e676c65204a696e676c652042656c6c732e2e2e2e4d592041535321, 552, '05/11/2006', 1);
INSERT INTO `photo_rating` VALUES (125, 843, 206, 0, 0x736c6f766e6f206b616b206e61206b617274696e652121203a2d29, 634, '05/12/2006', 1);
INSERT INTO `photo_rating` VALUES (126, 884, 342, 0, 0x6f792d204d6f74726f6379206b616d65727920626f6c736865206e652064617661742721, 552, '05/17/2006', 1);
INSERT INTO `photo_rating` VALUES (127, 736, 705, 0, 0x64616d6e20752066696e650d0a, 813, '05/23/2006', 1);
INSERT INTO `photo_rating` VALUES (128, 368, 320, 0, 0x6769726c20796f7520676f6e6e612073686f7720736f6d65206d6f72653f, 813, '05/23/2006', 1);
INSERT INTO `photo_rating` VALUES (129, 163, 122, 0, 0x75206c6f6f6b20676f6f640d0a, 825, '06/01/2006', 1);
INSERT INTO `photo_rating` VALUES (130, 915, 85, 0, 0x677272722e2e2e3b29, 206, '06/11/2006', 1);
INSERT INTO `photo_rating` VALUES (131, 920, 539, 0, 0x56657279206e69636520706963747572652e2049742073686f777320612073656e7369746976652073696465203a29, 536, '06/19/2006', 1);
INSERT INTO `photo_rating` VALUES (132, 924, 539, 0, 0x20224d722e20436f6f6c2220204e69636520706963204f6c65672e203a29, 536, '06/19/2006', 1);
INSERT INTO `photo_rating` VALUES (133, 937, 850, 0, 0x486920446172696e6120796f7520617265207265616c6c7920686f74202e204d79206e616d6520697320416c65782049276d203232207965617273206f6c642049206c69766520696e204c6f7320416e67656c657320416e642049276d206c6f6b696e6720666f72206e657720667269656e647320616e64206d61796265206d6f72652e20536f20696620796f757220696e74657265737465642073656e64206d652061206d657373616765202e2064617320766964616e796168, 761, '06/27/2006', 1);
INSERT INTO `photo_rating` VALUES (134, 951, 552, 0, 0x6c6f766520746861742070686f746f206f6620796f7572732e2e2e766572792073657879203d2920, 206, '07/02/2006', 1);
INSERT INTO `photo_rating` VALUES (135, 937, 850, 0, 0x596f752061726520736f2062656175746966756c, 206, '07/02/2006', 1);
INSERT INTO `photo_rating` VALUES (136, 951, 552, 0, 0x496e746572657374696e672e2c2c2c2c2c2c76657279207665727920696e746572657374696e672e2e2e2e2e2e697320746861742066696c7961732062617468207475623f0d0a, 90, '07/02/2006', 1);
INSERT INTO `photo_rating` VALUES (137, 963, 856, 0, 0x7468697320697320736f206375757575757575746521, 867, '07/07/2006', 1);
INSERT INTO `photo_rating` VALUES (138, 1026, 886, 0, 0x6c6f6f6b206174207468617420736578696920617373207275737369616e2f706f6c697368206769726c20266865617273743b20, 860, '07/07/2006', 1);
INSERT INTO `photo_rating` VALUES (139, 998, 867, 0, 0x766572792063757465206c6f766520746865206f7574666974, 885, '07/08/2006', 1);
INSERT INTO `photo_rating` VALUES (140, 976, 858, 0, 0x617777772074686973206973207468652073776565747374207069637475726520616e64207520626f7468206c6f6f6b20736f20707265747479, 885, '07/08/2006', 1);
INSERT INTO `photo_rating` VALUES (141, 977, 858, 0, 0x617777777720746861747320736f2063757465203a2029, 885, '07/08/2006', 1);
INSERT INTO `photo_rating` VALUES (142, 986, 858, 0, 0x746861747320737563682061202063757465207069637475726520616e642074686174732074686520434f4f4c5354202062656172206976652065766572207365656e20, 885, '07/08/2006', 1);
INSERT INTO `photo_rating` VALUES (143, 996, 867, 0, 0x7072657474792063757465212121, 813, '07/08/2006', 1);
INSERT INTO `photo_rating` VALUES (144, 1010, 871, 0, 0x63757465203a29, 813, '07/08/2006', 1);
INSERT INTO `photo_rating` VALUES (145, 1050, 903, 0, 0x6f6f6f207468617473206b6f6f6c20212121205b266865617274733b5d, 883, '07/08/2006', 1);
INSERT INTO `photo_rating` VALUES (146, 966, 860, 0, 0x53657878696920686169723c62723e0d0a486f7474205069633c62723e270d0a4a756c6961266865617274733b, 886, '07/08/2006', 1);
INSERT INTO `photo_rating` VALUES (147, 1037, 894, 0, 0x73756368206120707265747479207069637475726520616e642069207265616c6c79206c696b652075722068616972207468617473206120636f6f6c20616e676c652032, 885, '07/08/2006', 1);
INSERT INTO `photo_rating` VALUES (148, 1021, 883, 0, 0x637574652070696374757265203a29, 865, '07/08/2006', 1);
INSERT INTO `photo_rating` VALUES (149, 1021, 883, 0, 0x6f6f6f20746861747320636f6f6c21, 903, '07/09/2006', 1);
INSERT INTO `photo_rating` VALUES (150, 1022, 885, 0, 0x6177777777777720736f6f6f6f206375746521, 867, '07/09/2006', 1);
INSERT INTO `photo_rating` VALUES (151, 1040, 813, 0, 0x486f7420626f7921, 867, '07/09/2006', 1);
INSERT INTO `photo_rating` VALUES (152, 1036, 885, 0, 0x41777720746861747320736f2073776565742e205468617420646f67206b696e6461206c6f6f6b73206c696b65206120776f6c662074686f7567682e2e2e686168610d0a427574206974732061207665727920637574652070696374757265203d44, 894, '07/09/2006', 1);
INSERT INTO `photo_rating` VALUES (153, 993, 857, 0, 0x44414d4e20555220484f542e202623313039303b2623313039393b202623313037353b2623313037323b2623313038383b2623313037323b2623313039353b2623313130333b2e, 804, '07/10/2006', 1);
INSERT INTO `photo_rating` VALUES (154, 995, 857, 0, 0x5365786920706963, 804, '07/10/2006', 1);
INSERT INTO `photo_rating` VALUES (155, 995, 857, 0, 0x5365786920706963, 804, '07/10/2006', 1);
INSERT INTO `photo_rating` VALUES (156, 1110, 857, 0, 0x416c6c20757220706963732061726520686f747420, 804, '07/10/2006', 1);
INSERT INTO `photo_rating` VALUES (157, 1101, 857, 0, 0x757220736f20707265747479, 804, '07/10/2006', 1);
INSERT INTO `photo_rating` VALUES (158, 1091, 923, 0, 0x6861686120646f726b21203c33, 925, '07/10/2006', 1);
INSERT INTO `photo_rating` VALUES (159, 1128, 900, 0, 0x564552592053455859204c4f5649474e2054484520524544204c4950535449434b204d554141414141414141415a, 932, '07/10/2006', 1);
INSERT INTO `photo_rating` VALUES (160, 1105, 925, 0, 0x61777720697320746869732061206261627920706963747572653f20796f75207765726520736f6f6f6f6f6f6f206375746521212121203d29, 923, '07/10/2006', 1);
INSERT INTO `photo_rating` VALUES (161, 1040, 813, 0, 0x4e69636520706963266865617274733b, 857, '07/10/2006', 1);
INSERT INTO `photo_rating` VALUES (162, 886, 804, 0, 0x4e69636520706963266865617274733b, 857, '07/10/2006', 1);
INSERT INTO `photo_rating` VALUES (163, 1072, 908, 0, 0x6e6f74206f6e6c7920617265207765207275737369616e206275742077652061726520616c736f2062616c64, 923, '07/10/2006', 0);
INSERT INTO `photo_rating` VALUES (164, 1109, 857, 0, 0x465245414b494e2042454155544946554c, 804, '07/10/2006', 1);
INSERT INTO `photo_rating` VALUES (165, 975, 858, 0, 0x61777777207520616e64207572207377656574206c6974746c652070757070792069206c6f76652074686973207069632069747320736f206375746520617777772069206c6f7665206869732066616365203a2029, 885, '07/10/2006', 1);
INSERT INTO `photo_rating` VALUES (166, 970, 858, 0, 0x6a75737420676f7267656f7573, 885, '07/10/2006', 1);
INSERT INTO `photo_rating` VALUES (167, 978, 858, 0, 0x746f2063757465212069732074686174207572206775792074686174207520776572652074656c6c696e67206d652061626f75743f, 885, '07/10/2006', 1);
INSERT INTO `photo_rating` VALUES (168, 971, 858, 0, 0x6c7576206d79207477696e203c33, 885, '07/10/2006', 1);
INSERT INTO `photo_rating` VALUES (169, 972, 858, 0, 0x7572206f6c642061706172746d656e74206c6f6f6b73207665727920637574722069206c696b65207468617420626c756520746561207365742074696c65207468696e6720696e20746865206261636b726f756e64, 885, '07/10/2006', 1);
INSERT INTO `photo_rating` VALUES (170, 973, 858, 0, 0x69206c6f766520746861742064726573732075206c6f6f6b20736f2070726574747920616e642075722068616972207665727920637574650d0a70726f737461207072696e6365737361, 885, '07/10/2006', 1);
INSERT INTO `photo_rating` VALUES (171, 974, 858, 0, 0x617777207520616e64207572206d6f6d207265616c6c79206c6f6f6b206c696b65207477696e73203a2029, 885, '07/10/2006', 1);
INSERT INTO `photo_rating` VALUES (172, 979, 858, 0, 0x5275737369616e2070726f6d206c6f6f6b7320736f206d75636820626574746572207468616e207468652070726f6d73207765206861766520696e20466c6f7269646120616e64207520626f7468206c6f6f6b206a75737420676f7267656f7573, 885, '07/10/2006', 1);
INSERT INTO `photo_rating` VALUES (173, 980, 858, 0, 0x6177777777206265737420667269656e6473203465766572203a2029, 885, '07/11/2006', 1);
INSERT INTO `photo_rating` VALUES (174, 981, 858, 0, 0x7468617420697320736f2063757465207520616c6c206c6f6f6b206c696b65206d6f64656c73, 885, '07/11/2006', 1);
INSERT INTO `photo_rating` VALUES (175, 983, 858, 0, 0x5945414141414120424553542050494320455645522121212121, 885, '07/11/2006', 1);
INSERT INTO `photo_rating` VALUES (176, 985, 858, 0, 0x6865797979797979206920686176652074686f7365206a65616e73203a2029, 885, '07/11/2006', 1);
INSERT INTO `photo_rating` VALUES (177, 987, 858, 0, 0x53204e6f766f6d20476f6f6472656d21212121, 885, '07/11/2006', 1);
INSERT INTO `photo_rating` VALUES (178, 894, 813, 0, 0x796f75206c6f6f6b20746972656420212121205b266865617274733b5d, 856, '07/11/2006', 1);
INSERT INTO `photo_rating` VALUES (179, 1040, 813, 0, 0x63757465202121205b266865617274733b5d, 856, '07/11/2006', 1);
INSERT INTO `photo_rating` VALUES (180, 937, 850, 0, 0x6177206375746520736d696c65, 923, '07/11/2006', 1);
INSERT INTO `photo_rating` VALUES (181, 1129, 933, 0, 0x4c6f6f6b696e672020676f6f6420206769726c2e2e, 938, '07/11/2006', 1);
INSERT INTO `photo_rating` VALUES (182, 1177, 940, 0, 0x6e696365202064616e63652c2c2c, 938, '07/11/2006', 1);
INSERT INTO `photo_rating` VALUES (183, 1198, 947, 0, 0x576f772e2e2e686f772064696420796f75206d616e61676520746861743f, 206, '07/11/2006', 1);
INSERT INTO `photo_rating` VALUES (184, 1200, 949, 0, 0x4c4f4f4b494e472020474f4f44, 938, '07/11/2006', 1);
INSERT INTO `photo_rating` VALUES (185, 1165, 930, 0, 0x68657920686579206865792077686f207220552074616c6b696e6720544f206875683f3f, 951, '07/11/2006', 1);
INSERT INTO `photo_rating` VALUES (186, 1164, 930, 0, 0x75686868206c61206c612d2d6d792032206c6974746c652068617774206d616d617321210d0a6c6f6f6b696e6720676f6f64206775726c7973210d0a0d0a6c75762079610d0a0d0a3d5d, 951, '07/11/2006', 1);
INSERT INTO `photo_rating` VALUES (187, 1207, 951, 0, 0x776164647570206e6967676121, 930, '07/11/2006', 1);
INSERT INTO `photo_rating` VALUES (188, 1237, 964, 0, 0x75206861766520616e20757368657220706f737465722069206c6f7665207573686572212121, 956, '07/11/2006', 1);
INSERT INTO `photo_rating` VALUES (189, 1246, 966, 0, 0x616c6c206f6620796f752067757973206c6f6f6b20736f20434f6f6c2e2e2e2e657370656369616c6c79204a75656c65737e6c6f6c, 930, '07/11/2006', 1);
INSERT INTO `photo_rating` VALUES (190, 1177, 940, 0, 0x7468617420776173206f6e652066756e2f6372617a792064616e6365206875683f0d0a0d0a6c6f6c2e2e2e6c75762079613d44, 951, '07/11/2006', 1);
INSERT INTO `photo_rating` VALUES (191, 1226, 959, 0, 0x6261627920626162792062616279, 972, '07/11/2006', 1);
INSERT INTO `photo_rating` VALUES (192, 929, 206, 0, 0x646f6e74206576612074616b65207468697320706963206f66662c20697473206d79206661766f7269746520706963203a2d29, 634, '07/11/2006', 1);
INSERT INTO `photo_rating` VALUES (193, 1208, 955, 0, 0x4177652c20596f75204c6f6f6b20476f7267656f75732e, 974, '07/11/2006', 1);
INSERT INTO `photo_rating` VALUES (194, 1249, 961, 0, 0x776f7720796f75206c6f6f6b207265616c6c79206375746521, 966, '07/11/2006', 1);
INSERT INTO `photo_rating` VALUES (195, 1277, 950, 0, 0x647564652e2e2072207520737572652075722031353f206c6f6c, 903, '07/12/2006', 1);
INSERT INTO `photo_rating` VALUES (196, 1275, 950, 0, 0x6973207468617420757220667269656e64206f72207369733f, 903, '07/12/2006', 1);
INSERT INTO `photo_rating` VALUES (197, 1273, 950, 0, 0x776f77202062656175746966756c6c, 938, '07/12/2006', 1);
INSERT INTO `photo_rating` VALUES (198, 1235, 958, 0, 0x776f772e2e2e2e2063757465206c6f6f6b696e, 942, '07/12/2006', 1);
INSERT INTO `photo_rating` VALUES (199, 1243, 966, 0, 0x657777777777777777206c6f6c, 961, '07/12/2006', 1);
INSERT INTO `photo_rating` VALUES (200, 886, 804, 0, 0x68657920686579206865792074686572650d0a0d0a6c6f6f6b696e20676f640d0a0d0a3d44, 951, '07/12/2006', 1);
INSERT INTO `photo_rating` VALUES (201, 886, 804, 0, 0x686579206865790d0a596f75206c6f6f6b20637574657e0d0a3a29, 930, '07/12/2006', 1);
INSERT INTO `photo_rating` VALUES (202, 1039, 813, 0, 0x6e696365207368616465730d0a3d5d, 951, '07/12/2006', 1);
INSERT INTO `photo_rating` VALUES (203, 1294, 994, 0, 0x6375746520706963203d29, 930, '07/12/2006', 1);
INSERT INTO `photo_rating` VALUES (204, 1207, 951, 0, 0x686579207520646f6e74206c6f6f6b206c696b6520757273656c662c2c2062757420706c6561736520646f6e7420676574206d6164206174206d652e2e20627574206375746520616e797761797a21206c6f6c, 903, '07/12/2006', 1);
INSERT INTO `photo_rating` VALUES (205, 1206, 916, 0, 0x66756e6e202121205b266865617274733b5d, 856, '07/12/2006', 1);
INSERT INTO `photo_rating` VALUES (206, 1294, 994, 0, 0x6c6f7665207468697320706978206f66207961202e2e686f7474202121205b266865617274733b5d, 856, '07/12/2006', 1);
INSERT INTO `photo_rating` VALUES (207, 1166, 938, 0, 0x692075736520746f20706c617920746865207069616e6f2e2e2e2077656c6c20692071756974652061207768696c652061676f2e2e2e62757420676f6f6420666f72207961202e2e2e6c6f6b6b696e6720676f6f64202121205b266865617274733b5d, 883, '07/12/2006', 1);
INSERT INTO `photo_rating` VALUES (208, 1244, 969, 0, 0x6e69636520706963266865617274733b, 857, '07/12/2006', 1);
INSERT INTO `photo_rating` VALUES (209, 1249, 961, 0, 0x6e6f772c20636f756c6420796f752074656c6c206d652077686174207468652073746f7265207365637572697479206469643f, 942, '07/13/2006', 1);
INSERT INTO `photo_rating` VALUES (210, 1250, 961, 0, 0x4f6b2c2049206861766520736978207965617273206f6620626f78696e2e2057616e6e6120676f3f, 942, '07/13/2006', 1);
INSERT INTO `photo_rating` VALUES (211, 1177, 940, 0, 0x41726520796f752074776f20736973746572733f20596f7520626f7468206c6f6f6b207265616c20637574652c2063616e74206c69652e, 942, '07/13/2006', 1);
INSERT INTO `photo_rating` VALUES (212, 1126, 930, 0, 0x4279206661722c20746865206265737420706f736520497665207365656e20776974682061206769726c, 942, '07/13/2006', 1);
INSERT INTO `photo_rating` VALUES (213, 1160, 930, 0, 0x596f75206b6e6f772044656e6e69733f3f20, 942, '07/13/2006', 1);
INSERT INTO `photo_rating` VALUES (214, 1283, 983, 0, 0x446f20796f7520676f20746f204865726974616765204869676820627920616e79206368616e63653f, 942, '07/13/2006', 1);
INSERT INTO `photo_rating` VALUES (215, 1283, 983, 0, 0x446f20796f7520676f20746f204865726974616765204869676820627920616e79206368616e63653f, 942, '07/13/2006', 1);
INSERT INTO `photo_rating` VALUES (216, 1207, 951, 0, 0x6375746520706963, 984, '07/13/2006', 1);
INSERT INTO `photo_rating` VALUES (217, 1275, 950, 0, 0x4f6c6961206c6f6f6b7320746f20436f6f6c20696e206d79206a65616e7a7e0d0a6c6f6c0d0a686568650d0a49202623393832393b20796f7520746f6f7e, 930, '07/13/2006', 1);
INSERT INTO `photo_rating` VALUES (218, 1273, 950, 0, 0x616c6c20746865207069637320796f752068617665206f66206f6c69612e20736865732077656172696e206d5920636c6f7468657a7e0d0a686168616861686168616861686168610d0a566c61642044756465206c6f6f6b204d7920467269656e6473204c4f564520594f557e, 930, '07/13/2006', 1);
INSERT INTO `photo_rating` VALUES (219, 1040, 813, 0, 0x796f75722068616972206c6f6f6b732066616b65206a6b202c627574207365726575736c79, 805, '07/13/2006', 1);
INSERT INTO `photo_rating` VALUES (220, 1111, 857, 0, 0x64616e6720796f75206c6f6f6b20676f6f6421212120776861742063617220697320646174, 813, '07/13/2006', 1);
INSERT INTO `photo_rating` VALUES (221, 994, 857, 0, 0x796f75206c6f6f6b20736f20637574652121212120696d20736572696f757321, 813, '07/13/2006', 1);
INSERT INTO `photo_rating` VALUES (222, 965, 857, 0, 0x62656175746966756c, 813, '07/13/2006', 1);
INSERT INTO `photo_rating` VALUES (223, 1246, 966, 0, 0x68657920696d206f6e20746865726520746f6f2e2e2e6c6f6c, 951, '07/13/2006', 1);
INSERT INTO `photo_rating` VALUES (224, 1284, 984, 0, 0x6c6f6f6b696e20676f6f64, 951, '07/13/2006', 1);
INSERT INTO `photo_rating` VALUES (225, 1250, 961, 0, 0x616e642077686f20776f6e3f3f3f, 951, '07/13/2006', 1);
INSERT INTO `photo_rating` VALUES (226, 1182, 942, 0, 0x68657979790d0a0d0a646f6e742066616c6c0d0a0d0a6b6b3f0d0a0d0a6c6f6c, 951, '07/13/2006', 1);
INSERT INTO `photo_rating` VALUES (227, 1024, 860, 0, 0x63757465, 813, '07/13/2006', 1);
INSERT INTO `photo_rating` VALUES (228, 1207, 951, 0, 0x7265616c6c792063757465203a29, 813, '07/13/2006', 1);
INSERT INTO `photo_rating` VALUES (229, 1089, 918, 0, 0x6375746520616e64207072657474792121, 813, '07/13/2006', 1);
INSERT INTO `photo_rating` VALUES (230, 1235, 958, 0, 0x796f752061726520746865206d6f737420676f7267656f757320616e642062656175746966756c206769726c206f6e2074686973207468696e672121203a29, 813, '07/13/2006', 1);
INSERT INTO `photo_rating` VALUES (231, 1029, 890, 0, 0x6e6963652073776561746572210d0a0d0a556b7261494e4520414c6c206461205741590d0a0d0a686568653d5d, 951, '07/13/2006', 1);
INSERT INTO `photo_rating` VALUES (232, 1311, 998, 0, 0x686579206b7261736176697473610d0a0d0a6c7576207572207069632e2e2e736f2061646f7261626c653d5d, 951, '07/13/2006', 1);
INSERT INTO `photo_rating` VALUES (233, 963, 856, 0, 0x7572205665727920637574652e2e20746f20626164207572206f6e6c792031352074686f2e2e20627574207374696c6c206375746520696e206d7920657965732e, 176, '07/13/2006', 1);
INSERT INTO `photo_rating` VALUES (234, 1294, 994, 0, 0x6d6d6d6d6d6d266865617274733b, 857, '07/13/2006', 1);
INSERT INTO `photo_rating` VALUES (235, 1319, 1007, 0, 0x6177772069207265616c6c79206c696b65207468697320706963206f6620796f75203c3333, 857, '07/13/2006', 1);
INSERT INTO `photo_rating` VALUES (236, 1039, 813, 0, 0x5468616e6b7320342074686520636f6d6d656e742e20596f75206c6f6f6b207665727920637574652061732077656c6c7e203a29, 958, '07/13/2006', 1);
INSERT INTO `photo_rating` VALUES (237, 1179, 942, 0, 0x486f6c6c6973746572203d204c305645206e69636520706963, 860, '07/14/2006', 1);
INSERT INTO `photo_rating` VALUES (238, 1185, 942, 0, 0x646f6e27742066616c6c2021, 860, '07/14/2006', 1);
INSERT INTO `photo_rating` VALUES (239, 1330, 951, 0, 0x6e6e6e6e6e6e64616161616161616161, 930, '07/14/2006', 1);
INSERT INTO `photo_rating` VALUES (240, 1181, 942, 0, 0x6577777777207775742061726520796f75206472696e6b696e673f0d0a4f722069732074686174206120444f473f7e0d0a3a290d0a6a6b, 930, '07/14/2006', 1);
INSERT INTO `photo_rating` VALUES (241, 1186, 942, 0, 0x6f206c61206c6120686f772073636172797e7e7e7e7e, 930, '07/14/2006', 1);
INSERT INTO `photo_rating` VALUES (242, 1185, 942, 0, 0x686f77206d7563682064696420796f75206a756d703f, 930, '07/14/2006', 1);
INSERT INTO `photo_rating` VALUES (243, 1184, 942, 0, 0x4455444520697320746861742057617368696e67746f6e2044433f0d0a6c6f6c, 930, '07/14/2006', 1);
INSERT INTO `photo_rating` VALUES (244, 1182, 942, 0, 0x556d6d6d6d6d6d20692063616e20646f207468617420746f6f21, 930, '07/14/2006', 1);
INSERT INTO `photo_rating` VALUES (245, 1352, 860, 0, 0x68616861204d6172696e6b61206e6173746f796173636861796120727573736b6179612064657663686f6e6b613c62723e0d0a4a756c6961266865617274733b, 886, '07/14/2006', 1);
INSERT INTO `photo_rating` VALUES (246, 1334, 857, 0, 0x63757465, 813, '07/14/2006', 1);
INSERT INTO `photo_rating` VALUES (247, 1157, 856, 0, 0x637574652e0d0a3a5d, 964, '07/14/2006', 1);
INSERT INTO `photo_rating` VALUES (248, 1353, 860, 0, 0x6e696365206475646520692068617665207468652073616d652070696320646969732063617220697320612070696d7020796f, 956, '07/15/2006', 1);
INSERT INTO `photo_rating` VALUES (249, 1207, 951, 0, 0x596f7572205072657474793a29, 991, '07/15/2006', 1);
INSERT INTO `photo_rating` VALUES (250, 1222, 956, 0, 0x7468617420697320616e20617765736f6d652070696374757265, 907, '07/15/2006', 1);
INSERT INTO `photo_rating` VALUES (251, 1373, 956, 0, 0x6e6963652067686574746f207374796c65, 907, '07/15/2006', 1);
INSERT INTO `photo_rating` VALUES (252, 985, 858, 0, 0x746861747320637574652c2076657279206e61747572616c206c6f6f6b696e67, 907, '07/15/2006', 1);
INSERT INTO `photo_rating` VALUES (253, 1385, 1020, 0, 0x63757469652e203b5d, 890, '07/15/2006', 1);
INSERT INTO `photo_rating` VALUES (254, 1375, 956, 0, 0x2e2e696620697420636f6d657320696e2070696e6b2c2049274c4c2054414b4520495420212121202e2e2e205b266865617274733b5d, 856, '07/16/2006', 1);
INSERT INTO `photo_rating` VALUES (255, 1371, 956, 0, 0x6c6f76652074686973207069632e2e746f74617920686f7474202121205b266865617274733b5d, 856, '07/16/2006', 1);
INSERT INTO `photo_rating` VALUES (256, 1158, 856, 0, 0x75206c6f6f6b20736f206d6973746572696f757320696e2074686973207069632069207265616c6c79206c696b65206974206c6f6f6b696e6720686177742121, 956, '07/16/2006', 1);
INSERT INTO `photo_rating` VALUES (257, 963, 856, 0, 0x69207265616c6c79206c696b65207468697320706963206974206c6f6f6b73206c696b652075722073686f6f74696e67206120766964656f206f7220736f6d657468696e67, 956, '07/16/2006', 1);
INSERT INTO `photo_rating` VALUES (258, 1022, 885, 0, 0x49206c6f7665207468736920706963747572652c207572207368697274206d617463686573207572206861697220616e6420796f7520617265206c6f6f6b696e672042454155544946554c21212121212120, 858, '07/16/2006', 1);
INSERT INTO `photo_rating` VALUES (259, 1033, 885, 0, 0x4c6f7665207468652070696374757265206f6620796f7572206e657720686169722c206275742075206c6f6f6b20736164203a2820, 858, '07/16/2006', 1);
INSERT INTO `photo_rating` VALUES (260, 1034, 885, 0, 0x54686973206d616b6573206d6520676f20686d6d6d6d21204375757575757575746520, 858, '07/16/2006', 1);
INSERT INTO `photo_rating` VALUES (261, 1036, 885, 0, 0x54686973206973207375636820612073776565656574207069637475726520616e6420796f7520686176652074686520737765657465737420646f6721203a2920, 858, '07/16/2006', 1);
INSERT INTO `photo_rating` VALUES (262, 1056, 885, 0, 0x53657879203c3320206c6f766520757220736869727420616e6420796f75722068616972206973206c6f6f6b696e672062656175746966756c20696e20746865206c696768742121212120, 858, '07/16/2006', 1);
INSERT INTO `photo_rating` VALUES (263, 1179, 942, 0, 0x752077616e7465642070656f706c6520746f20636f6d6d656e7420796f757220706963747572657320736f20696d20676f6e6e6120636f6d6d656e742065766572792073696e676c652070696374757265202e2e2e2e6c6f6c2e2e2e2e2075206c6f6f6b207665727920686170707920696e207468697320706963202e2e2e2e6c6f6c2e2e, 865, '07/17/2006', 1);
INSERT INTO `photo_rating` VALUES (264, 1181, 942, 0, 0x686168612e2e2e2e2e766572792077656972642070696374757265203a292069207374696c6c2063616e7420756e6465727374616e6420776861742075207765726520646f696e672e2e2e2e6c6f6c2e2e, 865, '07/17/2006', 1);
INSERT INTO `photo_rating` VALUES (265, 1182, 942, 0, 0x686d6d2e2e2e2e61726520796f752077656172696e6720736f636b73207769746820666c697020666c6f70733f3f20, 865, '07/17/2006', 1);
INSERT INTO `photo_rating` VALUES (266, 1184, 942, 0, 0x76657279206e6963652070696374757265203a29202e2e2e2e77686572652069732069742061743f3f, 865, '07/17/2006', 1);
INSERT INTO `photo_rating` VALUES (267, 1185, 942, 0, 0x69207468696e6b20746865206d6f737420692065766572206a756d706564206f6e207468617420776173206c696b652032202e2e2e2e6c6f6c, 865, '07/17/2006', 1);
INSERT INTO `photo_rating` VALUES (268, 1186, 942, 0, 0x69206c6f7665206c696768746e696e6720627574207468656e20696d20736361726564206f662069742e2e2e2e2e2e2e7765697265642065683f3f20, 865, '07/17/2006', 1);
INSERT INTO `photo_rating` VALUES (269, 420, 374, 0, 0x596f752073686f756c6420706f7574206d6f72652070696373206f6620796f7572732e0d0a, 1020, '07/17/2006', 1);
INSERT INTO `photo_rating` VALUES (270, 1392, 1025, 0, 0x5520676f747a2061206e657720506963747572657e0d0a4375746521, 930, '07/17/2006', 1);
INSERT INTO `photo_rating` VALUES (271, 873, 630, 0, 0x466972737420706963747572652065766572207769746820757320736f6265722120574f57202d73686f6b6572, 552, '07/17/2006', 1);
INSERT INTO `photo_rating` VALUES (272, 886, 804, 0, 0x63757469652e203b5d, 890, '07/17/2006', 1);
INSERT INTO `photo_rating` VALUES (273, 1374, 956, 0, 0x5745737420736964652e2048656c6c2079656168210d0a4e6120746861747320776173206d7920667269656e647320726f6f6d2e2053686527732061206769726c2e, 964, '07/17/2006', 1);
INSERT INTO `photo_rating` VALUES (274, 1287, 989, 0, 0x44616d6e20757220686f74, 804, '07/18/2006', 1);
INSERT INTO `photo_rating` VALUES (275, 1328, 1008, 0, 0x4375746521212121, 916, '07/18/2006', 1);
INSERT INTO `photo_rating` VALUES (276, 1294, 994, 0, 0x6c6f76652065766572797468696e2061626f7574206974, 989, '07/18/2006', 1);
INSERT INTO `photo_rating` VALUES (277, 1337, 1000, 0, 0x776861742020752020676f696e672020736b792020646976696e673f3f, 938, '07/19/2006', 1);
INSERT INTO `photo_rating` VALUES (278, 1405, 1020, 0, 0x796f75206172652068617774203b29, 930, '07/19/2006', 1);
INSERT INTO `photo_rating` VALUES (279, 1414, 930, 0, 0x776f756c64207520706c7a206b696e64206f66206c696b652074616b652074686973207468696e67206f66663f2e2e2e706c7a, 951, '07/19/2006', 1);
INSERT INTO `photo_rating` VALUES (280, 1416, 938, 0, 0x706861742062696b6521, 1000, '07/20/2006', 1);
INSERT INTO `photo_rating` VALUES (281, 1109, 857, 0, 0x64616e6720796f757220736f20676f7267656f757320, 813, '07/20/2006', 1);
INSERT INTO `photo_rating` VALUES (282, 1428, 857, 0, 0x69206c6f766520796f7572207069637320796f757220736f20627565746966756c, 813, '07/20/2006', 1);
INSERT INTO `photo_rating` VALUES (283, 1429, 857, 0, 0x776f77206920776973682069206e65772061206769726c206c696b6520796f7521212121, 813, '07/20/2006', 1);
INSERT INTO `photo_rating` VALUES (284, 1430, 857, 0, 0x74727565207468617473207920692073686f756c642074616b652074686520706c616365206f662074686520626f792077686f2062726f6b6520796f7572206865617274212121206c6f6c, 813, '07/20/2006', 1);
INSERT INTO `photo_rating` VALUES (285, 1236, 964, 0, 0x6e69636865206e65206d6f677520706f6e6a61742720636865206e61706973616e6f206e6120667574626f6c6b652e2e2e20612074616b206f6e6520746a652069646574203b29, 917, '07/21/2006', 1);
INSERT INTO `photo_rating` VALUES (286, 1238, 964, 0, 0x6a6120746f7765206574696d206c6a75626c6a75207a616e696d617427736a61206c6f6c2e2e2e, 917, '07/21/2006', 1);
INSERT INTO `photo_rating` VALUES (287, 1089, 918, 0, 0x3c6120687265663d22687474703a2f2f70686f746f6275636b65742e636f6d22207461726765743d225f626c616e6b223e3c696d67207372633d22687474703a2f2f6934382e70686f746f6275636b65742e636f6d2f616c62756d732f663232382f617368657272696c6c2f36353061303537662e6769662220626f726465723d22302220616c743d2250686f746f6275636b6574202d20566964656f20616e6420496d61676520486f7374696e67223e3c2f613e0d0a4e6963652064726573733a29, 907, '07/22/2006', 1);
INSERT INTO `photo_rating` VALUES (288, 1441, 1046, 0, 0x7665727920707265747479203c333333, 886, '07/22/2006', 1);
INSERT INTO `photo_rating` VALUES (289, 1441, 1046, 0, 0x4e69636520283b, 1000, '07/23/2006', 1);
INSERT INTO `photo_rating` VALUES (290, 1442, 1046, 0, 0x486f7421202838, 1000, '07/23/2006', 1);
INSERT INTO `photo_rating` VALUES (291, 1351, 1013, 0, 0x44616d6e21, 1000, '07/23/2006', 1);
INSERT INTO `photo_rating` VALUES (292, 1413, 930, 0, 0x686579206c6f6f6b206920616d20696e20746861742070696374757265, 1025, '07/25/2006', 1);
INSERT INTO `photo_rating` VALUES (293, 1446, 1050, 0, 0x74686f7773207968696e6773206c6f6f6b2070756e797979797979797979797979792e, 1025, '07/25/2006', 1);
INSERT INTO `photo_rating` VALUES (294, 693, 637, 0, 0x546562650d0a5961206c75626c752074766f69207961736e6965206f6368690d0a49206b6f726f746b796f7520737472697a686b7520766f6c6f730d0a74766f69207961736e696520736c61646b6965206775626b690d0a69206e656d6e6f7a686b6f206b75726e6f736979206e6f730d0a0d0a63686d6f6b69, 900, '07/25/2006', 1);
INSERT INTO `photo_rating` VALUES (295, 1397, 989, 0, 0x637574652050496374757265203a29, 930, '07/25/2006', 1);
INSERT INTO `photo_rating` VALUES (296, 1062, 895, 0, 0x64616d21, 1000, '07/25/2006', 1);
INSERT INTO `photo_rating` VALUES (297, 1313, 1000, 0, 0x686579206973207468617420796f7572206361723f3f206920776f756c642077616e74206d79206e616d65206f6e206d79206c6973656e636520706c61746520616c736f2e2e2e2e70726574747920617765736f6d65203a29, 865, '07/26/2006', 1);
INSERT INTO `photo_rating` VALUES (298, 1483, 865, 0, 0x6861686168612e2e2e6920746f6f6b207468617420706963747572652e2e2e69207468696e6b2074686174206d7920706f736520697320736f6f6f206177736f6d652e2e2069206b6e657720796f7520776f756c64206c696b652069742e2e2e616e64202064696420616c6c206f6620746865206f75746c696e65696e67202e2e2e206f6d6720686f772069206c6f7665206d652068616e647920776f726b2e2e2e2e, 1054, '07/26/2006', 1);
INSERT INTO `photo_rating` VALUES (299, 1474, 1054, 0, 0x706c656173652074656c6c206d6520776879206920616d207375636820612070726f66657373696f6e616c2070686f746f677261706865723f3f3f2068616861, 865, '07/26/2006', 1);
INSERT INTO `photo_rating` VALUES (300, 1475, 1054, 0, 0x6f6b61792e2e2e2073746f702074616c6b696e67206b6172696e6121212e2e2e692063616e7420636f6e63656e7472617465206f66207768617420746f2077726974652e2e2e2e6f6e636520616761696e2e2e2e2e6920616d207375636820616e206172746973742e2e2e2e2e776974686f7574206d6520746865207069637475726520776f756c646e74206576656e20626520736f20676f6f642e2e2e2e2e2e2e6861686168612e2e2e2e0d0a0d0a76657279206375746520706963203a29, 865, '07/26/2006', 1);
INSERT INTO `photo_rating` VALUES (301, 681, 634, 0, 0x4f64657373612d6d616d612e2e2e, 686, '07/27/2006', 1);
INSERT INTO `photo_rating` VALUES (302, 1517, 1069, 0, 0x796f75206c6f6f6b207365636b73692062757420692073656520494c4f4e4121212121212068616861, 1068, '07/28/2006', 1);
INSERT INTO `photo_rating` VALUES (303, 1437, 860, 0, 0x74686174732061207265616c6c79206b757465207069632069206c696b65206974, 956, '07/30/2006', 1);
INSERT INTO `photo_rating` VALUES (304, 1237, 964, 0, 0x776f77207520746f74616c79206c6f6f6b206c696b652068696d20646174732068617774212121, 956, '07/30/2006', 1);
INSERT INTO `photo_rating` VALUES (305, 965, 857, 0, 0x4c6f6f6b696e672020766572792020686f747474, 938, '07/31/2006', 1);
INSERT INTO `photo_rating` VALUES (306, 348, 289, 0, 0x63757465203a29, 1076, '08/01/2006', 1);
INSERT INTO `photo_rating` VALUES (307, 1412, 885, 0, 0x49206c6f76652074686973207069632e2e2e62656175746966756c21212120416e6420746865206c616b6520697320736f20707265747479212054686572652069732061205275737369616e207061696e74696e672074686174206861732061206769726c206c65616e696e6720616761696e7374206120726f636b207468652073616d6520776179203a292120416e642049206c6f766520746865206c616b652e2e2e4920736177206f6e65206a757374206c696b652069742061726f756e642068657265203a2920, 858, '08/02/2006', 1);
INSERT INTO `photo_rating` VALUES (308, 1236, 964, 0, 0x6c6f6f6b696e20676f6f64, 1082, '08/04/2006', 1);
INSERT INTO `photo_rating` VALUES (309, 1294, 994, 0, 0x6c6f6f6b696e20676f6f64, 1082, '08/04/2006', 1);
INSERT INTO `photo_rating` VALUES (310, 1011, 872, 0, 0x697320796f7572206e616d6520696c6c6f6e613f, 1084, '08/05/2006', 1);
INSERT INTO `photo_rating` VALUES (311, 1353, 860, 0, 0x537765617421, 1000, '08/05/2006', 1);
INSERT INTO `photo_rating` VALUES (312, 989, 864, 0, 0x776f77206e6963652070696320796f75206c6f6f6b207365637379, 1026, '08/08/2006', 1);
INSERT INTO `photo_rating` VALUES (313, 1117, 928, 0, 0x6e6f77206e6f772077686f2061726520796f752073686f74696e3f, 1026, '08/09/2006', 1);
INSERT INTO `photo_rating` VALUES (314, 1581, 1093, 0, 0x3c6120687265663d22687474703a2f2f7777772e70696d706d7973706163652e6f72672f6d797370616365676c6974746572746578742e706870223e3c696d67207372633d22687474703a2f2f6d332e70696d706d7973706163652e6f72672f637572736f72732f6c2f31312f762e6769662220626f726465723d22302220616c743d22676c6974746572207465787422202f3e3c2f613e3c6120687265663d22687474703a2f2f7777772e70696d706d7973706163652e6f72672f6d797370616365676c6974746572746578742e706870223e3c696d67207372633d22687474703a2f2f6d332e70696d706d7973706163652e6f72672f637572736f72732f6c2f31312f652e6769662220626f726465723d22302220616c743d22676c6974746572207465787422202f3e3c2f613e3c6120687265663d22687474703a2f2f7777772e70696d706d7973706163652e6f72672f6d797370616365676c6974746572746578742e706870223e3c696d67207372633d22687474703a2f2f6d332e70696d706d7973706163652e6f72672f637572736f72732f6c2f31312f722e6769662220626f726465723d22302220616c743d22676c6974746572207465787422202f3e3c2f613e3c6120687265663d22687474703a2f2f7777772e70696d706d7973706163652e6f72672f6d797370616365676c6974746572746578742e706870223e3c696d67207372633d22687474703a2f2f6d332e70696d706d7973706163652e6f72672f637572736f72732f6c2f31312f792e6769662220626f726465723d22302220616c743d22676c6974746572207465787422202f3e3c2f613e2020202020203c6120687265663d22687474703a2f2f7777772e70696d706d7973706163652e6f72672f6d797370616365676c6974746572746578742e706870223e3c696d67207372633d22687474703a2f2f6d332e70696d706d7973706163652e6f72672f637572736f72732f6c2f31312f702e6769662220626f726465723d22302220616c743d22676c6974746572207465787422202f3e3c2f613e3c6120687265663d22687474703a2f2f7777772e70696d706d7973706163652e6f72672f6d797370616365676c6974746572746578742e706870223e3c696d67207372633d22687474703a2f2f6d332e70696d706d7973706163652e6f72672f637572736f72732f6c2f31312f722e6769662220626f726465723d22302220616c743d22676c6974746572207465787422202f3e3c2f613e3c6120687265663d22687474703a2f2f7777772e70696d706d7973706163652e6f72672f6d797370616365676c6974746572746578742e706870223e3c696d67207372633d22687474703a2f2f6d332e70696d706d7973706163652e6f72672f637572736f72732f6c2f31312f652e6769662220626f726465723d22302220616c743d22676c6974746572207465787422202f3e3c2f613e3c6120687265663d22687474703a2f2f7777772e70696d706d7973706163652e6f72672f6d797370616365676c6974746572746578742e706870223e3c696d67207372633d22687474703a2f2f6d332e70696d706d7973706163652e6f72672f637572736f72732f6c2f31312f742e6769662220626f726465723d22302220616c743d22676c6974746572207465787422202f3e3c2f613e3c6120687265663d22687474703a2f2f7777772e70696d706d7973706163652e6f72672f6d797370616365676c6974746572746578742e706870223e3c696d67207372633d22687474703a2f2f6d332e70696d706d7973706163652e6f72672f637572736f72732f6c2f31312f742e6769662220626f726465723d22302220616c743d22676c6974746572207465787422202f3e3c2f613e3c6120687265663d22687474703a2f2f7777772e70696d706d7973706163652e6f72672f6d797370616365676c6974746572746578742e706870223e3c696d67207372633d22687474703a2f2f6d332e70696d706d7973706163652e6f72672f637572736f72732f6c2f31312f792e6769662220626f726465723d22302220616c743d22676c6974746572207465787422202f3e3c2f613e, 938, '08/12/2006', 1);
INSERT INTO `photo_rating` VALUES (315, 1475, 1054, 0, 0x736f2061727469737469632e2e2e6177736f6d65202121205b266865617274733b5d, 883, '08/13/2006', 1);
INSERT INTO `photo_rating` VALUES (316, 1584, 1093, 0, 0x43757465212121, 916, '08/14/2006', 1);
INSERT INTO `photo_rating` VALUES (317, 1578, 1093, 0, 0x6f6b206920646f6e74207468696e6b20776f7264732063616e206578707265737320776861742069206665656c2061626f7574207468697320706963747572652e2e2e206f6b206920646f6e74207468696e6b20776f7264732063616e206578707265737320776861742069206665656c2061626f7574207468697320706963747572652e2e2e200d0a0d0a796f75722066616365206c6f6f6b7320736d6f6f6f6f6f7468206c696b6520612062616269657320626f6f74792e200d0a0d0a692063616e20676574206c6f737420696e20796f757220657965732e200d0a0d0a796f7572206d616b6520757020697320474f5247454f55532e200d0a0d0a796f7572206c697073206c6f6f6b73204c5543494f55532e200d0a0d0a796f75722068616972206c6f6f6b732048454c4c41204e49434520414e44205348494e59200d0a0d0a616e6420796f757220657965206c617368657320617265206c696b652c20636f6d6d65726369616c207374617475732121200d0a0d0a6675636b2e2e20736f206261736963616c6c792e20796f752061726520746865206d6f73742062656175746966756c206769726c206920686176652065766572207365656e2e20686f77206973207468617420666f72206120636f6d6d656e74212121200d0a, 916, '08/14/2006', 1);
INSERT INTO `photo_rating` VALUES (318, 1580, 1093, 0, 0x476f7267656f757320706963747572652e20412066696e65206769726c2072696768742074686572652e, 916, '08/14/2006', 1);
INSERT INTO `photo_rating` VALUES (319, 1579, 1093, 0, 0x6177777720626162792074686973206973206162736f6c7574656c792061646f7261626c652120, 916, '08/14/2006', 1);
INSERT INTO `photo_rating` VALUES (320, 1582, 1093, 0, 0x796f7527726520637574652c2077686174206d6f72652063616e2069207361793f20, 916, '08/14/2006', 1);
INSERT INTO `photo_rating` VALUES (321, 248, 161, 0, 0x596f75206c6f6f6b206b696e6461204672656e63682e2050726574747920657965732120, 1093, '08/15/2006', 1);
INSERT INTO `photo_rating` VALUES (322, 1021, 883, 0, 0x4f6f6f6820796f7527726520736f2070726574747920, 1093, '08/15/2006', 1);
INSERT INTO `photo_rating` VALUES (323, 1206, 916, 0, 0x4f20776f772074686174206c6f6f6b7320617765736f6d652121204c6f6c2063616c6c206d6520746865206e6578742074696d6520796f7520677579732061726520676f696e6720, 1093, '08/15/2006', 1);
INSERT INTO `photo_rating` VALUES (324, 1088, 916, 0, 0x4e69636520726964652120416c6c204920676574206973206120637261707079202738382063616d72792e2e2e203a28, 1093, '08/15/2006', 1);
INSERT INTO `photo_rating` VALUES (325, 1232, 957, 0, 0x4769726c206973207468617420796f753f20776f7720796f757220676f7267656f75732121, 1093, '08/15/2006', 1);
INSERT INTO `photo_rating` VALUES (326, 434, 153, 0, 0x536f207072657474792120576865726520697320746861743f, 1093, '08/15/2006', 1);
INSERT INTO `photo_rating` VALUES (327, 1214, 955, 0, 0x49207468696e6b20796f7527726520676f6e6e61206d616b6520746865205275737369616e206d61666961206a65616c6f7573, 1093, '08/15/2006', 1);
INSERT INTO `photo_rating` VALUES (328, 1219, 955, 0, 0x42656175746966756c206c616469657320616e6420676f6f642d6c6f6f6b696e672067656e746c656d656e2e2e2e207768617420656c73652063616e2049207361793f20596f75206775797320206c6f6f6b20686f7474, 1093, '08/15/2006', 1);
INSERT INTO `photo_rating` VALUES (329, 1166, 938, 0, 0x53686f772074686174207468696e672077686f27732074686520626f7373206c6f6c, 1093, '08/15/2006', 1);
INSERT INTO `photo_rating` VALUES (330, 1415, 938, 0, 0x77686f732074686520707265747479206c6164793f, 1093, '08/15/2006', 1);
INSERT INTO `photo_rating` VALUES (331, 1578, 1093, 0, 0x48657920506173686121212e2e2079612064756d61752074692062657a75736c6f766e6f20707261762e2e0d0a5072656b7261736e6f6520666f746f2e2e20, 161, '08/15/2006', 1);
INSERT INTO `photo_rating` VALUES (332, 862, 512, 0, 0x7069636b206265747465722067757973206e78742074696d653b205d, 1102, '08/15/2006', 1);
INSERT INTO `photo_rating` VALUES (333, 1593, 1097, 0, 0x6b726173617669747369, 990, '08/16/2006', 1);
INSERT INTO `photo_rating` VALUES (334, 1578, 1093, 0, 0x707265747479, 955, '08/16/2006', 1);
INSERT INTO `photo_rating` VALUES (335, 1580, 1093, 0, 0x646f6e74206675636b2061726f756e642077697468742068652073696c766572206d616e206c6f6c, 955, '08/16/2006', 1);
INSERT INTO `photo_rating` VALUES (336, 1614, 1098, 0, 0x7965616161616821, 1103, '08/17/2006', 1);
INSERT INTO `photo_rating` VALUES (337, 1173, 940, 0, 0x6c6f6f6b696e67207072657474792121, 1073, '08/17/2006', 1);
INSERT INTO `photo_rating` VALUES (338, 1210, 161, 0, 0x412065746f207479206764653f0d0a, 1093, '08/18/2006', 1);
INSERT INTO `photo_rating` VALUES (339, 795, 193, 0, 0x6e69636520636172, 1103, '08/18/2006', 1);
INSERT INTO `photo_rating` VALUES (340, 368, 320, 0, 0x69206c696b652072656421, 1103, '08/18/2006', 1);
INSERT INTO `photo_rating` VALUES (341, 792, 193, 0, 0x68656c6c6f21, 1103, '08/18/2006', 1);
INSERT INTO `photo_rating` VALUES (342, 1614, 1098, 0, 0x696e207468697320706963747572652075206c696b65206f6e65206769726c2069206c696b6520627574206920646f6e2774207468696e6b20736865206c696b6573206d652e205368652069732062656175746966756c21, 1103, '08/18/2006', 1);
INSERT INTO `photo_rating` VALUES (343, 132, 109, 0, 0x486f77647921212121287965612d686129, 1103, '08/18/2006', 1);
INSERT INTO `photo_rating` VALUES (344, 1207, 951, 0, 0x6e69636520666f726573742121212121, 1103, '08/18/2006', 1);
INSERT INTO `photo_rating` VALUES (345, 992, 867, 0, 0x686579212121, 1103, '08/18/2006', 1);
INSERT INTO `photo_rating` VALUES (346, 1154, 923, 0, 0x686579206261627921, 1103, '08/18/2006', 1);
INSERT INTO `photo_rating` VALUES (347, 1091, 923, 0, 0x6363637021212179706121212121210d0a436f6d756e69736d21212121212179706121212121210d0a5374616c696e206c69766521212121212121797061212121212121, 1103, '08/18/2006', 1);
INSERT INTO `photo_rating` VALUES (348, 1395, 989, 0, 0x6e69636521212121, 1103, '08/18/2006', 1);
INSERT INTO `photo_rating` VALUES (349, 1151, 923, 0, 0x2623313035303b2623313034303b2623313035313b2623313036383b2623313037313b2623313035333b2121, 1093, '08/19/2006', 1);
INSERT INTO `photo_rating` VALUES (350, 1091, 923, 0, 0x4343435021212052757373696120344556455221, 1093, '08/19/2006', 1);
INSERT INTO `photo_rating` VALUES (351, 1051, 903, 0, 0x4d6f736b76612e2e2e206f646e6f20697a2073616d7978206b72617369767978206d6573742076206d697265, 1093, '08/19/2006', 1);
INSERT INTO `photo_rating` VALUES (352, 1051, 903, 0, 0x4d6f736b76612e2e2e206f646e6f20697a2073616d7978206b72617369767978206d6573742076206d697265, 1093, '08/19/2006', 1);
INSERT INTO `photo_rating` VALUES (353, 1201, 150, 0, 0x4865792e2e2e2e0d0a4d79206e616d6520697320416c657820746f6f210d0a4861616121, 1103, '08/20/2006', 1);
INSERT INTO `photo_rating` VALUES (354, 1060, 118, 0, 0x6e6963652072656172210d0a576f7721, 1103, '08/20/2006', 1);
INSERT INTO `photo_rating` VALUES (355, 252, 163, 0, 0x59656161612e2e2e2e0d0a5468726565736f6d652c206f756868686821, 1103, '08/20/2006', 1);
INSERT INTO `photo_rating` VALUES (356, 283, 179, 0, 0x6865792c206920776173206c6f6f6b276e20666f72207468656d20657665727977686572652e2e2e2e2e2e0d0a47696d6d79206261636b206d792074726f757365727321212121, 1103, '08/20/2006', 1);
INSERT INTO `photo_rating` VALUES (357, 1272, 980, 0, 0x6e696365206361722e0d0a6d7920676f742073616d65207061696e7420616e64206865696768742c20627574206d796e2069732066617374286e6f74292e0d0a312e38204c202739342065636c697073652047532e0d0a69206c6f766520796f75722072696465212121, 1103, '08/20/2006', 1);
INSERT INTO `photo_rating` VALUES (358, 1584, 1093, 0, 0x574f57212121210d0a41414848482e2e2e2e2e2e2e2e2e0d0a574f5721212121, 1103, '08/20/2006', 1);
INSERT INTO `photo_rating` VALUES (359, 1622, 1106, 0, 0x466c79212121212121, 1103, '08/21/2006', 1);
INSERT INTO `photo_rating` VALUES (360, 549, 395, 0, 0x596561682c206261627920796561682121212121, 1103, '08/21/2006', 1);
INSERT INTO `photo_rating` VALUES (361, 110, 97, 0, 0x447564652c20776865726573206d7920626565723f3f3f, 1103, '08/21/2006', 1);
INSERT INTO `photo_rating` VALUES (362, 1353, 860, 0, 0x447564652c206d7920636172206973206265747465722c20616e642063686561706572212121, 1103, '08/21/2006', 1);
INSERT INTO `photo_rating` VALUES (363, 1352, 860, 0, 0x6865792c206e6f7420666169722e0d0a492077616e7420736f6d652c2073686172696e6720697320636172696e6721, 1103, '08/21/2006', 1);
INSERT INTO `photo_rating` VALUES (364, 1026, 886, 0, 0x484579206865792068657920686579206865792068657920686579206865790d0a7072697665742070726976657420707269766574207072697665740d0a6b616b2064656c613f, 1103, '08/21/2006', 1);
INSERT INTO `photo_rating` VALUES (365, 862, 512, 0, 0x5768792068616e67206f7574207769746820746572726f72697374732c20492062657420746865792077616e74656420666f7220736f6d657468696e673f21, 1103, '08/21/2006', 1);
INSERT INTO `photo_rating` VALUES (366, 333, 262, 0, 0x4355452050415341213f, 1103, '08/21/2006', 1);
INSERT INTO `photo_rating` VALUES (367, 284, 176, 0, 0x447564652c207573652066616369616c20636c65616e7365722e0d0a506f73742070696320696e20666577207765656b2c2073656520746865206469666672656e6365, 1103, '08/21/2006', 1);
INSERT INTO `photo_rating` VALUES (368, 1332, 176, 0, 0x4865792073706f6e67626f6221210d0a57686f20697320796f7572206e657720667269656e643f, 1103, '08/21/2006', 1);
INSERT INTO `photo_rating` VALUES (369, 351, 296, 0, 0x4368656572732121210d0a596f7520646f6e2774206c6f6f6b2068617070792c206576656e2077697468206265657220696e20796f75722068616e642e0d0a5768617465766572206d616b657320796f75206861707079213f, 1103, '08/21/2006', 1);
INSERT INTO `photo_rating` VALUES (370, 865, 512, 0, 0x4355452050415341213f, 1103, '08/21/2006', 1);
INSERT INTO `photo_rating` VALUES (371, 1399, 989, 0, 0x4f68686868682e2e2e2e0d0a4c6f76656c7921, 1103, '08/21/2006', 1);
INSERT INTO `photo_rating` VALUES (372, 1003, 857, 0, 0x423e453e413e553e543e463e553e4c, 1103, '08/21/2006', 1);
INSERT INTO `photo_rating` VALUES (373, 1334, 857, 0, 0x74616b6520796f7520626f74682c20616e64206c6f766520796f75206d75636821, 1103, '08/21/2006', 1);
INSERT INTO `photo_rating` VALUES (374, 1004, 857, 0, 0x50726574747920657965730d0a5265616c6c79, 1103, '08/21/2006', 1);
INSERT INTO `photo_rating` VALUES (375, 1106, 857, 0, 0x486f776479212121210d0a596f752061726520676f6f64206c6f6f6b696e, 1103, '08/21/2006', 1);
INSERT INTO `photo_rating` VALUES (376, 1552, 1086, 0, 0x48492068692068696869686968696869686868686869696968696869680d0a68696869686969686968696869680d0a68656c6c6f0d0a686868686565656c6c6c6f6f6f212121212121213f213f213f213f21, 1103, '08/21/2006', 1);
INSERT INTO `photo_rating` VALUES (377, 1047, 899, 0, 0x574f572048454c4c4f20574f572121, 1103, '08/21/2006', 1);
INSERT INTO `photo_rating` VALUES (378, 757, 735, 0, 0x48657920626162793f0d0a7761732075703f21, 1103, '08/21/2006', 1);
INSERT INTO `photo_rating` VALUES (591, 736, 705, 0, 0x6f6d672e2e2e757220736f6f207365787879, 1248, '11/28/2006', 1);
INSERT INTO `photo_rating` VALUES (380, 1590, 1097, 0, 0x6b7261736176697473613a29, 990, '08/23/2006', 1);
INSERT INTO `photo_rating` VALUES (381, 1634, 886, 0, 0x6865792c2076736f20686f726f73686f2120, 1103, '08/23/2006', 1);
INSERT INTO `photo_rating` VALUES (382, 238, 122, 0, 0x68656c6c6f20736578793f21, 1103, '08/23/2006', 1);
INSERT INTO `photo_rating` VALUES (383, 187, 128, 0, 0x70726976657421212120686921212121206f6c6121212121, 1103, '08/23/2006', 1);
INSERT INTO `photo_rating` VALUES (384, 480, 399, 0, 0x696d206d697373696e6720696e207468697320706963747572652c20692073686f756c64207265706c616365207468617420646f6767792e, 1103, '08/23/2006', 1);
INSERT INTO `photo_rating` VALUES (385, 263, 165, 0, 0x686920637574652c206b616b2064656c613f, 1103, '08/23/2006', 1);
INSERT INTO `photo_rating` VALUES (386, 1442, 1046, 0, 0x6865792c206865792c206865792c206865792c206865792e0d0a5072697665742c206b616b2064656c613f0d0a69206b6e6f772074686520636f6c6f72206f6620796f75722062726121, 1103, '08/26/2006', 1);
INSERT INTO `photo_rating` VALUES (387, 1441, 1046, 0, 0x6865792c2068656c6c6f2c20636520657374612073656e6f726974613f, 1103, '08/26/2006', 1);
INSERT INTO `photo_rating` VALUES (388, 1411, 118, 0, 0x7468617420626f792068617665207769646520666163652c20616e64206769726c206e6f742e0d0a6f75682c2068656c6c6f21212121, 1103, '08/26/2006', 1);
INSERT INTO `photo_rating` VALUES (389, 1525, 1032, 0, 0x74686174732061206e69636520636172, 1121, '08/28/2006', 1);
INSERT INTO `photo_rating` VALUES (390, 648, 573, 0, 0x69206c696b65207468652070696374757265, 1121, '08/28/2006', 1);
INSERT INTO `photo_rating` VALUES (391, 1107, 857, 0, 0x7072697665742c206b616b2064656c613f, 1103, '09/04/2006', 1);
INSERT INTO `photo_rating` VALUES (392, 1683, 1121, 0, 0x676f7420616e7920726f6f6d20666f72206d65, 1032, '09/05/2006', 1);
INSERT INTO `photo_rating` VALUES (393, 245, 122, 0, 0x796f7520206172652020766572792020686f7474, 938, '09/08/2006', 1);
INSERT INTO `photo_rating` VALUES (394, 410, 342, 0, 0x686579207768617420757020756d6d206f6b20746865206775792077697468207468652062756c6520736869727420697320687574206f6b20627574207468652034206f6620796f75206172652e2062796520652d6d61696c206d65206b656e69616c657340756e69766973696f6e2e636f6d, 1146, '09/13/2006', 1);
INSERT INTO `photo_rating` VALUES (395, 1590, 1097, 0, 0x7572207769636b656420707265747479203a44, 1149, '09/13/2006', 1);
INSERT INTO `photo_rating` VALUES (396, 1786, 1162, 0, 0x41206d6f676e61207961206275647520736162616b6f792121212121, 1161, '09/18/2006', 1);
INSERT INTO `photo_rating` VALUES (397, 1787, 1151, 0, 0x546861742077617465722069732070726f6c6c7920636f6c642e20, 916, '09/18/2006', 1);
INSERT INTO `photo_rating` VALUES (398, 1771, 1151, 0, 0x4375746520616e64207365787921212121, 916, '09/18/2006', 1);
INSERT INTO `photo_rating` VALUES (399, 1790, 1164, 0, 0x574f57204920414d20544845204f4e4c59204f4e45205448415420495320434f4d4d454e5420594f55522050494320594f55204c4f4f4b204355544520494e2054484953204f4e4520594f552053484f554c4420474554204d4f5245204f50494353, 1122, '09/18/2006', 1);
INSERT INTO `photo_rating` VALUES (400, 1529, 941, 0, 0x4177772077686f20697320746861743f0d0a796f75206c6f6f6b207265616c6c7920637574652e, 930, '09/18/2006', 1);
INSERT INTO `photo_rating` VALUES (401, 1770, 1151, 0, 0x49206c6f766520746869732069636f6e20692068617665206974206f6e206d7920726567756c6172206d797370616365203a44, 1155, '09/19/2006', 1);
INSERT INTO `photo_rating` VALUES (402, 1772, 1151, 0, 0x7665727920707265747479, 1155, '09/19/2006', 1);
INSERT INTO `photo_rating` VALUES (403, 1804, 1167, 0, 0x5365787921210d0a6f6368656e20666b75736e6f21, 964, '09/19/2006', 1);
INSERT INTO `photo_rating` VALUES (404, 1800, 1167, 0, 0x6b72617369766f21, 964, '09/19/2006', 1);
INSERT INTO `photo_rating` VALUES (405, 1052, 903, 0, 0x7468617473207265616c6c79206b6f6f6c2121, 1122, '09/21/2006', 1);
INSERT INTO `photo_rating` VALUES (406, 1813, 1122, 0, 0x6177777720746861747320616e2061646f7261626c6520706963, 956, '09/21/2006', 1);
INSERT INTO `photo_rating` VALUES (407, 1818, 1122, 0, 0x75206c6f6f6b20736c656570792068657265, 956, '09/21/2006', 1);
INSERT INTO `photo_rating` VALUES (408, 1836, 903, 0, 0x594f55204c4f4f4b204e4f5420484150505920494e2054484520504943204255542053555052495345442057454c4c2049205354494c4c204c4f564520495420444f20594f55205245414c4c59204841564520424c5545204559455320435554452049204d45414e20594f55204c4f4f4b20435554452057454c4c205945414820, 1122, '09/23/2006', 1);
INSERT INTO `photo_rating` VALUES (409, 965, 857, 0, 0x796f75722062656175746966756c21, 804, '09/25/2006', 1);
INSERT INTO `photo_rating` VALUES (410, 995, 857, 0, 0x566572792062656175746966756c2c207520676f74206120686f7420626f64792e, 804, '09/25/2006', 1);
INSERT INTO `photo_rating` VALUES (411, 1003, 857, 0, 0x707265747479, 804, '09/25/2006', 1);
INSERT INTO `photo_rating` VALUES (412, 1005, 857, 0, 0x686f7420686f7420686f7421, 804, '09/25/2006', 1);
INSERT INTO `photo_rating` VALUES (413, 1108, 857, 0, 0x69662069206861642074696d6520746f20636f6d6d656e7420616c6c2075722070696373206920776f756c642069206a75737420646f6e7420686176652074696d652c20616c6c207468656d206172652062656175746966756c21, 804, '09/25/2006', 1);
INSERT INTO `photo_rating` VALUES (414, 1196, 945, 0, 0x70726574747920637574652e, 804, '09/25/2006', 1);
INSERT INTO `photo_rating` VALUES (415, 1551, 1026, 0, 0x69207265616c6c79206c6f7665207468697320706963206769726c20796f752073686f756c6420676574206d6f7265207069637320736f2079656168206c6f76652069742069206d65616e642063757465656565656565656565656565656565656565656565656565656565, 1122, '09/26/2006', 1);
INSERT INTO `photo_rating` VALUES (416, 1796, 1168, 0, 0x686920686f772061726520796f752064696f6e672e20796f75206c6f6f6b206e69636521, 1176, '09/27/2006', 1);
INSERT INTO `photo_rating` VALUES (417, 1793, 1164, 0, 0x6865792063757465206c6f7665207468652070696320796f75206c6f6f6b20686f74206f6e207468652070696320, 1122, '09/28/2006', 1);
INSERT INTO `photo_rating` VALUES (418, 1793, 1164, 0, 0x68652079637574652070696320627574207520646f6e74206c6f6f6b206c696b6520612072757373696f6e206f7220756b7265696e652067792075206c6f6f6b206d6578696b656e, 1026, '09/28/2006', 1);
INSERT INTO `photo_rating` VALUES (419, 1842, 1164, 0, 0x61726520752074616b696e2061207069633f, 1026, '09/28/2006', 1);
INSERT INTO `photo_rating` VALUES (420, 1839, 934, 0, 0x692068617665206e6f74207365656e2074686973206f6e206d7973706163652c20796f75206c6f6f6b2068656c6c612070696d702e206c6f6c, 916, '09/28/2006', 1);
INSERT INTO `photo_rating` VALUES (421, 1130, 934, 0, 0x676f7267656f7573, 916, '09/28/2006', 1);
INSERT INTO `photo_rating` VALUES (422, 1839, 934, 0, 0x692068617665206e6f74207365656e2074686973206f6e206d7973706163652c20796f75206c6f6f6b2068656c6c612070696d702e206c6f6c, 916, '09/28/2006', 1);
INSERT INTO `photo_rating` VALUES (423, 1814, 1122, 0, 0x6e696365206261636b20696e20746865206461792070686f746f3f206c6f6c21, 1175, '10/02/2006', 1);
INSERT INTO `photo_rating` VALUES (424, 1818, 1122, 0, 0x69206c696b652074686973206f6e65207468616e207468652072657374206265636175736520697473206f6c642074696d652070686f746f206c6f6c203a5020616e6420697473206174207363686f6f6c21206c6f6c2063207961206c6174657220676174657221, 1175, '10/02/2006', 1);
INSERT INTO `photo_rating` VALUES (425, 1391, 1024, 0, 0x796f7572207265616c792070726574747921203a29, 1122, '10/04/2006', 1);
INSERT INTO `photo_rating` VALUES (426, 1841, 1177, 0, 0x796f7520626574746572206e6f742073686f7420616e79206f6e65207769746820746861742067756e21212121203a50, 1122, '10/04/2006', 1);
INSERT INTO `photo_rating` VALUES (427, 1354, 1005, 0, 0x637574652070696321203a29, 1122, '10/04/2006', 1);
INSERT INTO `photo_rating` VALUES (428, 1406, 804, 0, 0x736f6f2063757465212121203a290d0a796f752072656d696e6465206d65206f6620736f6d656f6e652e2e2e6c6f6c, 1122, '10/04/2006', 1);
INSERT INTO `photo_rating` VALUES (429, 1409, 804, 0, 0x7468697320706963206c6f6f6b7320736f20636f6f6c21, 1122, '10/04/2006', 1);
INSERT INTO `photo_rating` VALUES (430, 1801, 1167, 0, 0x63757465212121203a29, 1122, '10/04/2006', 1);
INSERT INTO `photo_rating` VALUES (431, 1865, 1181, 0, 0x676f7267656f75733c3333, 1178, '10/05/2006', 1);
INSERT INTO `photo_rating` VALUES (432, 1550, 805, 0, 0x69207265616c6c79206c6f7665207468697320706963207468616e6b7320666f72206265696e67206d7920667269656e64, 1122, '10/07/2006', 1);
INSERT INTO `photo_rating` VALUES (433, 1816, 1122, 0, 0x756d6d206865792c2063757465207069632c2061626f75742074686174206f6e6520636f6d6d656e74206f6e206c696b6520392d32332d3036207468617420796f752067617665206d652c2079656168206920646f206861766520626c7565206579657321, 903, '10/08/2006', 1);
INSERT INTO `photo_rating` VALUES (434, 1106, 857, 0, 0x6b7261736176657473612e2e20752020617265202020766572792020707265747479, 938, '10/08/2006', 1);
INSERT INTO `photo_rating` VALUES (435, 1876, 1193, 0, 0x6769726c2069206c6f7665207468652070696320697473207265616c6c7920636f6f6c20616e6420796f7520646964207265616c6c7920676f6f642073696e67696e6720796561737465726461792069207468696e6b2069207370656c6c65642069742074686520776f72642077726f6e67206f682077656c6c, 1122, '10/09/2006', 1);
INSERT INTO `photo_rating` VALUES (436, 1877, 1193, 0, 0x6c6f76652074686973206f6e652074776f20796f752073686f756c6420636f6d65206f76657220617274206d7920686f75736520736f6d6574696d657320736f2079656168206c6f766520697420616761696e, 1122, '10/09/2006', 1);
INSERT INTO `photo_rating` VALUES (437, 1886, 956, 0, 0x686d6d6d2e20776f772c2049206469646e74206b6e6f7720796f752077657265206d7920667269656e64206f6e207275736b69646f6d2e2e20616e79776179732c206375746520636f75706c6521, 903, '10/09/2006', 1);
INSERT INTO `photo_rating` VALUES (438, 1026, 886, 0, 0x2623313038373b2623313038383b2623313038303b2623313037343b2623313037373b2623313039303b2623313038303b2623313038323b2c202623313038323b2623313037323b2623313038323b202623313037363b2623313037373b2623313038333b2623313037323b3f202623313130333b202623313039303b2623313038363b2623313038333b2623313130303b2623313038323b2623313038363b202623313039353b2623313039303b2623313038363b202623313039313b2623313037393b2623313038353b2623313037323b2623313038333b202623313038373b2623313038383b2623313038363b202623313130313b2623313039303b2623313039343b202623313038393b2623313039303b2623313038383b2623313037323b2623313038353b2623313038303b2623313039353b2623313038323b2623313038303b202623313039303b2623313037323b2623313038323b202623313039353b2623313039303b2623313038363b202623313038373b2623313038363b2623313038323b2623313037323b202623313039353b2623313039303b2623313038363b202623313038353b2623313038303b2623313039353b2623313037373b2623313037353b2623313038363b202623313038353b2623313037373b202623313038373b2623313038363b2623313038393b2623313039303b2623313037323b2623313037343b2623313038303b2623313038333b202623313038353b2623313038363b202623313038353b2623313037323b202623313037363b2623313038333b2623313130333b2623313039333b202623313038393b2623313037363b2623313037373b2623313038333b2623313037323b2623313130323b202c202623313038323b2623313038333b2623313037323b2623313038393b2623313038353b2623313037323b2623313130333b202623313039323b2623313038363b2623313039303b2623313038323b2623313037323b200d0a, 1195, '10/10/2006', 1);
INSERT INTO `photo_rating` VALUES (439, 1634, 886, 0, 0x2623313039353b2623313039303b2623313038363b202623313039353b2623313039303b2623313038363b202623313039303b2623313037323b2623313038343b202623313039313b202623313039303b2623313037373b2623313037333b2623313130333b202623313038353b2623313037323b202623313038393b2623313039303b2623313038363b2623313038333b2623313037373b3f3f3f3f, 1195, '10/10/2006', 1);
INSERT INTO `photo_rating` VALUES (440, 1885, 956, 0, 0x686579206769726c667269656e6473207768617473207570206c6f7665207468652070696320796f752067757973206d616b65206120677265617420636f75706c65206c6f7665206974, 1122, '10/10/2006', 1);
INSERT INTO `photo_rating` VALUES (735, 1405, 1020, 0, 0x68657920796f752069276d2073616420636175736520796f7520666f72676f742061626f7574206d6520796f7572206f6c6420667269656e642e2077656c6c2074656c206d6520686f772077617320565f6461792e, 1236, '02/16/2007', 1);
INSERT INTO `photo_rating` VALUES (443, 1841, 1177, 0, 0x776f7720636f6f6c2067756e212121206361726566756c6c20776974682069742121, 1202, '10/17/2006', 1);
INSERT INTO `photo_rating` VALUES (444, 991, 866, 0, 0x636f6f6c207069632121212121, 1202, '10/17/2006', 1);
INSERT INTO `photo_rating` VALUES (445, 1294, 994, 0, 0x686d6d6d20637574652070696321, 1202, '10/17/2006', 1);
INSERT INTO `photo_rating` VALUES (446, 434, 153, 0, 0x776f77207468617473207265616c6c79205245414c4c59206e69636520706963212121212121, 1202, '10/17/2006', 1);
INSERT INTO `photo_rating` VALUES (447, 433, 153, 0, 0x776f7720746869732070696321206973206a75737420435554452121216177777777203a2963757465, 1202, '10/17/2006', 1);
INSERT INTO `photo_rating` VALUES (448, 1925, 1202, 0, 0x596f7527726520736f2062656175746966756c21212121, 1201, '10/17/2006', 1);
INSERT INTO `photo_rating` VALUES (734, 1109, 857, 0, 0x796f7520206c6f6f6b202047656f7267756573, 938, '01/30/2007', 1);
INSERT INTO `photo_rating` VALUES (733, 2620, 1330, 0, 0x6861686168686120796f75206c6f6f6b206c696b652061204348494d50, 1331, '01/29/2007', 1);
INSERT INTO `photo_rating` VALUES (451, 1156, 856, 0, 0x796f7527726520736f206375746521212121213131, 1201, '10/18/2006', 1);
INSERT INTO `photo_rating` VALUES (452, 1469, 958, 0, 0x796f7527726520736f20626561746966756b20616e64206e696365206769726c21212121213a2929292929, 1201, '10/18/2006', 1);
INSERT INTO `photo_rating` VALUES (453, 1901, 1193, 0, 0x536f20637574652121213b29, 1201, '10/18/2006', 1);
INSERT INTO `photo_rating` VALUES (454, 1173, 940, 0, 0x7665727920707265747479212121213a2929292929, 1201, '10/18/2006', 1);
INSERT INTO `photo_rating` VALUES (455, 1946, 1203, 0, 0x556b61696e61696e2067616e737461732121206c6f6c, 1202, '10/18/2006', 1);
INSERT INTO `photo_rating` VALUES (456, 1932, 1193, 0, 0x69206c6f766520746869732070696320796f75206c6f6f6b20736f206375746520696e206974206c6f766520697420736973, 1122, '10/19/2006', 1);
INSERT INTO `photo_rating` VALUES (457, 1836, 903, 0, 0x686579206e6f7420746f20626520726f6420627574207520646f6e74206c6f6f6b206c696b652061207369787374696e2079656172206f6c642e20666f72737420692074686f756768742075207765722061206c6974746c65206b6964206f6e2074686120736d616c6c207069632e2075206c6f6f6b206c696b652069742e, 1026, '10/20/2006', 1);
INSERT INTO `photo_rating` VALUES (458, 1272, 980, 0, 0x6e69636520636172206d792062726f20757374792068617665207468652073616d6520636172206974732068656c6c61206661737421206973206974207572653f, 1026, '10/20/2006', 1);
INSERT INTO `photo_rating` VALUES (459, 1551, 1026, 0, 0x7468616e6b7320666f72207468617420636f6d6d656e742e2e2e2062616420636f6d6d656e742e2e2061637475616c6c7920796f7520646f6e74206c6f6f6b206c696b65203136206561746865722e2e20796f75206c6f6f6b206c696b652031332e2e206f682077656c6c2e, 903, '10/20/2006', 1);
INSERT INTO `photo_rating` VALUES (461, 1052, 903, 0, 0x776177206361636979206372617361767368696b20786520772072757369653f, 1026, '10/21/2006', 1);
INSERT INTO `photo_rating` VALUES (462, 1052, 903, 0, 0x776177206361636979206372617361767368696b20786520772072757369653f, 1026, '10/21/2006', 1);
INSERT INTO `photo_rating` VALUES (463, 1946, 1203, 0, 0x757265696e65206d616669613f, 1026, '10/21/2006', 1);
INSERT INTO `photo_rating` VALUES (732, 2605, 1331, 0, 0x7768617420746865206675636b206b696e64206f6620616e696d616c20697320656174696e6720757220686561642e, 1330, '01/29/2007', 1);
INSERT INTO `photo_rating` VALUES (731, 1668, 1118, 0, 0x686579206475646520796f75206c6f6f6b20686f74, 1328, '01/22/2007', 1);
INSERT INTO `photo_rating` VALUES (730, 2599, 1331, 0, 0x677272727272727272722e2e2e2e2e2e0d0a62757420686f74, 1328, '01/22/2007', 1);
INSERT INTO `photo_rating` VALUES (729, 406, 342, 0, 0x6865792077617473207570, 1333, '01/19/2007', 1);
INSERT INTO `photo_rating` VALUES (728, 406, 342, 0, 0x6865792077617473207570, 1333, '01/19/2007', 1);
INSERT INTO `photo_rating` VALUES (469, 1886, 956, 0, 0x61777777206d616e2120746861747320736f206672696767696e2063617574652121212069206c6f766520796f7521, 961, '10/23/2006', 1);
INSERT INTO `photo_rating` VALUES (470, 1249, 961, 0, 0x61777777206265626b612075206c6f6f6b20736f2073657863, 956, '10/23/2006', 1);
INSERT INTO `photo_rating` VALUES (471, 1259, 943, 0, 0x6e69636520706963213a29, 1202, '10/24/2006', 1);
INSERT INTO `photo_rating` VALUES (472, 1385, 1020, 0, 0x6e696365207069632121, 1202, '10/24/2006', 1);
INSERT INTO `photo_rating` VALUES (473, 1240, 966, 0, 0x6e69636520706963212121213a29, 1202, '10/24/2006', 1);
INSERT INTO `photo_rating` VALUES (474, 1958, 1026, 0, 0x6c6f6f6b73206c696b6520612062616e69612c20636f6f6c, 916, '10/24/2006', 1);
INSERT INTO `photo_rating` VALUES (475, 1975, 572, 0, 0x48657920626162652c2077686f206875676765642042696c6c79204d617274696e2066726f6d20476f6f6420436861726c6f7474653f204e494b4b4920444944212121212041206e6967687420746f206e6576657220666f726765742c206875683f202049206b6e6f7720796f7520776f6e2774203b2920, 536, '10/24/2006', 1);
INSERT INTO `photo_rating` VALUES (476, 1037, 894, 0, 0x76657279206e69636520616e64207377656574, 1206, '10/25/2006', 1);
INSERT INTO `photo_rating` VALUES (477, 1218, 957, 0, 0x76657279206172746973746963, 1206, '10/25/2006', 1);
INSERT INTO `photo_rating` VALUES (478, 1476, 1062, 0, 0x4920686176652061206461756768746572206f6c646572207468616e20796f7520736f20646f6e27742067657420746f6f206578636974656420627574207768656e20746865792061726520726561647920746f206d6172727920677579732074656e6420746f2077616e742074616c6c657220636869636b73206265636175736520746865792077616e7420746865697220736f6e7320746f2062652074616c6c20616e64207468657265666f7265206c75636b79, 1206, '10/25/2006', 1);
INSERT INTO `photo_rating` VALUES (479, 163, 122, 0, 0x76657279206e696365, 1206, '10/26/2006', 1);
INSERT INTO `photo_rating` VALUES (480, 255, 163, 0, 0x6375746520616e642073657879, 1206, '10/26/2006', 1);
INSERT INTO `photo_rating` VALUES (481, 997, 867, 0, 0x63757465, 1206, '10/26/2006', 1);
INSERT INTO `photo_rating` VALUES (482, 1018, 879, 0, 0x766572792063757465, 1206, '10/26/2006', 1);
INSERT INTO `photo_rating` VALUES (483, 981, 858, 0, 0x7365787920627574206e6f7420736c757474793a2076657279206e696365, 1206, '10/26/2006', 1);
INSERT INTO `photo_rating` VALUES (484, 822, 552, 0, 0x69206c696b65207468697320706963, 1206, '10/26/2006', 1);
INSERT INTO `photo_rating` VALUES (485, 719, 662, 0, 0x63757465, 1206, '10/26/2006', 1);
INSERT INTO `photo_rating` VALUES (486, 294, 211, 0, 0x6375746520616e64207377656574, 1206, '10/26/2006', 1);
INSERT INTO `photo_rating` VALUES (487, 309, 164, 0, 0x6e696365, 1206, '10/26/2006', 1);
INSERT INTO `photo_rating` VALUES (488, 1890, 552, 0, 0x73657879206c656773, 1206, '10/26/2006', 1);
INSERT INTO `photo_rating` VALUES (489, 1555, 1071, 0, 0x73686d657879, 1084, '10/27/2006', 1);
INSERT INTO `photo_rating` VALUES (490, 1340, 1000, 0, 0x305f30202020204a45535553204348524953542e20202020203a4f, 1084, '10/27/2006', 1);
INSERT INTO `photo_rating` VALUES (491, 984, 858, 0, 0x6e6963652076696577, 1206, '10/28/2006', 1);
INSERT INTO `photo_rating` VALUES (492, 1227, 961, 0, 0x75726520736f2068617774212121, 956, '10/28/2006', 1);
INSERT INTO `photo_rating` VALUES (493, 1427, 961, 0, 0x6c6f76652074686520736861646573, 956, '10/28/2006', 1);
INSERT INTO `photo_rating` VALUES (494, 2004, 1216, 0, 0x417777772e2e2e73686520697320736f6f6f6f206375746521203a29, 1213, '11/01/2006', 1);
INSERT INTO `photo_rating` VALUES (495, 2007, 1216, 0, 0x4c4f4f4b494e472053455859204f4e205448415420434152203b290d0a, 1213, '11/01/2006', 1);
INSERT INTO `photo_rating` VALUES (496, 2008, 1216, 0, 0x54574f204845415659204d4554414c20424954434845532c20524f434b204f4e20212121, 1213, '11/01/2006', 1);
INSERT INTO `photo_rating` VALUES (497, 2005, 1216, 0, 0x49206c6f76652074616b696e67207069637475726573206f6620752062616265203b29200d0a0d0a, 1213, '11/01/2006', 1);
INSERT INTO `photo_rating` VALUES (498, 2010, 1216, 0, 0x676f642064616d6e20796f757220686f742021212120, 1213, '11/01/2006', 1);
INSERT INTO `photo_rating` VALUES (499, 2006, 1216, 0, 0x53657879204269616368212121, 1213, '11/01/2006', 1);
INSERT INTO `photo_rating` VALUES (500, 2009, 1216, 0, 0x4b45455020594f55522048414e4453204f4646204f46204d5920424954434820212121, 1213, '11/01/2006', 1);
INSERT INTO `photo_rating` VALUES (501, 1637, 945, 0, 0x7665727920707265747479792e, 857, '11/06/2006', 1);
INSERT INTO `photo_rating` VALUES (502, 1924, 1201, 0, 0x69207265616c6c79206c6f76652074686973207069632069206c696b6520746865206261636b67726f756e6420206c6f7665206974206769726c, 1122, '11/07/2006', 1);
INSERT INTO `photo_rating` VALUES (503, 1886, 956, 0, 0x6168686820736f206375746520752074776f20736f20686170707920666f7220796f75206c6f76652074686520706963, 1122, '11/07/2006', 1);
INSERT INTO `photo_rating` VALUES (504, 1990, 956, 0, 0x6c6f76652069742075206c6f6f6b206d616420696e2074686520706963206275742069206c6f766520697420616e7977617973, 1122, '11/07/2006', 1);
INSERT INTO `photo_rating` VALUES (505, 1815, 1122, 0, 0x79756f206c6f6f6b206e69636520, 1226, '11/08/2006', 1);
INSERT INTO `photo_rating` VALUES (506, 2021, 1004, 0, 0x77686174732069732074686174207468696e6b2074686174207572652070756c696e67206f6e, 1026, '11/08/2006', 1);
INSERT INTO `photo_rating` VALUES (507, 2002, 1210, 0, 0x4c4f4f4f4f4f564520666f72206d7920736d65787920626f79667269656e642e203a29, 1211, '11/09/2006', 1);
INSERT INTO `photo_rating` VALUES (508, 1957, 1026, 0, 0x69206265656e20746861697220746f20796f752068617665206e69636520706963, 1226, '11/09/2006', 1);
INSERT INTO `photo_rating` VALUES (516, 2074, 1193, 0, 0x686f7421212070696320776f726b206974206769726c, 1122, '11/15/2006', 1);
INSERT INTO `photo_rating` VALUES (510, 1835, 1171, 0, 0x796f75206c6f6f6b20686f74, 1226, '11/13/2006', 1);
INSERT INTO `photo_rating` VALUES (511, 1835, 1171, 0, 0x796f75206c6f6f6b20686f74, 1226, '11/13/2006', 1);
INSERT INTO `photo_rating` VALUES (512, 1844, 1178, 0, 0x796f75206c6f6f6b206e696365, 1226, '11/13/2006', 1);
INSERT INTO `photo_rating` VALUES (513, 2050, 1226, 0, 0x736865732063757465, 1026, '11/13/2006', 1);
INSERT INTO `photo_rating` VALUES (515, 1405, 1020, 0, 0x61686820796f75206c6f6f6b20736f206375746520696e207468652070696320, 1122, '11/14/2006', 1);
INSERT INTO `photo_rating` VALUES (517, 2072, 1193, 0, 0x736164207069632064696420796f752063757420796f757273656c66206769726c2073616420616e6420616761696e20736164, 1122, '11/15/2006', 1);
INSERT INTO `photo_rating` VALUES (518, 2069, 1193, 0, 0x796f75206c6f6f6b2073616420696e2074686520706963206368656572207570206769726c2065766572797468696e672077656c6c20626520616c6c207269676874, 1122, '11/15/2006', 1);
INSERT INTO `photo_rating` VALUES (519, 2065, 1193, 0, 0x796f75206c6f6f6b206c696b6520796f75202061726520736c656570696e6720696e20746869732070696320752073686f756c6420707574206d792070696320746865726520746f, 1122, '11/15/2006', 1);
INSERT INTO `photo_rating` VALUES (520, 2071, 1193, 0, 0x69206c6f766520796f75722068616972206c696b65207468617420, 1122, '11/15/2006', 1);
INSERT INTO `photo_rating` VALUES (521, 2064, 1193, 0, 0x63757465207368697274206c6f7665206974206e6963652074776f206f6620796f75, 1122, '11/15/2006', 1);
INSERT INTO `photo_rating` VALUES (522, 2075, 1193, 0, 0x6e69636520736d696c6520, 1122, '11/15/2006', 1);
INSERT INTO `photo_rating` VALUES (523, 2076, 1193, 0, 0x796f75206c6f6f6b2062756974656166756c206769726c20616e642069207468696e6b2069207370656c6c656420746861742077726f6e67, 1122, '11/15/2006', 1);
INSERT INTO `photo_rating` VALUES (524, 2077, 1193, 0, 0x6c6f766520697420776f726b206974, 1122, '11/15/2006', 1);
INSERT INTO `photo_rating` VALUES (525, 2078, 1193, 0, 0x69207265616c6c79206c6f766520746869732070696320, 1122, '11/15/2006', 1);
INSERT INTO `photo_rating` VALUES (526, 1986, 1167, 0, 0x796f75206c6f6f6b20686f74206f6e20746869736420706963, 1226, '11/16/2006', 1);
INSERT INTO `photo_rating` VALUES (527, 2015, 1217, 0, 0x796f75206c6f6f6b20686f74206f6e207468697320706963, 1226, '11/16/2006', 1);
INSERT INTO `photo_rating` VALUES (528, 1442, 1046, 0, 0x796f75206c6f6f6b20686f7420686f7420686f7420, 1226, '11/17/2006', 1);
INSERT INTO `photo_rating` VALUES (529, 1949, 118, 0, 0x53657879, 938, '11/17/2006', 1);
INSERT INTO `photo_rating` VALUES (530, 1839, 934, 0, 0x537765657469652020796f7520206172652020686f747474, 938, '11/17/2006', 1);
INSERT INTO `photo_rating` VALUES (531, 1441, 1046, 0, 0x796f7520206172652020707265747479, 938, '11/17/2006', 1);
INSERT INTO `photo_rating` VALUES (532, 2090, 1226, 0, 0x752061726520736f2073747570696420666f7220676f696e206f75742077697468206865722061686520666c75727473207769746820657672792073696e676c65206779207368652073656573, 1026, '11/17/2006', 1);
INSERT INTO `photo_rating` VALUES (533, 108, 86, 0, 0x686920686f772061726520796f7520646f696e6720746f6461793f0d0a692077656c6c206c696b6520796f7520746f206265636f6d6f206d79206e657720667269656e642e, 1236, '11/20/2006', 1);
INSERT INTO `photo_rating` VALUES (534, 2092, 1235, 0, 0x6865792077686174732075703f2076657279207365786920706963747572652e20686974206d6520757020696620752077616e742e, 1233, '11/20/2006', 1);
INSERT INTO `photo_rating` VALUES (535, 308, 216, 0, 0x686920, 1236, '11/21/2006', 1);
INSERT INTO `photo_rating` VALUES (536, 402, 81, 0, 0x686f772063616e20676574206e6577206669656e64732e20, 1236, '11/21/2006', 1);
INSERT INTO `photo_rating` VALUES (537, 2107, 1238, 0, 0x68692c20686f772061726520796f7520646f696e672e200d0a77656c6c20206d79206e616d65206973206a696d656e612069276d206d65786963616e0d0a616e6420692077656c6c206c696b6520746f20746f206d65206d7920667269656e642e, 1236, '11/21/2006', 1);
INSERT INTO `photo_rating` VALUES (538, 1285, 986, 0, 0x68692e20796f75206c6f6f6b2076657279206e696365206f6e2074686973207069632e0d0a686f772061726520796f7520746f6461792e200d0a6920686f706520796f75206265636f6d6f206d79206e657720667269656e642e, 1236, '11/21/2006', 1);
INSERT INTO `photo_rating` VALUES (539, 1818, 1122, 0, 0x686579206769726c206973206d65206d6172696120796f7572206769726c2d667269656e642e0d0a69276d20736f20686170707920746f2066696e6520796f752e, 1236, '11/21/2006', 1);
INSERT INTO `photo_rating` VALUES (540, 1117, 928, 0, 0x68657920776861742773207570200d0a686f772061726520796f752064696f6e670d0a, 1236, '11/21/2006', 1);
INSERT INTO `photo_rating` VALUES (541, 108, 86, 0, 0x68657920686f772061726520796f7520646f696e672e, 1236, '11/21/2006', 1);
INSERT INTO `photo_rating` VALUES (542, 1294, 994, 0, 0x68657920796f7520686f772061726520796f752064696f6e67200d0a6d6d20796f75206c6f6f6b206e69636521, 1236, '11/21/2006', 1);
INSERT INTO `photo_rating` VALUES (543, 2104, 1193, 0, 0x69207265616c6c79206c6f7665207572207069636b20616e6420757220736d696c65, 1122, '11/21/2006', 1);
INSERT INTO `photo_rating` VALUES (544, 2103, 1193, 0, 0x796561702074686174732074727565, 1122, '11/21/2006', 1);
INSERT INTO `photo_rating` VALUES (545, 2102, 1193, 0, 0x79656170206974732074727565207265616c6c792074727565, 1122, '11/21/2006', 1);
INSERT INTO `photo_rating` VALUES (546, 702, 103, 0, 0x68657920677579206d6d0d0a796f75206c6f6f6b2076657279206e69636520796f7520616e6420796f757220667269656e647320746f, 1236, '11/21/2006', 1);
INSERT INTO `photo_rating` VALUES (547, 340, 274, 0, 0x686920686f772061726520796f7520, 1236, '11/21/2006', 1);
INSERT INTO `photo_rating` VALUES (548, 1203, 916, 0, 0x6869, 1236, '11/21/2006', 1);
INSERT INTO `photo_rating` VALUES (727, 1483, 865, 0, 0x3c666f6e742073697a653d333e6f68206b72697374696e6121207468617420697320736f6f20637574652e2e, 1310, '01/19/2007', 1);
INSERT INTO `photo_rating` VALUES (552, 1352, 860, 0, 0x4d6172696e612121212120446964204368696e676973207365652074686973206c6f6c3f3f3f, 1046, '11/22/2006', 1);
INSERT INTO `photo_rating` VALUES (553, 340, 274, 0, 0x686579206973206d65206a696d656e61, 1236, '11/22/2006', 1);
INSERT INTO `photo_rating` VALUES (554, 2118, 1241, 0, 0x49206c6f766520796120506963, 1238, '11/22/2006', 1);
INSERT INTO `photo_rating` VALUES (555, 2116, 1233, 0, 0x4f682c204261627920796f75207220736f20686f747420696e20746869732070696320, 1238, '11/22/2006', 1);
INSERT INTO `photo_rating` VALUES (556, 2117, 1233, 0, 0x49206c6f76652074686973205069632e, 1238, '11/22/2006', 1);
INSERT INTO `photo_rating` VALUES (557, 1795, 1167, 0, 0x6375657465207368697274, 1026, '11/22/2006', 1);
INSERT INTO `photo_rating` VALUES (558, 1795, 1167, 0, 0x6375657465207368697274, 1026, '11/22/2006', 1);
INSERT INTO `photo_rating` VALUES (726, 1237, 964, 0, 0x64756520796f75206c6f6f6b2066752a2a6e20686f7420696e2074686973207069630d0a0d0a6d756368206c6f76652c0d0a0d0a20202020202020202076616e7a, 1328, '01/19/2007', 1);
INSERT INTO `photo_rating` VALUES (725, 2588, 1286, 0, 0x752077616e742061206b69737320646f6e742075206c6f6c, 1321, '01/16/2007', 1);
INSERT INTO `photo_rating` VALUES (561, 1375, 956, 0, 0x796561682070696e6b206361727320726f636b206c6f6c, 860, '11/22/2006', 1);
INSERT INTO `photo_rating` VALUES (562, 1532, 1000, 0, 0x7365786969, 860, '11/22/2006', 1);
INSERT INTO `photo_rating` VALUES (724, 2298, 1270, 0, 0x7572207265616c6c7920776f726b696e672074686174207368697274206c6f6c2e206e6963652076696577206f6620666c6f77657273203a29, 1286, '01/16/2007', 1);
INSERT INTO `photo_rating` VALUES (723, 2304, 1270, 0, 0x686d6d2e2e2e74686973207069637475726573206c6f6f6b73206c696b65206d6565203a292068616861206a6b206c6f6f6b696e6720676f6f6421, 1286, '01/16/2007', 1);
INSERT INTO `photo_rating` VALUES (567, 1553, 1071, 0, 0x6c6f766520746861207069632e2e2e, 1244, '11/24/2006', 1);
INSERT INTO `photo_rating` VALUES (590, 1865, 1181, 0, 0x776f77, 1237, '11/28/2006', 1);
INSERT INTO `photo_rating` VALUES (569, 2133, 1193, 0, 0x6b757465, 956, '11/26/2006', 1);
INSERT INTO `photo_rating` VALUES (570, 143, 113, 0, 0x79616b207368656d6173682121210d0a0d0a0d0a76657279206e6963652e2e2e2e686f77206d7563683f3f, 1248, '11/27/2006', 1);
INSERT INTO `photo_rating` VALUES (571, 914, 839, 0, 0x79616b207368656d6173682121212076657279206e6963652e2e2e2e686f77206d7563683f3f, 1248, '11/27/2006', 1);
INSERT INTO `photo_rating` VALUES (572, 914, 839, 0, 0x79616b207368656d6173682121212076657279206e6963652e2e2e2e686f77206d7563683f3f, 1248, '11/27/2006', 1);
INSERT INTO `photo_rating` VALUES (573, 661, 599, 0, 0x79616b207368656d6173682121212076657279206e6963652e2e2e2e686f77206d7563683f3f2e2e2e2e2e77686572652069732076656e696365206274773f3f3f20676f747461206c6f6f6b206974207570206f6e20676f6f676c65206d617073, 1248, '11/27/2006', 1);
INSERT INTO `photo_rating` VALUES (574, 661, 599, 0, 0x6f6f6f682075722062656c6f772073617261736f74612e2e2e2e6920632c2074686174207375636b73, 1248, '11/27/2006', 1);
INSERT INTO `photo_rating` VALUES (575, 1974, 1207, 0, 0x79616b207368656d6173682121212076657279206e6963652e2e2e2e686f77206d7563683f3f, 1248, '11/27/2006', 1);
INSERT INTO `photo_rating` VALUES (576, 1293, 993, 0, 0x79616b207368656d6173682121212076657279206e6963652e2e2e2e686f77206d7563683f3f, 1248, '11/27/2006', 1);
INSERT INTO `photo_rating` VALUES (577, 1351, 1013, 0, 0x79616b207368656d6173682121212076657279206e6963652e2e2e2e686f77206d7563683f3f, 1248, '11/27/2006', 1);
INSERT INTO `photo_rating` VALUES (578, 531, 428, 0, 0x79616b207368656d6173682121212076657279206e6963652e2e2e2e686f77206d7563683f3f, 1248, '11/27/2006', 1);
INSERT INTO `photo_rating` VALUES (579, 1779, 955, 0, 0x69206c696b6520736d6f6b65207765656420696e206d7920686f6d6520636f756e7472792e2e2e2e6974206973207665727920676f6f642077656564, 1248, '11/27/2006', 1);
INSERT INTO `photo_rating` VALUES (580, 1925, 1202, 0, 0x706963732066726f6d2074686520726f6164736964653f, 1237, '11/27/2006', 1);
INSERT INTO `photo_rating` VALUES (581, 2131, 1244, 0, 0x6d656f77212121, 1237, '11/27/2006', 1);
INSERT INTO `photo_rating` VALUES (582, 2167, 1251, 0, 0x6177777777206c6f6f6b206174207068696c6c702075206c6f6f6b20736f20736572696f757321212121206c6f6c, 1250, '11/27/2006', 1);
INSERT INTO `photo_rating` VALUES (583, 2164, 1250, 0, 0x796f752073746f6c652069742066726f6d206d652e2e2e6c6f6c2e2e2e776f6f7020776f6f70, 1242, '11/27/2006', 1);
INSERT INTO `photo_rating` VALUES (584, 2177, 1250, 0, 0x77687920796f7520676f74206d7920706963206f66207573, 1242, '11/27/2006', 1);
INSERT INTO `photo_rating` VALUES (585, 2175, 1250, 0, 0x6177777777206d79206d6f73742070726574747965737420667269656e6420657665722e2e2e796f75206c6f6f6b20686f7474, 1242, '11/27/2006', 1);
INSERT INTO `photo_rating` VALUES (586, 2175, 1250, 0, 0x6177777777206d79206d6f73742070726574747965737420667269656e6420657665722e2e2e796f75206c6f6f6b20686f7474, 1242, '11/27/2006', 1);
INSERT INTO `photo_rating` VALUES (587, 2175, 1250, 0, 0x6177777777206d79206d6f73742070726574747965737420667269656e6420657665722e2e2e796f75206c6f6f6b20686f7474, 1242, '11/27/2006', 1);
INSERT INTO `photo_rating` VALUES (588, 2182, 1251, 0, 0x776f77206e6963652070696374757265207068696c69702e2e2e2e2e, 1242, '11/28/2006', 1);
INSERT INTO `photo_rating` VALUES (589, 2183, 1251, 0, 0x69206c696b6520746869732070696374757265206f6620796f75206d722e68756c7365, 1242, '11/28/2006', 1);
INSERT INTO `photo_rating` VALUES (592, 736, 705, 0, 0x6964206c6f766520746f2073656520736f6d65206d6f7265207069637373, 1248, '11/28/2006', 1);
INSERT INTO `photo_rating` VALUES (593, 2224, 1241, 0, 0x68657920646f726b20737469636b20746861742074686e67206261636b20696e207572206d6f757468206c6f6c, 1250, '11/29/2006', 1);
INSERT INTO `photo_rating` VALUES (594, 2222, 1241, 0, 0x726f636b206f75742077697420796f757220636f636b206f757920636872697374696e61, 1250, '11/29/2006', 1);
INSERT INTO `photo_rating` VALUES (595, 2221, 1241, 0, 0x647564652075206c6f6f6b206c696b65207572206f6e2073756d7468696e20, 1250, '11/29/2006', 1);
INSERT INTO `photo_rating` VALUES (596, 2141, 1241, 0, 0x617777777720752067757973206c6f6f6b20736f20646f7261626c65, 1250, '11/29/2006', 1);
INSERT INTO `photo_rating` VALUES (597, 2231, 1267, 0, 0x796179212061746c6561747320796f75207069636b656420676f6f6420706963747572657320746869732074696d6521206c6f6c2049206c6f766520796f752062616279, 1268, '11/29/2006', 1);
INSERT INTO `photo_rating` VALUES (598, 2232, 1267, 0, 0x61777777772049206c6f766520796f7520746f20626162792121, 1268, '11/29/2006', 1);
INSERT INTO `photo_rating` VALUES (599, 2111, 1238, 0, 0x6f68206d65682067757273682079616c6c20617265206265617574696d7573206c6f6c206973207468697320756d206c6b652070726f6d206f722073756d7468696e3f, 1250, '11/29/2006', 1);
INSERT INTO `photo_rating` VALUES (600, 2140, 1241, 0, 0x4865792069206c6f766520746861742066696e67657220616e6420796f7520626574746572206e6f7420626520666c69636b696e67206d65206f6666, 1238, '11/29/2006', 1);
INSERT INTO `photo_rating` VALUES (601, 2175, 1250, 0, 0x70726574747920657965206d616b65207570212e2e7572206120706f707065742e2e, 1262, '11/29/2006', 1);
INSERT INTO `photo_rating` VALUES (602, 2204, 1260, 0, 0x6e69636520776f726b206f6e2074686520636c6f746865732e20616e6420657965732e20616e642065766572797468696e6720656c73652e2074686120666973686e657473206e6963652c20746f6f2e2869206c6f6f6f6f6f766520666973686e657421212129, 1237, '11/29/2006', 1);
INSERT INTO `photo_rating` VALUES (603, 2260, 1260, 0, 0x6675636b696e206121, 1237, '11/29/2006', 1);
INSERT INTO `photo_rating` VALUES (604, 2254, 1267, 0, 0x74616b6520746869732064616d6e2070696374757265206f6666212121212121212121212121212131, 1268, '11/29/2006', 1);
INSERT INTO `photo_rating` VALUES (605, 2276, 1268, 0, 0x61777777206c6f6f6b206174206d6520616e64206d792062616279212121210d0a69206c6f766520796f752062616279212121, 1267, '11/29/2006', 1);
INSERT INTO `photo_rating` VALUES (606, 2267, 1268, 0, 0x69206c6f76652068657221, 1267, '11/29/2006', 1);
INSERT INTO `photo_rating` VALUES (607, 2274, 1268, 0, 0x4e6f6e65206f662074686174206e6f77212121210d0a6c6f6c0d0a6261627920796f7572206120646f726b206275742069206c6f766520796f7521212121, 1267, '11/29/2006', 1);
INSERT INTO `photo_rating` VALUES (608, 2269, 1268, 0, 0x617777206d7920626162792069732073657879212121, 1267, '11/29/2006', 1);
INSERT INTO `photo_rating` VALUES (609, 2265, 1268, 0, 0x61777720646f6e742064726f70207468656d2062616279210d0a42454341524546554c21210d0a69206c6f766520796f752062616279212121, 1267, '11/29/2006', 1);
INSERT INTO `photo_rating` VALUES (610, 2271, 1268, 0, 0x686d6d6d2e2e2e2077686f2061726520796f752074657874696e20626162793f3f0d0a686d6d206920776f6e6465723f, 1267, '11/29/2006', 1);
INSERT INTO `photo_rating` VALUES (611, 2268, 1268, 0, 0x6974206c6f6f6b73206c696b6520696d20736c656570696e670d0a627574206775657373207768617420696d206e6f740d0a68656865, 1267, '11/29/2006', 1);
INSERT INTO `photo_rating` VALUES (612, 2275, 1268, 0, 0x65777720626162790d0a67657420796f75722066696e676572206f7574206f662074686572652121210d0a4e41535459, 1267, '11/29/2006', 1);
INSERT INTO `photo_rating` VALUES (613, 2279, 1268, 0, 0x776f6f6f6f6f207768617420626162793f3f3f3f3f3f0d0a692077616e6e61206b6e6f772074656c6c206d652074656c6c206d653f3f200d0a6c6f6c0d0a696d2073756368206120646f726b0d0a62757420796f75206c6f7665206d6521210d0a616e642069206c6f766520796f75, 1267, '11/29/2006', 1);
INSERT INTO `photo_rating` VALUES (614, 2273, 1268, 0, 0x646f6e74206c6f6f6b20736f207361642064616d6e69742121210d0a62652068617070790d0a796f752068617665206d6520696e20796f7572206c696665212121, 1267, '11/29/2006', 1);
INSERT INTO `photo_rating` VALUES (615, 2266, 1268, 0, 0x626162792077686174207765726520796f7520646f696e673f3f3f3f, 1267, '11/29/2006', 1);
INSERT INTO `photo_rating` VALUES (616, 2264, 1268, 0, 0x41777777772c2069206c6f766520796f757220736d696c65206261627921210d0a6275742069206c6f766520796f75206d6f72652121212121, 1267, '11/29/2006', 1);
INSERT INTO `photo_rating` VALUES (617, 2234, 1268, 0, 0x61777777206c6f6f6b206174206d79206261627973206f6e65206c6974746c6520646970706c652e2e20617777772e20736f20637574650d0a69206c6f766520796f752062616279, 1267, '11/29/2006', 1);
INSERT INTO `photo_rating` VALUES (618, 2261, 1268, 0, 0x736578792121206c696b6520616c77617973212121, 1267, '11/29/2006', 1);
INSERT INTO `photo_rating` VALUES (619, 2272, 1268, 0, 0x4c6f6f6b20796f7520776572652074616c6b696e6720746f206d65207768656e20796f7520746f6f6b207468697320706963747572652e2e0d0a5941592121210d0a49206665656c207370656369616c21210d0a69206c6f766520796f752062616279212121, 1267, '11/29/2006', 1);
INSERT INTO `photo_rating` VALUES (620, 2240, 1267, 0, 0x596f7520736f206e65656420746f20736d696c652062616279212121206f6820707320692073656520646f776e20796f757220736869727421206c6f6c, 1268, '11/29/2006', 1);
INSERT INTO `photo_rating` VALUES (621, 2241, 1267, 0, 0x6177772049206c6f766520746869732070696374757265212077686572652064696420796f75206765742074686520726f73653f21, 1268, '11/29/2006', 1);
INSERT INTO `photo_rating` VALUES (622, 2242, 1267, 0, 0x736f2073616421207768793f21, 1268, '11/29/2006', 1);
INSERT INTO `photo_rating` VALUES (623, 2243, 1267, 0, 0x617777207375636820612070726574747920736d696c65206261627921, 1268, '11/29/2006', 1);
INSERT INTO `photo_rating` VALUES (624, 2116, 1233, 0, 0x6f68206d6568206775727368206974732061726d616e6420686568652073727279206966207370656c742077726f6e67206275742079656168207768617473207570700d0a285c285c0d0a283e2e3c290d0a2828222928222920204d4d4657434c, 1250, '11/29/2006', 1);
INSERT INTO `photo_rating` VALUES (625, 2244, 1267, 0, 0x64616d6e20776861747320757020776974682074686573652070696374757265732077686572652065766572796f6e6520616e64207468657265206d6f6d6d6127732063616e2073656520646f776e20796f75722073686972743f21, 1268, '11/29/2006', 1);
INSERT INTO `photo_rating` VALUES (626, 2245, 1267, 0, 0x61777720796f75206c6f6f6b2063757465207769746820796f75722068616972206c696b6520746861742121, 1268, '11/29/2006', 1);
INSERT INTO `photo_rating` VALUES (627, 2246, 1267, 0, 0x74686973206973207375636820612063757465207069637475726521, 1268, '11/29/2006', 1);
INSERT INTO `photo_rating` VALUES (628, 2247, 1267, 0, 0x736f2070726574747920696e20626c61636b20616e64207768697465, 1268, '11/29/2006', 1);
INSERT INTO `photo_rating` VALUES (629, 2239, 1262, 0, 0x6f68206d65682067757273682e2e2e2e206865206c6f6f6b7320736f206861707079206c6f6c202873617263617374696329, 1250, '11/29/2006', 1);
INSERT INTO `photo_rating` VALUES (630, 2214, 1262, 0, 0x69207265616c6c79206c696b65207468697320706963207369737379203c33, 1250, '11/29/2006', 1);
INSERT INTO `photo_rating` VALUES (631, 2181, 1251, 0, 0x5048494c4c495021212121207774662069732077726f6e672077697420796f75206c6f6c206868656865686520776861742061726520796f75206f6e3f20692077616e7420736f6d65206c6f6c206d6d6677636c206868656568686565, 1250, '11/29/2006', 1);
INSERT INTO `photo_rating` VALUES (632, 2182, 1251, 0, 0x6f68206d6568206775727368212121212121212121213120666f722061206d696e75746520692074686f75676874207520776173207477696e6b696521212121, 1250, '11/29/2006', 1);
INSERT INTO `photo_rating` VALUES (633, 2199, 1251, 0, 0x6d616e207068696c6c69702120707574207468617420646f776e20796f752061696e7420676f74206e6f7468696e6721206c6f6c206a6b206865652068656520627574206e617720666f72207265616c2e2e2e2e2e2e2e616865656d6d6d2a2a2a, 1250, '11/29/2006', 1);
INSERT INTO `photo_rating` VALUES (634, 2106, 1237, 0, 0x6c6f6c207468697320706963206973206b696e64612066756e6e792e2e2e2e2069207468696e6b206a61636b20626c61636b20697320736f2073747570696420206c6f6c206275742079656168206b6f6f6c656f2068656865207474796c, 1250, '11/29/2006', 1);
INSERT INTO `photo_rating` VALUES (635, 2278, 1268, 0, 0x6f68206d6568206775727368207065656b2d612d626f6f2069207365652061207265626563636120686568656865, 1250, '11/29/2006', 1);
INSERT INTO `photo_rating` VALUES (636, 2268, 1268, 0, 0x79616c6c2061726520736f2061646f72616269626c65206c6f6c20617777777777205b20205d0d0a2020202020202020202020202020202020202020202020202020202020202020204b6f64616b0d0a20202020202020202020202020202020202020202020202020202020202020206d6f6d656e74, 1250, '11/29/2006', 1);
INSERT INTO `photo_rating` VALUES (637, 2275, 1268, 0, 0x656868682069732074686174206d656361696c613f2069206d697373737320686572203a28282828, 1250, '11/29/2006', 1);
INSERT INTO `photo_rating` VALUES (638, 2231, 1267, 0, 0x746861747320736f6f6f206b6f6f6c207265626563636120796f752073686f756c64207465616368206d6520686f7720746f20646f20697420686568652062757420796561682061777777, 1250, '11/29/2006', 1);
INSERT INTO `photo_rating` VALUES (639, 2231, 1267, 0, 0x746861747320736f6f6f206b6f6f6c207265626563636120796f752073686f756c64207465616368206d6520686f7720746f20646f20697420686568652062757420796561682061777777, 1250, '11/29/2006', 1);
INSERT INTO `photo_rating` VALUES (640, 2232, 1267, 0, 0x796f7520677579736573206c6f7665206973206f6e65206f662061206b696e6420736f6f6f6f207377656174202e2e2e2a2a746561722a2a, 1250, '11/29/2006', 1);
INSERT INTO `photo_rating` VALUES (641, 2253, 1267, 0, 0x4f48204d45482047555253482121212121212120495453204120484950505921212121206c6f6c206a6b20796f75206b6e6f772069203c3320796f75, 1250, '11/29/2006', 1);
INSERT INTO `photo_rating` VALUES (642, 2254, 1267, 0, 0x68657920726562656363612077616e7420746f207365652061206d6167696320747269636b3f3f3f3f3f2020202a2a74686579206a6967676c652a2a202020206c6f6c2072656d656d6265723f2020206a6b6a6b6a6b206c6f6c20, 1250, '11/29/2006', 1);
INSERT INTO `photo_rating` VALUES (643, 2227, 1266, 0, 0x49203c3320746873207063202e2e2e2e2e2e2062757420697420697320736f20656666696e206f6c642e2e2e, 1250, '11/29/2006', 1);
INSERT INTO `photo_rating` VALUES (644, 2172, 1251, 0, 0x6f68206d6568206775727368206d7920746f6e677565206973206265747465722068656865206c6f6c, 1250, '11/30/2006', 1);
INSERT INTO `photo_rating` VALUES (645, 2307, 1269, 0, 0x41777777770d0a736f6f6f6f6f2063757465212121210d0a59616c6c206c6f6f6b20736f6f6f6f6f2068617070790d0a6c6f6c0d0a3c33207961206769726c0d0a2a526562656363612a, 1267, '11/30/2006', 1);
INSERT INTO `photo_rating` VALUES (646, 2270, 1269, 0, 0x7768617473206f7665722074686572653f3f0d0a68756820687568206875683f3f3f0d0a6c6f6c0d0a4974732061207265616c2063757465207069630d0a3c332079610d0a2a526562656363612a, 1267, '11/30/2006', 1);
INSERT INTO `photo_rating` VALUES (647, 2308, 1269, 0, 0x4177772077686f7320746861743f3f, 1267, '11/30/2006', 1);
INSERT INTO `photo_rating` VALUES (648, 2296, 1263, 0, 0x68656c6c6f2e2e2e2e, 1242, '11/30/2006', 1);
INSERT INTO `photo_rating` VALUES (649, 2304, 1270, 0, 0x686920686f772061726520796f752e20796f75206c6f6f6b206e6963652e, 1236, '11/30/2006', 1);
INSERT INTO `photo_rating` VALUES (650, 2295, 1262, 0, 0x3c666f6e7420666163653d7363726970743e3c666f6e742073697a653d363e0d0a6d792062656175746966756c206a65737321210d0a0d0a266865617274733b, 1269, '11/30/2006', 1);
INSERT INTO `photo_rating` VALUES (651, 2172, 1251, 0, 0x6e6f206d7920746f756e6720697420626574746572207468656e20796f7572732e2e2e3a29, 1242, '11/30/2006', 1);
INSERT INTO `photo_rating` VALUES (652, 2183, 1251, 0, 0x79656168206d616e6e206d6520746f6f20796f75722068616972206675636b696e20726f636b7320696e207468697320706963, 1250, '11/30/2006', 1);
INSERT INTO `photo_rating` VALUES (653, 2282, 1267, 0, 0x61776821212074686973206973206b75746520626563636121210d0a0d0a3c33207961, 1269, '11/30/2006', 1);
INSERT INTO `photo_rating` VALUES (654, 2333, 1271, 0, 0x796f7520676f7420746861742066726f6d20626f626279206c6173742079656172, 1242, '11/30/2006', 1);
INSERT INTO `photo_rating` VALUES (655, 2332, 1271, 0, 0x6c6f6f6b20617420746861742075676c792061737320666167, 1242, '11/30/2006', 1);
INSERT INTO `photo_rating` VALUES (656, 2327, 1237, 0, 0x4f48204d45482047555253482121212121212121212020434f4e535449504154494f4e21212121212121212121212121212121212121212121212121212121212121212121212121212121212121212121212121212121212121212121212121212121212121212121212121212121212121212121212121212121212121212121212121212121212121212121212121212121212121212121212121206c6f6c, 1250, '11/30/2006', 1);
INSERT INTO `photo_rating` VALUES (657, 2326, 1237, 0, 0x6f68206d6568206775727368206f6820736f20736578792069207468696e6b20686520736565732073616e7461, 1250, '11/30/2006', 1);
INSERT INTO `photo_rating` VALUES (658, 2328, 1237, 0, 0x69207761732073697474656e20746865726520747279696e20746f20666967757265206f75742077686174204a422073746f6f6420666f72206f6e2068697320677569746172, 1250, '11/30/2006', 1);
INSERT INTO `photo_rating` VALUES (659, 2322, 1242, 0, 0x61777768682e2e697473206d656565652e2e3c332069206c6f76652074686973206f6e656565, 1262, '11/30/2006', 1);
INSERT INTO `photo_rating` VALUES (660, 2172, 1251, 0, 0x756d202e2e2e2e2e206e6f2069742061696e74212121206c6f6c2068656865686520206d696e6573206973206c6f6e676572212121212121206c6f6c, 1250, '11/30/2006', 1);
INSERT INTO `photo_rating` VALUES (661, 2335, 1242, 0, 0x6974732075732e2e2e2e6d616e2074686174207368697274206d616b65206d65206c6f6f6b2066617465722e2e2e2e676f6f64206e6967687420626162792e2e2e69206c6f76652075, 1241, '11/30/2006', 1);
INSERT INTO `photo_rating` VALUES (662, 2317, 1242, 0, 0x6d616e207468697320697320612062616420706963206f66206d65, 1241, '11/30/2006', 1);
INSERT INTO `photo_rating` VALUES (663, 2316, 1242, 0, 0x69747320656d696c79, 1241, '11/30/2006', 1);
INSERT INTO `photo_rating` VALUES (664, 2324, 1242, 0, 0x6f72207220746865792e2e2e2e2e6c6f76652075, 1241, '11/30/2006', 1);
INSERT INTO `photo_rating` VALUES (665, 2318, 1242, 0, 0x6865792069206b6e6f772074686573652070656f706c65, 1241, '11/30/2006', 1);
INSERT INTO `photo_rating` VALUES (666, 2348, 1251, 0, 0x6f68206d6568206775727368212121212121212121212120204849474820464956452042495a4e4954434821212121, 1250, '12/01/2006', 1);
INSERT INTO `photo_rating` VALUES (667, 2347, 1251, 0, 0x77686174207068696c6c6970732074686e6b696e672e2e2e2e2269662069206f6e6c7920686164206120627261696e22, 1250, '12/01/2006', 1);
INSERT INTO `photo_rating` VALUES (668, 2350, 1251, 0, 0x2a2a444f4e5457414c4b20494e544f20544845204c494748542a2a, 1250, '12/01/2006', 1);
INSERT INTO `photo_rating` VALUES (669, 2346, 1251, 0, 0x746869732070696320676976657320616c6c206e6577206d65616e696e6720746f2073687574207468656675636b207570212121206c6f6c, 1250, '12/01/2006', 1);
INSERT INTO `photo_rating` VALUES (670, 2199, 1251, 0, 0x686f772064696420796f752067657420736f207269707065642c20686f77206d616e7920636f636b7320646f20796f75206861766520746f207375636b20746f206765742074686f7365206e61737479206c6f6f6b696e206162733f3f3f, 1237, '12/01/2006', 1);
INSERT INTO `photo_rating` VALUES (671, 2335, 1242, 0, 0x686179206d616b65206d79206d6f6e657920686f65, 1271, '12/01/2006', 1);
INSERT INTO `photo_rating` VALUES (672, 2211, 1260, 0, 0x69206c696b65732064612070616e747920737472617073212121, 1237, '12/01/2006', 1);
INSERT INTO `photo_rating` VALUES (673, 2131, 1244, 0, 0x636f6f6c2070696320616e64206272697461696e2072207520612066656c696e65206e6f77206c6f6c, 1251, '12/01/2006', 1);
INSERT INTO `photo_rating` VALUES (674, 1393, 1027, 0, 0x41726520796f7520746865206f6e65207769746820746865206772617920776974682072656420737472697065206f7220746865206f6e6520696e207468652079656c6c6f772073686972742e, 1223, '12/01/2006', 1);
INSERT INTO `photo_rating` VALUES (675, 2405, 1241, 0, 0x6375746965, 1243, '12/02/2006', 1);
INSERT INTO `photo_rating` VALUES (676, 2396, 1241, 0, 0x796f757220736f20676f6f66792121, 1243, '12/02/2006', 1);
INSERT INTO `photo_rating` VALUES (677, 2374, 1244, 0, 0x746861742062206d69207368697274207368617774792e6c6d616f2e, 1233, '12/02/2006', 1);
INSERT INTO `photo_rating` VALUES (678, 2371, 1244, 0, 0x57686f6f702057686f6f70207468617473206d6520534c696d204b6c6f776e2e2064616d6e20696d20736578692e20686168612c206e6f74207265616c6c792e, 1233, '12/02/2006', 1);
INSERT INTO `photo_rating` VALUES (679, 2417, 1251, 0, 0x416820686f772063757465, 1260, '12/04/2006', 1);
INSERT INTO `photo_rating` VALUES (680, 2167, 1251, 0, 0x54686973206973207468652062657374206f6e6c696e652070686f746f, 1260, '12/04/2006', 1);
INSERT INTO `photo_rating` VALUES (681, 2393, 1241, 0, 0x7768792064696420796f7520737465616c206d792061727420776f726b, 1242, '12/04/2006', 1);
INSERT INTO `photo_rating` VALUES (682, 2397, 1241, 0, 0x7468697320697320737475706964, 1242, '12/04/2006', 1);
INSERT INTO `photo_rating` VALUES (683, 2417, 1251, 0, 0x6e6f20776179207068696c69702e2e2e657777772e2e2e776f77212121, 1242, '12/04/2006', 1);
INSERT INTO `photo_rating` VALUES (684, 2371, 1244, 0, 0x697473207374757069642061726d6f6e, 1271, '12/04/2006', 1);
INSERT INTO `photo_rating` VALUES (685, 2417, 1251, 0, 0x6375746520706963, 1268, '12/04/2006', 1);
INSERT INTO `photo_rating` VALUES (686, 2428, 1242, 0, 0x64617473206d6520, 1271, '12/04/2006', 1);
INSERT INTO `photo_rating` VALUES (687, 2414, 1233, 0, 0x6f6d672069206c6f7665207468697320, 1238, '12/04/2006', 1);
INSERT INTO `photo_rating` VALUES (688, 2129, 1244, 0, 0x73657869206769722e2e2e2e20646f6f6d20646f6f6d20646f6f6d20646f6f6d20646f6f6d20646f6f6d20646f6f6d20646f6f6d, 1233, '12/04/2006', 1);
INSERT INTO `photo_rating` VALUES (689, 2375, 1244, 0, 0x6f6d67206974206675636b696e2070696e6b20736177746965, 1233, '12/04/2006', 1);
INSERT INTO `photo_rating` VALUES (690, 2376, 1244, 0, 0x646f2074686520726f632061776179206e206c65616e206261636b206c65616e206261636b206c65616e206261636b, 1233, '12/04/2006', 1);
INSERT INTO `photo_rating` VALUES (691, 2377, 1244, 0, 0x736d696c652034206d652064616464692077686174207520636861206c6f6f6b696e206174206c6574206d652063207572206772696c6c20752077616e6e612063206d6920776861743f3f, 1233, '12/04/2006', 1);
INSERT INTO `photo_rating` VALUES (692, 2378, 1244, 0, 0x626f6f62696765, 1233, '12/04/2006', 1);
INSERT INTO `photo_rating` VALUES (693, 2379, 1244, 0, 0x626c75686868686c616c616c616c61, 1233, '12/04/2006', 1);
INSERT INTO `photo_rating` VALUES (694, 2380, 1244, 0, 0x692063616e2073686f6c646572206c65616e206920646f6e74206b6e6f20686f7720746f2064616e63652074686f2e2e2e2e61636375616c6c79206920646f2e, 1233, '12/04/2006', 1);
INSERT INTO `photo_rating` VALUES (695, 2417, 1251, 0, 0x68656865206c6f6f6b20617420752e2e2066756e6e792e2e206275742063757465203d5d2062757420796561206920746f74616c6c792077656e7420746f20666169726669656c64207769746820752e2e20752070726f62616c6c7920646f6e742072656d656d6265722074686f2e2e2e20, 1244, '12/04/2006', 1);
INSERT INTO `photo_rating` VALUES (696, 2428, 1242, 0, 0x6d7920676f642067657420746869732070696374757265207572207468696e6720752072206b696c6c696e672065766572796f6e652e2e2e2e6a75737420706c6179696e2e2e2e2e2e6e6f74, 1241, '12/04/2006', 1);
INSERT INTO `photo_rating` VALUES (697, 2417, 1251, 0, 0x6f6f6f6f6868206d7920676f642e2e2e2e647564652077686174207468652068656c6c2e2e2e2e6577777777772e2e2e2e, 1241, '12/04/2006', 1);
INSERT INTO `photo_rating` VALUES (698, 2316, 1242, 0, 0x6865792e2e697473206d7920626162792e2e736865206c6f6f6b6b73207375706572206372617a7920686572652e206c6f6c2e2e2e696c79206372797374616c, 1243, '12/05/2006', 1);
INSERT INTO `photo_rating` VALUES (722, 2584, 1321, 0, 0x616c6c206d6969696e6e6e6e65656565203a44, 1286, '01/16/2007', 1);
INSERT INTO `photo_rating` VALUES (700, 541, 440, 0, 0x227368652773206c697374656e696e672c2062757420686572206579657320617265206f6e2074686520646f6f7222, 1295, '12/10/2006', 1);
INSERT INTO `photo_rating` VALUES (701, 2167, 1251, 0, 0x686568652069206861766520746861742073686972742e2e2e, 1244, '12/12/2006', 1);
INSERT INTO `photo_rating` VALUES (702, 2167, 1251, 0, 0x686568652069206861766520746861742073686972742e2e2e, 1244, '12/12/2006', 1);
INSERT INTO `photo_rating` VALUES (703, 2167, 1251, 0, 0x686568652069206861766520746861742073686972742e2e2e, 1244, '12/12/2006', 1);
INSERT INTO `photo_rating` VALUES (704, 301, 211, 0, 0x746f6c73747573686b69203a2929292929, 847, '12/13/2006', 1);
INSERT INTO `photo_rating` VALUES (705, 2464, 1017, 0, 0x4e69636520736578792076657279207665727920736578792c2049206c696b6520796f757220626f6f62696520746865792061726520766572792079756d6d79206168686168616861686168610d0a0d0a4d6174766179, 1016, '12/13/2006', 1);
INSERT INTO `photo_rating` VALUES (721, 2584, 1321, 0, 0x686d6d2e2e2e6c6f6f6b206174207468697320686f74746965203a29, 1286, '01/16/2007', 1);
INSERT INTO `photo_rating` VALUES (720, 1117, 928, 0, 0x686f6c612e2e2e3f202068692e2e2e3f20, 1324, '01/14/2007', 1);
INSERT INTO `photo_rating` VALUES (709, 2368, 1286, 0, 0x796f757220707265747920686f74, 805, '12/19/2006', 1);
INSERT INTO `photo_rating` VALUES (710, 1060, 118, 0, 0x6b616b61796120706f7061, 980, '12/27/2006', 1);
INSERT INTO `photo_rating` VALUES (711, 2577, 1310, 0, 0x48414841213c62723e0d0a564552592043555445213c62723e0d0a4c4f4c203a443c62723e0d0a594f5520534f2053494c4c592e2e2049204c4f564520594f553c62723e0d0a5b266865617274733b5d, 1315, '01/06/2007', 1);
INSERT INTO `photo_rating` VALUES (712, 2583, 1310, 0, 0x564552592043555445213c62723e0d0a49204c4f5645205448495320504943213c62723e0d0a4920544f4f4b204954213c62723e0d0a594f55204c4f4f4b20424f4d422e4f524721, 1315, '01/06/2007', 1);
INSERT INTO `photo_rating` VALUES (713, 2583, 1310, 0, 0x686579206e696e6b61212074686174206973206c696b6520736f20736f20637574652e2e2e69206a757374206c6f76652069742120616e642069732064616e6e6120696e20746865207069637475726520746f6f3f2074686174732066756e6e79206c6f6c2e2e2e6c6f7665207961203d29, 1054, '01/06/2007', 1);
INSERT INTO `photo_rating` VALUES (714, 2367, 1286, 0, 0x64616d6d2074616e6963686b6120746861747320686f7421212121206e696365206f757466697420746f2e2e2e2e, 1321, '01/09/2007', 1);
INSERT INTO `photo_rating` VALUES (715, 2584, 1321, 0, 0x686579206375746965203b29, 1286, '01/09/2007', 1);
INSERT INTO `photo_rating` VALUES (716, 2368, 1286, 0, 0x70726974747920686f742e2e75206d65616e20662a2a6b696e6720686f74742121212121212121, 1321, '01/09/2007', 1);
INSERT INTO `photo_rating` VALUES (717, 2585, 1286, 0, 0x2267616e67737461220d0a, 1321, '01/09/2007', 1);
INSERT INTO `photo_rating` VALUES (718, 2590, 1286, 0, 0x706f736572206c6f6c206a6b20686f742e2e2e, 1321, '01/09/2007', 1);
INSERT INTO `photo_rating` VALUES (719, 2587, 1286, 0, 0x6275746966756c2e2e2e77686174206b696e6461206472696e6b20697320746861743f3f3f, 1321, '01/09/2007', 1);
INSERT INTO `photo_rating` VALUES (736, 434, 153, 0, 0x68692077656c6c20692073656520796f75207468617420796f7520666f726765742061626f757420796f7572206f6c6420667269656e642e20627965206b697373657320616e2061206875672e20, 1236, '02/16/2007', 1);
INSERT INTO `photo_rating` VALUES (737, 1088, 916, 0, 0x79612073686573207269676874200d0a796f7520646f20686176652061206e6963652072696465, 1340, '03/13/2007', 1);
INSERT INTO `photo_rating` VALUES (738, 2430, 1201, 0, 0x7265616c6c79206375746521, 1366, '04/11/2007', 1);
INSERT INTO `photo_rating` VALUES (739, 1294, 994, 0, 0x6c6f76652074686174206c6f6f6b2068756e6e2e2e2e6375746521, 1385, '05/29/2007', 1);

-- --------------------------------------------------------